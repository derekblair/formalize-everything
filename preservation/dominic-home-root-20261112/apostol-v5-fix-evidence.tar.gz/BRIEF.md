# BRIEF — Apostol dossier v5 fix (Carbon)

**Task:** Repair `DOSSIER-APOSTOL-v4.md` (T. M. Apostol, *Introduction to Analytic Number
Theory*, Springer UTM, 1976) per the authoritative crossed review of record, and deliver
`DOSSIER-APOSTOL-v5.md` (NEW file — do not overwrite v4).

**Ticket:** formalize-everything #67. **Research only:** literature and source-level
verification. No Lean or Isabelle build, no kernel check, no `#print axioms`, no
formalization, no package installation/removal, no repository mutation, no GitHub write,
no merge. This lane does not review its own work and does not arrange any review: the
renewed crossed review of v5 is coordinator-appointed after v5 lands. **Lanes never
arrange their own reviews.**

**Harness (standing, Derek 2026-11-10):** agy, `--model gemini-4-carbon-high --effort high`
(max thinking for Carbon; `--effort max` is rejected for this model), pool
google-ai-ultra. No `--sandbox` on formalization lanes. No Lean on xavier, ever.

**Deliverable:** `DOSSIER-APOSTOL-v5.md` in this directory, written incrementally as you
verify each section, ending with the line `DOSSIER COMPLETE.`. When done, print
`DOSSIER_DONE` as the last line of your session output.

## 0. Inputs (sha256-verified in-lane before any repair work)

| File | SHA-256 | Lines | Role |
|---|---|---|---|
| `DOSSIER-APOSTOL-v4.md` | `75f6aa332ac949dde87816f75b050ef2061aa8b671ff550a1dd284e18744cca1` | 741 | Failed antecedent under repair |
| `REVIEW-APOSTOL-v4.md` | `b85572469b5ff5f59d552f29896d6af0f73591421a6e686161c0e2028e8cf262` | 254 | Authoritative repair spec (**FAIL**) |
| `REVIEW-APOSTOL-v3.md` | `1735cfc9b1067e6dc328f92a60c996af4033b5aa3f65efb73e017d4922b70951` | 208 | Prior repair authority (FAIL, C1–C6) |
| `DOSSIER-APOSTOL-v3.md` | `d5861c5101cd065c0f544e19448d15fbc7a0968614b5ba70a8f579db4f975d7f` | 422 | Failed antecedent |
| `REVIEW-APOSTOL-v2.md` | `54419458d7501605416f71e54affe6a1f5090cdbff46aff90bbd6f87fdb74cc9` | 235 | Prior repair authority (FAIL, R1–R9) |
| `DOSSIER-APOSTOL-v2.md` | `7cc27b0201c5b6ba13d01f05165ccd1439f7da11226c84092d02a49198f7f13a` | 522 | Failed antecedent |

Pinned upstream (live-verify, do not invent pins): Mathlib
`leanprover-community/mathlib4@862047ba60dbfd5ec316433fb728e310612e6449`. The v4
evidence package (`evidence-v4/`, manifest `44/44` clean; `evidence-v3/`, `101/101`
clean) is on dominic in the v4-fix task dir
`/root/projects/math/tasks/carbon-apostol-v4-fix-20261110/` — re-run `check-manifest.py`
read-only against it and confirm both counts before relying on any evidence claim.
`jonhanke/analytic-number-theory-lean` pin `2a7c236a347a23d8187f7a027aad058c1ee844f8`
(v4 §3.8) — do not promote any of its rows to verified coverage; Gate 1 stands.

## 1. The blocking defect — AT12.10 (REVIEW §1.1(3), §1.3, §3 item 1)

`DOSSIER-APOSTOL-v4.md:405` states, and counts as full `[M]` in §4.2 (L580):

> Functional equation of Hurwitz zeta (finite cos/sin sum form): for `0 < a ≤ 1`
> (`a : ℝ` mapped to `UnitAddCircle`) and `s ∈ ℂ` satisfying `∀ n ∈ ℕ, s ≠ -n`
> and `(a < 1 ∨ s ≠ 1)`, `ζ(1 - s, a) = (2 Γ(s) / (2π)^s) (cos(π s / 2)
> ∑_{n=1}^∞ cos(2π n a) n^{-s} + sin(π s / 2) ∑_{n=1}^∞ sin(2π n a) n^{-s})`
> (expressed at M via `hurwitzZetaEven` / `hurwitzZetaOdd` in `hurwitzZeta_one_sub`,
> `NumberTheory_LSeries_HurwitzZeta.lean:141`).

This is **mathematically false as written**. The stated hypotheses hold at
`(a, s) = (1, 1/2)` yet the LHS is finite (`ζ(1/2) ≈ -1.46035`) while the RHS
diverges (`∑ n^{-1/2} = +∞`); both series fail the n-th term test across the whole
half-plane `{Re(s) ≤ 0} \ (-ℕ)` for every `a ∈ (0, 1]`. Two compounding errors:

- (a) The `Re(s) > 1` condition on the raw infinite trigonometric series is omitted.
  Sibling row AT12.8 (L403) carries `Re(s) > 1` for the same series form.
- (b) The citation is wrong and the object is misidentified: `hurwitzZeta_one_sub` is
  at `HurwitzZeta.lean:157–160` (`:141` is `hurwitzZetaEven_one_sub`) and is stated
  via the **analytically continued** `expZeta` (`cosZeta + I * sinZeta`, `:116`),
  which equals the infinite series only when `1 < re s`
  (`hasSum_expZeta_of_one_lt_re`, `:129`). The title `"finite cos/sin sum form"`
  refers to Apostol's rational-parameter theorem (`a = h/k`, a **finite** `k`-term
  sum over `m = 1..k` involving `ζ(s, m/k)`), which the pasted infinite series is not.

**Required fix — choose exactly one, and prove the choice from a live source:**

- (i) **Restate via the continued functions** (`cosZeta` / `sinZeta` / `expZeta` at
  `HurwitzZeta.lean:157`) if that matches the intended node — verify the statement
  against the live Mathlib file at the frozen pin and quote the declaration; keep
  `[M]` only if the restated node genuinely matches `hurwitzZeta_one_sub`.
- (ii) **Write the true finite-sum statement** for rational `a = h/k` (the review's
  candidate form: `ζ(1 - s, h/k) = (2 Γ(s) / (2π k)^s) ∑_{m=1}^k
  cos(π s / 2 - 2π m h / k) ζ(s, m/k)`) — only if you verify that exact form from
  a live source (Apostol's text or a cited secondary source); do not invent it.
- (iii) **Otherwise mark AT12.10 `UNFINISHED`** (pending physical-book check) and
  **demote it from `[M]`**: `[M] 56 → 55`, Lean full `58 → 57`, any-assistant
  `69 → 68`, remainder `249 → 250` — and update **every** figure that depends on
  the demotion consistently (§0, §4.1–4.2, §6.2, §8.1; the §4.2 Ch. 12 row and
  the §8 repair table). The corrected coverage is `[M] = 55/318` (17.3%),
  `[E] = 2/318` (0.6%), Lean `57/318` (17.9%), `[X] = 11/318` (3.5%),
  any-assistant `68/318` (21.4%), remainder `250/318` (78.6%).

Whichever branch you take, also correct: the `hurwitzZeta_one_sub` citation to
`:157`; the §8.1/§8.2 disposition entries for C1, C3, R1d, R2 (review §1.9(1) —
they currently report those items closed); and the AT12.8/AT12.10 collision note in
§1.1 so the two rows are no longer conflated.

**Do not** silently weaken the statement, do not keep `[M]` on a divergent-series
formula, and do not re-label the infinite series as the finite sum. If neither (i)
nor (ii) can be verified from a live source, (iii) is the correct outcome — a
demotion honestly recorded beats a repaired-looking falsehood.

## 2. Nonblocking repairs (REVIEW §3 items 2–4)

- **(2) Refresh §6.1 controlling programme state** to the live 2026-11-11 state.
  The review's §2.4 table (dated 2026-11-11 01:23 PST) is your starting point, not
  your source: re-verify each slot live before writing. Its five stale 2026-11-10
  cells were `#5` Walters, `#7` Marker, `#8` Milnor, `#9` van Lint, `#11`
  Cutland. Known transitions since the review (verify, do not copy blindly):
  Walters v4 renewed crossed review running on xanthe; Cutland v3 fix running on
  brooklynn; Marker v4 review PASS recorded on #72; Milnor v3 review PASS WITH
  ISSUES recorded on #70; van Lint v3 review PASS recorded on #73; Apostol v4
  review FAIL recorded on #67 (this repair). The `#4` slot stays NOT established;
  the no-ordinal stance stands.
- **(3) Fix the `"7" → "8"` count** in §4.3(2)(a) (L603) and §8.1 (L721): the
  enumerated re-proof list is `AT13.11` (1) + `AT13.14` (1) + `AT12.6, AT12.9,
  AT12.10, AT12.11` (4) + `AT6.17, AT7.2` (2) = **8** nodes. Exception: if
  AT12.10 is demoted under §1(iii), the count becomes **7** — state which case
  holds and why; do not leave the two sections disagreeing.
- **(4) Fix Ch. 12 citation line numbers and the companion timestamp label:**
  `AD12.2` → `HurwitzZeta.lean:53,73`; `AD12.3` → `RiemannZeta.lean:127,207`;
  `AT12.9` → `RiemannZeta.lean:106,178`; `AT12.10` → `HurwitzZeta.lean:157`
  (all at Mathlib pin `862047ba…`, live-verified). Label `2026-11-10T18:33:08Z`
  on `jonhanke/elementary-number-theory-lean@a72ea556…` (§3.8 L538) as the
  **commit date** (`created_at` is `2026-11-09T15:30:42Z`).

## 3. What must NOT change

- Everything the v4 review verified as REPAIRED stays repaired: C2 (318 IDs, chapter
  totals sum), C4 (20-shard Formalpedia scan reproducible), C5 (55-node inventory
  separated), C6 (jonhanke live-verified at pin `2a7c236a…`, zero rows promoted),
  all 4 nonblocking items, both manifests, all 120 `UNFINISHED` markers, the 68/69
  verified counted matches, and every R1–R9 disposition. Do not re-open any of
  them; do not renumber any §2 ID; do not change any other coverage figure.
- Preserve the §8 disposition table and §6.3 Gates 1–6 verbatim except for the
  corrections §1–§2 require. Preserve the honest candidate-without-selection
  stance: v5 claims NO slot and establishes none.

## 4. Verification bar for v5 (do all of it, record the evidence)

- Re-run the §2 bullet parse (318 unique IDs, `70 AD + 248 AT`, `0` gaps, `0`
  duplicates) and the coverage recomputation from the v5 text itself; print the
  recomputed `[M]/[E]/[X]`/remainder figures and confirm every section agrees.
- Live-fetch `HurwitzZeta.lean` at the frozen Mathlib pin and quote the exact
  `hurwitzZeta_one_sub` declaration (`:157–160`) and `hasSum_expZeta_of_one_lt_re`
  (`:129`) in the dossier or its evidence note — whichever §1 branch you take.
- Re-run `check-manifest.py` read-only over `evidence-v4/` and `evidence-v3/`
  (dominic v4-fix task dir) and record `checked/bad/missing/unparsed` for both.
- Re-verify the five §6.1 cells against live GitHub state (issue comments on
  #68, #70, #72, #73, #75) and record the comment IDs or timestamps you relied on.
- End the dossier with a §8-style disposition table mapping every v4-review item
  (blocking AT12.10; nonblocking 2–4) to its v5 repair with section pointers.

## 5. Hard gates (programme standing rules — violating any of these fails the lane)

- Zero sorries/admits in any Lean claim (research only — no Lean work in this lane
  at all). Axioms only propext / Classical.choice / Quot.sound (no Lean work here,
  so nothing to audit — do not introduce any).
- Faithful statements: never weaken a statement silently; a demotion is recorded
  explicitly with the arithmetic (§1(iii)).
- No installs or removals on any machine. No Lean on xavier, ever (not applicable
  — this lane is on dominic, research only).
- This lane never merges and never reviews its own work. No GitHub writes of any
  kind from this lane. The renewed crossed review of v5 is coordinator-appointed.
- If any v4-review finding cannot be verified from a live source, say so in the
  dossier explicitly rather than asserting it — a flagged uncertainty beats a
  silent assumption.
