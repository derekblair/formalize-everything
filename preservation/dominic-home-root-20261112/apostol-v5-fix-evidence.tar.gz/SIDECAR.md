# SIDECAR — carbon-apostol-v5-fix-20261110

- **Item:** Apostol dossier v5 fix (formalize-everything #67; repair of
  `DOSSIER-APOSTOL-v4.md` after crossed Carbon review FAIL).
- **Lane:** `carbon-apostol-v5-fix-20261110`, dominic, agy
  `--model gemini-4-carbon-high --effort high`, pool google-ai-ultra.
- **Brief:** `lane-prompts/brief-carbon-apostol-v5-fix-20261110.md` (sha256 to be
  recorded at launch; written by the coordinator this run, grounded in the v4
  crossed review read in full).
- **Runner:** `lane-prompts/run-carbon-apostol-v5-fix-20261110.sh` (bash -n clean;
  md5 recorded at launch).
- **Deliverable:** `DOSSIER-APOSTOL-v5.md` (NEW file, ends `DOSSIER COMPLETE.`),
  session prints `DOSSIER_DONE`.
- **Inputs (desk-verified sha256):**
  - v4 dossier `75f6aa332ac949dde87816f75b050ef2061aa8b671ff550a1dd284e18744cca1`
    (741 lines)
  - v4 review `b85572469b5ff5f59d552f29896d6af0f73591421a6e686161c0e2028e8cf262`
    (254 lines, FAIL — authoritative repair spec)
  - v3 review `1735cfc9b1067e6dc328f92a60c996af4033b5aa3f65efb73e017d4922b70951`
  - v3 dossier `d5861c5101cd065c0f544e19448d15fbc7a0968614b5ba70a8f579db4f975d7f`
  - v2 review `54419458d7501605416f71e54affe6a1f5090cdbff46aff90bbd6f87fdb74cc9`
  - v2 dossier `7cc27b0201c5b6ba13d01f05165ccd1439f7da11226c84092d02a49198f7f13a`
  - Evidence dirs + `check-manifest.py` staged in-lane from the dominic v4-fix
    task dir (`/root/projects/math/tasks/carbon-apostol-v4-fix-20261110/`,
    same machine); manifests re-checked read-only (`evidence-v4` 44/44,
    `evidence-v3` 101/101).
- **Repair scope:** ONE blocking defect (AT12.10 false/divergent Hurwitz series,
  missing `Re(s) > 1`, wrong citation `:141` vs `:157`, finite/infinite conflation;
  review §3 item 1 — restate via `expZeta`/`cosZeta`/`sinZeta`, or write the true
  finite-sum form from a live source, or mark `UNFINISHED` + demote `[M]` 56→55
  with full arithmetic updates) + three nonblocking items (§6.1 refresh to live
  2026-11-11 state; `"7" → "8"` count; Ch. 12 citation lines + companion
  timestamp label). Everything else the v4 review verified REPAIRED stays
  repaired; no §2 renumbering; `#4` slot NOT established; no-ordinal stance.
- **Reviewer independence:** fresh Carbon session; v4 authored by the sibling's
  Carbon fix lane on dominic, v4 reviewed by Carbon on xanthe. This is a fix
  lane (repair directed by the independent review), not a crossed review; the
  renewed crossed review of v5 is coordinator-appointed after v5 lands, on a
  different machine where possible. Lanes never arrange their own reviews.
- **Routing (lane_router + pool_status):** pool cache observed
  2026-11-11T02:04:53-07:00 (stale-DST stamp = 02:04:53 PST): google-ai-ultra 5h
  100% / weekly 100%; Carbon capacity healthy. Machine dominic: only free Carbon
  machine with verified agy + Lean (xanthe runs the Walters v4 review, brooklynn
  runs the Cutland v3 fix, bakkie agy signed out, xavier Lean-banned, nibbles
  not a Carbon machine). Same machine as the v4 author — recorded honestly; the
  fix is directed by the independent v4 review, and the v5 crossed review goes
  elsewhere.
- **Pre-launch checks:** no `carbon-apostol-v5*` session or task dir on dominic
  (verified this run); no Apostol v5 claim in CLAIMS.md (verified this run);
  dominic holds no running Carbon session (verified this run).
- **Claim:** coordinator claim appended to `lane-reports/CLAIMS.md` this run
  before launch. The sibling loop must NOT launch a second Apostol v5 fix —
  harvest this lane's `DOSSIER-APOSTOL-v5.md` instead.
- **Expires:** when v5 is harvested + verified and its renewed crossed review
  launches, or on RELEASE.
