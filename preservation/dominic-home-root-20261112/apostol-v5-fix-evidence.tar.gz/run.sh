#!/bin/bash
# Runner: carbon-apostol-v5-fix-20261110 (dominic, google-ai-ultra).
# Carbon fix of the Apostol v4 dossier (FE #67) per the crossed Carbon review
# of record (FAIL, one blocking defect AT12.10 + 3 nonblocking items),
# coordinator-appointed. Brief:
# lane-prompts/brief-carbon-apostol-v5-fix-20261110.md
# Fix pool Carbon (fresh agy session; v4 authored by the sibling's Carbon fix
# lane on dominic, reviewed by Carbon on xanthe - the fix is a repair directed
# by the independent review, not a crossed review; the renewed crossed review
# is coordinator-appointed after v5 lands; lanes never arrange their own
# reviews).
# Harness: agy, --model gemini-4-carbon-high --effort high (max thinking for
# Carbon; --effort max is rejected), --dangerously-skip-permissions (yolo
# mode, Derek's standing rule). Interactive tmux session; the brief is
# delivered as a file in the task dir and read by the session.
# Research only: no coding, no Lean, no repo writes, no GitHub writes, no
# installs. Deliverable DOSSIER-APOSTOL-v5.md in the task dir (NEW file),
# ending with the line DOSSIER COMPLETE. The session prints DOSSIER_DONE as
# the last line of its output when finished.
# RUNNER LESSONS (Marker v3 + Walters v3 + Cutland v2/v3 Carbon launches):
# the AGY_READY probe can fire on the welcome banner and the first send-keys
# can be eaten, and the `esc to cancel` probe alone is unreliable - so this
# runner verifies delivery by receipt (pane shows the session working on
# BRIEF.md) and re-sends once (after Escape) if the receipt is absent. The
# brief tells the session to write incrementally, so a partial dossier is
# still usable; the coordinator harvests the on-disk file and does NOT restart
# from scratch (Walters v3 lesson: a lane can die on a stream idle timeout
# with a complete deliverable on disk but no DONE marker).
set -u
export PATH="/root/.local/bin:/usr/local/bin:$PATH"
TASKDIR=/root/projects/math/tasks/carbon-apostol-v5-fix-20261110
V4FIXDIR=/root/projects/math/tasks/carbon-apostol-v4-fix-20261110
SESSION=carbon-apostol-v5-fix-20261110
LOG="$TASKDIR/carbon-run.log"
mkdir -p "$TASKDIR"
cd "$TASKDIR" || exit 1
# --- Stage evidence dirs + check-manifest.py from the v4-fix lane (same box) ---
for d in evidence-v4 evidence-v3; do
  if [ ! -d "$d" ]; then cp -r "$V4FIXDIR/$d" "$d" || exit 3; fi
done
if [ ! -f check-manifest.py ]; then cp "$V4FIXDIR/check-manifest.py" . 2>/dev/null || cp /root/projects/math/tasks/carbon-review-apostol-v4-20261110/check-manifest.py . 2>/dev/null || echo "CHECK_MANIFEST_MISSING: evidence re-check skipped, lane notes it"; fi
# v1 chain is background context only: stage if present, never fail on absence.
for f in DOSSIER-APOSTOL.md REVIEW-APOSTOL.md; do
  if [ ! -f "$f" ]; then cp "$V4FIXDIR/$f" "$f" 2>/dev/null || true; fi
done
# --- Step 0: verify staged inputs; fail fast (exit 3) on any mismatch ---
{
  echo "RUN_START $(date -u +%Y-%m-%dT%H:%M:%SZ)"
  agy --version 2>&1 | head -3
  sha256sum DOSSIER-APOSTOL-v4.md REVIEW-APOSTOL-v4.md REVIEW-APOSTOL-v3.md DOSSIER-APOSTOL-v3.md REVIEW-APOSTOL-v2.md DOSSIER-APOSTOL-v2.md BRIEF.md SIDECAR.md
  echo "expected dossier-v4 75f6aa332ac949dde87816f75b050ef2061aa8b671ff550a1dd284e18744cca1"
  echo "expected review-v4   b85572469b5ff5f59d552f29896d6af0f73591421a6e686161c0e2028e8cf262"
  echo "expected review-v3   1735cfc9b1067e6dc328f92a60c996af4033b5aa3f65efb73e017d4922b70951"
  echo "expected dossier-v3  d5861c5101cd065c0f544e19448d15fbc7a0968614b5ba70a8f579db4f975d7f"
  echo "expected review-v2   54419458d7501605416f71e54affe6a1f5090cdbff46aff90bbd6f87fdb74cc9"
  echo "expected dossier-v2  7cc27b0201c5b6ba13d01f05165ccd1439f7da11226c84092d02a49198f7f13a"
  ok=1
  [ "$(sha256sum DOSSIER-APOSTOL-v4.md | cut -d' ' -f1)" = "75f6aa332ac949dde87816f75b050ef2061aa8b671ff550a1dd284e18744cca1" ] || ok=0
  [ "$(sha256sum REVIEW-APOSTOL-v4.md | cut -d' ' -f1)" = "b85572469b5ff5f59d552f29896d6af0f73591421a6e686161c0e2028e8cf262" ] || ok=0
  [ "$(sha256sum REVIEW-APOSTOL-v3.md | cut -d' ' -f1)" = "1735cfc9b1067e6dc328f92a60c996af4033b5aa3f65efb73e017d4922b70951" ] || ok=0
  [ "$(sha256sum DOSSIER-APOSTOL-v3.md | cut -d' ' -f1)" = "d5861c5101cd065c0f544e19448d15fbc7a0968614b5ba70a8f579db4f975d7f" ] || ok=0
  [ "$(sha256sum REVIEW-APOSTOL-v2.md | cut -d' ' -f1)" = "54419458d7501605416f71e54affe6a1f5090cdbff46aff90bbd6f87fdb74cc9" ] || ok=0
  [ "$(sha256sum DOSSIER-APOSTOL-v2.md | cut -d' ' -f1)" = "7cc27b0201c5b6ba13d01f05165ccd1439f7da11226c84092d02a49198f7f13a" ] || ok=0
  if [ "$ok" = "0" ]; then echo "INPUT_SHA_MISMATCH"; exit 3; fi
  echo "INPUT_SHA_OK"
} 2>&1 | tee -a "$LOG"
[ "${PIPESTATUS[0]}" = "0" ] || exit 3
# --- Verify evidence manifests (informational counts; the lane adjudicates) ---
{
  echo "MANIFEST_START $(date -u +%Y-%m-%dT%H:%M:%SZ)"
  for d in evidence-v4 evidence-v3; do
    if [ -f "$d/MANIFEST.txt" ] && [ -f check-manifest.py ]; then
      echo "--- $d"
      python3 check-manifest.py "$d" 2>&1 | tail -3
    else
      echo "MANIFEST_MISSING: $d/MANIFEST.txt or check-manifest.py"
    fi
  done
  echo "MANIFEST_END $(date -u +%Y-%m-%dT%H:%M:%SZ)"
} 2>&1 | tee -a "$LOG"
# --- Start the interactive Carbon session in tmux; brief delivered as a file ---
if tmux has-session -t "$SESSION" 2>/dev/null; then
  echo "SESSION_EXISTS: $SESSION already running; not launching a second lane" | tee -a "$LOG"
  exit 4
fi
tmux new-session -d -s "$SESSION" -c "$TASKDIR" "agy --model gemini-4-carbon-high --effort high --dangerously-skip-permissions" 2>&1 | tee -a "$LOG"
# Wait for agy to come up (its pane shows the model name), then hand it the brief.
ready=0
for i in $(seq 1 18); do
  sleep 5
  if tmux capture-pane -t "$SESSION" -p 2>/dev/null | grep -q "Gemini 4 Carbon"; then ready=1; break; fi
done
echo "AGY_READY=$ready after ${i}x5s" | tee -a "$LOG"
tmux send-keys -t "$SESSION" -l "Read BRIEF.md in this directory and execute the task in it in full. Work in this directory. Write DOSSIER-APOSTOL-v5.md incrementally as you verify each section, ending with the line DOSSIER COMPLETE. When done, print DOSSIER_DONE as the last line of your session output."
tmux send-keys -t "$SESSION" Enter
sleep 15
# Receipt verification: the session must show it is working on BRIEF.md.
# The banner can eat the first send-keys - re-send once (after Escape) if no receipt.
if tmux capture-pane -t "$SESSION" -p 2>/dev/null | grep -qiE "BRIEF|Apostol|thinking|Thought"; then
  echo "RECEIPT_OK" | tee -a "$LOG"
else
  echo "RECEIPT_MISSING: re-sending brief instruction once" | tee -a "$LOG"
  tmux send-keys -t "$SESSION" Escape
  sleep 2
  tmux send-keys -t "$SESSION" -l "Read BRIEF.md in this directory and execute the task in it in full. Work in this directory. Write DOSSIER-APOSTOL-v5.md incrementally as you verify each section, ending with the line DOSSIER COMPLETE. When done, print DOSSIER_DONE as the last line of your session output."
  tmux send-keys -t "$SESSION" Enter
  sleep 15
  tmux capture-pane -t "$SESSION" -p 2>&1 | tail -12 | tee -a "$LOG"
fi
tmux capture-pane -t "$SESSION" -p 2>&1 | tail -12 | tee -a "$LOG"
echo "LAUNCH_DONE $(date -u +%Y-%m-%dT%H:%M:%SZ)" | tee -a "$LOG"
