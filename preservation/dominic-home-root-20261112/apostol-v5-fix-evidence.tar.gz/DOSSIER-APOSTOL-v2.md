# DOSSIER-APOSTOL-v2 — T. M. Apostol, *Introduction to Analytic Number Theory* (Springer UTM, 1976): repaired dossier

**Task:** formalize-everything #67, math programme research rotation (GLM 5.3 stream) — **fix lane**.
**Author:** GLM 5.3 lane, pi harness, on `dominic`, 2026-11-10 (evening pass).
**What this file is:** the repair of `DOSSIER-APOSTOL.md` (v1, 624 lines, sha256 `93a491f62af895684b281ab372a6e3173c327fb9c55d8f70317327cf7d158da1`), carried out against the crossed-review verdict **FAIL** (`REVIEW-APOSTOL.md`, 180 lines, sha256 `29c42b7f803ae8599a94463f2e2b938c6534da852d9d2cf471ed61ba3e39d882`, gpt-6-astra/ultra, 2026-11-10) and its corrections C1–C12. v1 is retained unmodified in this directory. Every item v1 got right and the review confirmed is retained; every item the review refuted is retracted or repaired here; §8 maps C1–C12 to the repairing sections.
**Status:** research input only. This dossier authorizes no proof lane. A proof lane needs its own frozen pin manifest and coordinator-appointed crossed review. This repaired dossier itself needs a renewed coordinator-appointed crossed review before any pinning use.
**Evidence discipline of this pass:** every live check below was made **2026-11-10 (≈18:05–18:35 UTC)** by this lane, with `curl -L` and authenticated `gh api`/`gh search`; the raw artifacts are shipped in `prefetch-v2/` with a per-file sha256 `MANIFEST.txt` (183 files; the 20 Formalpedia shards re-downloaded fresh and byte-identical to the morning cache). A claim this pass could not verify is marked **UNVERIFIED**; a bounded negative is stated with exactly the searches that were run. Springer's site served a bot-challenge page to this pass (3,038-byte HTML for both the book page and the front-matter PDF) — v1's Springer-verified chapter table is carried with that provenance and could not be re-verified today.

---

## §0 Executive summary (revised — supersedes v1 §0)

1. **The book is open as a whole-book Lean project, and NOT open chapter-by-chapter.** No complete fourteen-chapter Apostol project was identified in the searches run (v1's searches + the crossed review's + this pass's fresh GitHub searches: repo search `Apostol language:Lean` → 0; code search `Apostol language:lean` → 25 hits, none a book project; Isabelle code search → 98 hits, dominated by an AFP mirror; Coq code search → 3 irrelevant hits; Palomar, Formalpedia, salt, atlas, TauCeti, ReasBook, lean-pool, Freek-100 as recorded in §3). But chapter formalizations **do exist**: AFP `Gauss_Sums` is "a full formalisation of Chapter 8" (entry abstract, verified this pass), and AFP `Prime_Distribution_Elementary` "is a formalisation of Chapter 4 (and parts of Chapter 3)" (entry abstract, verified this pass). v1's "no repo, branch, or Palomar entry formalizes the book **or any chapter of it**" is **retracted** (review C8).
2. **The Selberg retraction (review C2, blocking).** v1's claim that Selberg's asymptotic formula is "OPEN in every assistant checked" with "no blueprint to port from" is **false and retracted**. First-hand this pass: AFP `Prime_Distribution_Elementary/Selberg_Asymptotic_Formula.thy` labels its inversion development `(* 4.17 *)` and proves `theorem selberg_asymptotic_formula` `(* 4.18 *)` — ψ(x)·ln x + Σ_{n≤x} Λ(n)ψ(x/n) = 2x·ln x + O(x) — "Following Apostol"; and Metamath `selberg` (us.metamath.org/mpeuni/selberg.html, contributed by Mario Carneiro 2016-05-23) proves the equivalent symmetry form, citing Shapiro Eq. 10.4.10 p. 419; Avigad–Donnelly–Gray–Raff's verified elementary Selberg proof (arXiv:cs/0509025v3 §§3.1–3.2, per the review) is further prior art. The **pointwise** Ch. 2 Selberg identity (v1's Thm ⚠2.20) was **not located as a separate declaration** in any of these; its claimed global absence remains **UNVERIFIED** and must not be asserted.
3. **The false formulas are repaired (review C1, blocking).** The σ_α product, Euler's summation formula endpoint signs, the Bell-series recovery statement, and the Ch. 11 coefficient integral are restated completely and correctly in §2 (each with its counterexample and independent corroboration). The repaired Euler summation is corroborated declaration-level by `girving/interval`'s `sum_Ioc_eq_integral_add_of_hasDerivWithinAt` specialized to p = 1.
4. **Coverage is rebuilt from individually verified nodes only (review C4/C11).** v1's "≈62% of 315 nodes", "≈74% (232/314)", "~60% upstream-only" and "≈90% with cross-assistant prior art" are **withdrawn** — none had a reproducible numerator. The auditable result of this pass: **61/318 nodes (19.2%) are verified covered in Lean** (58 upstream Mathlib [M] + 3 external Lean [E], each with file + declaration named in §4), **68/318 (21.4%) verified covered in any assistant** (adding 7 cross-assistant [X] declarations), plus a further tier of AFP entries whose abstracts state precise coverage of book content but which were **not** node-verified (listed, not counted). This is a verified **lower bound**, not "the" coverage; the true figure is UNVERIFIED above it. v1's per-chapter percentages were topic-blended estimates and do not reappear.
5. **The node ledger is reconciled to one method and one total (review C3/C5).** v1's table summed to 314 while §0 said 315, Ch. 5 labelled D5.1–D5.7 while counting six, and Ch. 12 labelled 12.1–12.20 while counting eighteen. The v2 ledger counts every enumerated node individually under one convention: **318 provisional nodes = 70 definitions + 248 theorem/lemma statement-nodes**, every number ⚠-provisional pending pinning against the physical printing. Only three book numbers are treated as verified ([V]): **Thm 4.10** (Mertens I — Formalpedia record `d09af852-f479-4509-a198-8f0ba56f9115`, shard index-004.jsonl:3080, now fully sourced), **Thm 13.15** (Pólya–Vinogradov — AFP `Polya_Vinogradov.thy` l. 813 "Theorem 13.15"), **Thm 14.5** (upper bound for p(n) — AFP `Pentagonal_Number_Theorem.thy` l. 400/405/424).
6. **Revised recommendation (review C12; full statement in §6).** On the repaired evidence, Apostol is **not** the pick if the programme wants maximal new-to-every-assistant mathematics: the analytic crown is substantially formalized in Isabelle (Perron incl. an effective form, PNT with explicit remainder and a zero-free region, the full Ch. 8 incl. Pólya–Vinogradov, the Ch. 14 chain JTP → pentagonal → p(n)-recurrence → van Lint bound → Rademacher, Dirichlet's theorem, Mertens I & II, Selberg's asymptotic formula), and the Lean-side remainder is mostly port-with-blueprint work. A conditional pick remains defensible **as a statement-complete, import-first integration project** with the two carve-outs (statement-fidelity vs Ch. 12–13 proof routes; frozen external commits + license rulings) and with an explicit Ch. 14 decision: the pin for Jacobi's triple product should be the **analytic identity as printed** (|x| < 1, y ≠ 0) — v1's schedule claim of "no analysis prerequisites" for Ch. 14 is **retracted**; the convergence transfer (infinite sums/products, |x| < 1, y ≠ 0) is a real prerequisite, and AFP's own route (restrict-then-analytic-continuation, plus a separate fps version for pentagonal) is the blueprint. This recommendation is **conditional and not self-executing**: the fourth-slot decision belongs to the coordinator on the repaired evidence and the renewed crossed review.

**Not established by this dossier (explicitly):** the printed-book node count (every count is provisional ⚠); per-node coverage above the verified 68; the global absence of the pointwise Selberg identity, of index calculus, of the Ramanujan partition congruences, or of any named statement not listed with a search in §3/§4; any dependency-closure or sorry-free audit beyond the files actually fetched and grepped this pass; any legal ruling on the atlas license.

---

## §1 The book, its edition, and the numbering discipline

**Edition.** Tom M. Apostol, *Introduction to Analytic Number Theory*, Undergraduate Texts in Mathematics, Springer, first published 1976; the pagination used throughout is that of the SpringerLink ebook / 1998 softcover reissue (DOI 10.1007/978-1-4757-5579-4), as selected and verified by v1 (live check 2026-11-10, morning pass, front matter `bfm:978-1-4757-5579-4/1.pdf`). This pass's re-fetch of that page and PDF returned a 3,038-byte bot-challenge HTML from Springer, so the table below is **carried from v1's verified capture** and marked as such; it is consistent with the AFP theory files, which cite chapter/theorem numbers in agreement with it (13.15, 14.5, 4.10, 4.17/4.18, §4.6).

| Ch. | Title | Pages | Sections |
|---|---|---|---|
| — | Historical Introduction | 1–12 | — |
| 1 | The Fundamental Theorem of Arithmetic | 13–23 | 1.1–1.8 |
| 2 | Arithmetical Functions and Dirichlet Multiplication | 24–51 | 2.1–2.19 |
| 3 | Averages of Arithmetical Functions | 52–73 | 3.1–3.12 |
| 4 | Some Elementary Theorems on the Distribution of Prime Numbers | 74–105 | 4.1–4.11 |
| 5 | Congruences | 106–128 | 5.1–5.11 |
| 6 | Finite Abelian Groups and Their Characters | 129–145 | 6.1–6.10 |
| 7 | Dirichlet's Theorem on Primes in Arithmetic Progressions | 146–156 | 7.1–7.9 |
| 8 | Periodic Arithmetical Functions and Gauss Sums | 157–177 | 8.1–8.12 |
| 9 | Quadratic Residues and the Quadratic Reciprocity Law | 178–203 | 9.1–9.11 |
| 10 | Primitive Roots | 204–223 | 10.1–10.13 |
| 11 | Dirichlet Series and Euler Products | 224–248 | 11.1–11.12 |
| 12 | The Functions ζ(s) and L(s, χ) | 249–277 | 12.1–12.16 |
| 13 | Analytic Proof of the Prime Number Theorem | 278–303 | 13.1–13.12 |
| 14 | Partitions | 304–328 | 14.1–14.11 |
| — | Bibliography / Index | 329–340 | — |

**Numbering discipline (review C5).** Every node carries a **neutral provisional ID** `A<ch>.<seq>` (D-prefix for definitions, T-prefix for theorem/lemma statement-nodes; seq ordered as enumerated within the chapter). The book's own number, where v1 reconstructed one, appears as `⚠<book no.>` — the ⚠ marks a reconstruction that MUST be re-pinned against the physical printing before any frozen pin manifest, and it travels with the number in **every** cross-reference in this dossier. Three book numbers are **verified anchors [V]** (source named at the node): **4.10**, **13.15**, **14.5**. Because printed 13.15 is Pólya–Vinogradov [V], v1's reconstructed Ch. 13 numbering that assigned 13.15–13.16 to the zero-free region is **wrong from 13.15 onward**; the v2 ledger keeps the content nodes and marks their book numbers as "⚠ ≥ 13.16, shifted" (no collision with the verified 13.15).

**Counting convention and the reconciled total (review C3).** A node = one numbered definition/theorem/lemma/corollary as printed, with the caveat that several Ch. 1/5 definitions are unnumbered in the text and are counted as provisional nodes anyway (flagged at the node). v1's running table summed to 69 D + 245 T = 314 while v1 §0 said 315; Ch. 5 listed seven definitions (D5.1–D5.7) but counted six; Ch. 12 labelled theorems up to 12.20 but counted eighteen. v2 applies one method — count every enumerated item individually — which resolves all three: Ch. 5 has **7** definitions, Ch. 12 has **20** theorem-nodes, Ch. 13 has **20** theorem-nodes (19 content nodes + the [V] Pólya–Vinogradov node, which v1 double-booked). The reconciled ledger:

| Ch. | Definitions | Thm/Lem nodes | Chapter total | Running total |
|---|---:|---:|---:|---:|
| 1 | 3 | 14 | 17 | 17 |
| 2 | 14 | 20 | 34 | 51 |
| 3 | 3 | 13 | 16 | 67 |
| 4 | 5 | 17 | 22 | 89 |
| 5 | 7 | 20 | 27 | 116 |
| 6 | 6 | 17 | 23 | 139 |
| 7 | 1 | 9 | 10 | 149 |
| 8 | 8 | 22 | 30 | 179 |
| 9 | 5 | 26 | 31 | 210 |
| 10 | 3 | 21 | 24 | 234 |
| 11 | 4 | 18 | 22 | 256 |
| 12 | 5 | 20 | 25 | 281 |
| 13 | 1 | 20 | 21 | 302 |
| 14 | 5 | 11 | 16 | 318 |

**Total: 318 provisional nodes (70 D + 248 T), all ⚠.** The printed-book count remains UNVERIFIED; the pinning pass against the physical book is mandatory and may split/merge items. v1's 314 and 315 were both artifacts of inconsistent counting, not book counts.

---

## §2 Chapter-by-chapter statement ledger (repaired)

Statements are faithful paraphrases with exact hypotheses; repaired statements (C1) are marked **[REPAIRED]** with their checking counterexample; rows that remain sketches are marked **UNFINISHED — research reminder, not a pinnable statement** (review C1's rule). Book numbers are ⚠ unless [V].

### Chapter 1 — The Fundamental Theorem of Arithmetic (pp. 13–23 ⚠carried)

**Definitions (3):** AD1.1 divisibility d | n (§1.2; unnumbered in text); AD1.2 greatest common divisor (§1.3; unnumbered); AD1.3 prime — n > 1 whose only divisors are 1 and n (§1.4; unnumbered). *(all three flagged: counted although unnumbered as printed)*

**Theorems (14):**
- AT1.1 ⚠1.1 (§1.2) Division algorithm: for b > 0 and any integer a there exist unique q, r with a = qb + r, 0 ≤ r < b.
- AT1.2 ⚠1.2 (§1.3): (a,b) exists and is the least positive member of {ax + by}; every common divisor divides (a,b).
- AT1.3 ⚠1.3 (§1.3) Euclid's lemma: d | ab and (d,a) = 1 ⇒ d | b.
- AT1.4 ⚠1.4 (§1.4): p | ab ⇒ p | a or p | b; p | a₁⋯aₙ ⇒ p | aᵢ for some i.
- AT1.5–AT1.6 ⚠1.5–1.6 (§1.5) **FTA**: every n > 1 is a product of primes; the factorization is unique up to order (n = ∏ p^{a_p}; p^a ∥ n well-defined).
- AT1.7 ⚠1.7 (§1.5) **Euclid**: infinitely many primes.
- AT1.8 ⚠1.8 (§1.4/1.5): every composite n has a prime divisor ≤ √n.
- AT1.9 ⚠1.9 (§1.6): sieve of Eratosthenes correctness (procedure node; unnumbered as a theorem ⚠).
- AT1.10 ⚠1.10 (§1.6) **Σ 1/p diverges** (Euler/Apostol Ch. 1 route; restated Ch. 4 §4.8).
- AT1.11–AT1.13 ⚠1.11–1.13 (§1.7) Euclidean algorithm: termination; last nonzero remainder = (a,b); back-substitution (a,b) = ax + by.
- AT1.14 ⚠1.14 (§1.8): gcd of several numbers; common-divisor characterization.

**Dependencies:** none. **Node count 17** (3 D + 14 T, all counted provisionally).

### Chapter 2 — Arithmetical Functions and Dirichlet Multiplication (pp. 24–51 ⚠carried)

**Definitions (14):** AD2.1 arithmetical function (§2.1); AD2.2 Möbius μ (§2.2); AD2.3 Euler totient φ (§2.3); AD2.4 Dirichlet product/convolution (§2.6); AD2.5 identity I(n) = [n=1] (§2.6); AD2.6 Dirichlet inverse (§2.7); AD2.7 von Mangoldt Λ (§2.8); AD2.8 multiplicative function (§2.9); AD2.9 completely multiplicative (§2.9); AD2.10 Liouville λ (§2.12); AD2.11 σ_α and d = σ₀ (§2.13); AD2.12 generalized convolution / partial sums (§2.14); AD2.13 Bell series (§2.15–2.16); AD2.14 derivative f′(n) = f(n) log n (§2.18).

**Theorems (20):**
- AT2.1 ⚠2.1 (§2.2): Σ_{d|n} μ(d) = [n=1].
- AT2.2 ⚠2.2 (§2.4): φ(n) = n Σ_{d|n} μ(d)/d.
- AT2.3 ⚠2.3 (§2.4): Σ_{d|n} φ(d) = n.
- AT2.4 ⚠2.4 (§2.5): φ(n) = n ∏_{p|n} (1 − 1/p).
- AT2.5 ⚠2.5 (§2.6): arithmetical functions form a commutative ring-like structure under + and ∗ with I as ∗-unit.
- AT2.6 ⚠2.6 (§2.7): f has a Dirichlet inverse iff f(1) ≠ 0.
- AT2.7 ⚠2.7 (§2.7) **Möbius inversion**: f = g ∗ 1 ⇔ g = f ∗ μ.
- AT2.8 ⚠2.8 (§2.8): Λ = μ ∗ log; equivalently Σ_{d|n} Λ(d) = log n.
- AT2.9–AT2.11 ⚠2.9–2.11 (§2.9–2.10): f, g multiplicative ⇒ f∗g multiplicative; multiplicativity of Σ_{d|n} f(d); a multiplicative function is determined by its prime-power values.
- AT2.12 ⚠2.12 (§2.11): completely multiplicative f has Dirichlet inverse μf.
- AT2.13 ⚠2.13 (§2.12): Σ_{d|n} λ(d) = [n is a square].
- AT2.14 ⚠2.14 (§2.13) **[REPAIRED — review C1(a)].** σ_α is multiplicative, and for n = ∏_{p^a ∥ n} (a ≥ 1):
  **σ_α(n) = ∏_{p^a ∥ n} σ_α(p^a), where σ_α(p^a) = Σ_{k=0}^{a} p^{αk} = (p^{α(a+1)} − 1)/(p^α − 1) if p^α ≠ 1, and σ_α(p^a) = a + 1 if p^α = 1 (i.e. α = 0, giving d(p^a) = a+1).**
  The geometric-series denominator is **p^α − 1**; the only exceptional case is p^α = 1 (α = 0) — the α ≠ −1 exclusion in v1's formula was spurious (α = −1 is fine: σ_{−1}(p^a) = (1 − p^{−(a+1)})/(1 − p^{−1})), and indeed σ_{−1}(n) = σ₁(n)/n. Check: n = 2, α = 1 gives σ₁(2) = 1+2 = 3 = (2²−1)/(2−1) ✓; v1's denominator p^{α+1}−1 gave 1 ✗ (the review's counterexample). Note: Mathlib already has this node at declaration level — `ArithmeticFunction.sigma_apply_prime_pow` in `Mathlib/NumberTheory/ArithmeticFunction/Misc.lean` at M (§4).
- AT2.15 ⚠2.15 (§2.14): Fubini-type interchange identities for generalized convolutions.
- AT2.16 ⚠2.16 (§2.15): formal power series over arithmetical functions; uniqueness of coefficients.
- AT2.17–AT2.18 ⚠2.17–2.18 (§2.16–2.17) **[REPAIRED — review C1(c)].** Bell series. For any arithmetical f and prime p, the Bell series is f_p(x) = Σ_{k≥0} f(p^k) x^k (a formal power series in x).
  **(i) Recovery with multiplicativity hypotheses:** if f and g are **multiplicative**, then f = g ⇔ f_p(x) = g_p(x) for every prime p (⇔ f(p^k) = g(p^k) for all p, k ≥ 0). Multiplicativity of both sides is essential: f ≡ 1 and g = f except g(6) = 2 agree at 1 and at every prime power, hence have identical Bell series at every prime, yet f ≠ g (the review's counterexample) — so the bare v1 statement "f = g ⇔ equal Bell series at every prime" is false without it.
  **(ii) Completely multiplicative case:** f completely multiplicative ⇒ f_p(x) = 1/(1 − f(p) x).
  **(iii) Convolution rule (no hypothesis):** (f∗g)_p(x) = f_p(x)·g_p(x) for arbitrary f, g, since (f∗g)(p^k) = Σ_{j=0}^{k} f(p^j) g(p^{k−j}) — a Cauchy product.
  **(iv) Standard series:** μ_p(x) = 1 − x; Λ_p(x) = (log p)·x/(1−x); λ_p(x) = 1/(1+x); σ_α,p(x) = 1/((1−x)(1−p^α x)); and the totient:
  **φ_p(x) = 1 + Σ_{k≥1} (p^k − p^{k−1}) x^k = (1 − x)/(1 − p x)** (convergent for |x| < 1/p; x-coefficient p − 1 = φ(p), which v1's garbled "(1−x)(1−p^{−1}x)^{−1}-type" form got wrong).
- AT2.19 ⚠2.19 (§2.18): derivative Leibniz rules (f∗g)′ = f′∗g + f∗g′; relations with Λ for multiplicative f.
- AT2.20 ⚠2.20 (§2.19) **Selberg identity (pointwise form):** Λ(n) log n + Σ_{d|n} Λ(d)Λ(n/d) = Σ_{d|n} μ(d) log²(n/d). **Status: OPEN in Lean within this pass's searches; presence/absence in other assistants UNVERIFIED** — the asymptotic form is formalized (AFP 4.18, Metamath `selberg`) but those are different statements; do not conflate (see §3.5, §5.6).

**Dependencies:** Ch. 1. **Node count 34** (14 D + 20 T).

### Chapter 3 — Averages of Arithmetical Functions (pp. 52–73 ⚠carried)

**Definitions (3):** AD3.1 O/Ω/Θ/o-notation, asymptotic equivalence (§3.2); AD3.2 fractional part ψ(x) = x − ⌊x⌋ (§3.3); AD3.3 average order (§3.5 ff.).

**Theorems (13):**
- AT3.1 ⚠3.1 (§3.3) **Euler's summation formula [REPAIRED — review C1(b)].** If f has a continuous derivative f′ on [y, x] with 0 < y < x, then, with ψ(t) = t − ⌊t⌋:
  **Σ_{y<n≤x} f(n) = ∫_y^x f(t) dt + ∫_y^x ψ(t) f′(t) dt − f(x)ψ(x) + f(y)ψ(y).**
  The endpoint terms are **−f(x)ψ(x) + f(y)ψ(y)**; v1's "+f(x)ψ(x) − f(y)ψ(y)" is false (review counterexample: f ≡ 1, y = 1, x = 3/2 — no integers in (1, 3/2], LHS = 0; v1's RHS = 1/2 + 0 + 1/2 − 0 = 1; corrected RHS = 1/2 + 0 − 1/2 + 0 = 0 ✓). Independent corroboration (declaration-level, this pass): `girving/interval` commit `2c89204b806f4acd9b8530a38e656369d0a4d7f3` (2026-10-14), `Interval/EulerMaclaurin/Formula.lean`, theorem `sum_Ioc_eq_integral_add_of_hasDerivWithinAt` — for p = 1 its endpoint term is (−1)^{0+1}/1!·(P₁(b)f(b) − P₁(a)f(a)) = **−f(b)ψ(b) + f(a)ψ(a)** with P₁ = periodized Bernoulli B₁ = t − ⌊t⌋, and its sum ranges over the integers in (a, b] — exactly the corrected signs.
- AT3.2 ⚠3.2 (§3.4): Σ_{n≤x} 1/n = log x + γ + O(1/x).
- AT3.3 ⚠3.3 (§3.4): Σ_{n≤x} n^α = x^{α+1}/(α+1) + O(x^α) (α ≥ 0); companion Σ_{n≤x} log n = x log x − x + O(log x).
- AT3.4 ⚠3.4 (§3.5) **Dirichlet hyperbola**: Σ_{n≤x} d(n) = x log x + (2γ−1)x + O(√x).
- AT3.5 ⚠3.5 (§3.6): Σ_{n≤x} σ_α(n) = ζ(α+1)x^{α+1}/(α+1) + O(x^β), α > 0, β = max(1,α); companion for σ_{−α}, 0 < α < 1.
- AT3.6 ⚠3.6 (§3.7): Σ_{n≤x} φ(n) = 3x²/π² + O(x log x).
- AT3.7 ⚠3.7 (§3.8): two random integers coprime with probability 6/π² (visible lattice points).
- AT3.8–AT3.9 ⚠3.8–3.9 (§3.9): Σ_{n≤x} μ²(n) = x/ζ(2) + O(√x); trivial bounds on M(x) = Σ_{n≤x} μ(n).
- AT3.10–AT3.12 ⚠3.10–3.12 (§3.10–3.11): partial sums of Dirichlet products — Σ_{n≤x}(f∗g)(n) = Σ_{a≤x} g(a) Σ_{m≤x/a} f(m) = Σ_{ab≤x} f(a)g(b), and the companion identity.
- AT3.13 ⚠3.13 (§3.12): the hyperbola-symmetric form used to re-derive Σ d(n).

**Dependencies:** Ch. 1–2; elementary real analysis. **Node count 16** (3 D + 13 T).

### Chapter 4 — Some Elementary Theorems on the Distribution of Prime Numbers (pp. 74–105 ⚠carried)

**Definitions (5):** AD4.1 Chebyshev ψ(x) = Σ_{n≤x} Λ(n) and θ(x) = Σ_{p≤x} log p (§4.2); AD4.2 π(x) (§4.1); AD4.3 the n-th prime p_n (§4.5); AD4.4 Mertens' constant B (§4.8); AD4.5 M(x) = Σ_{n≤x} μ(n) (§4.9).

**Theorems (17):**
- AT4.1 ⚠4.1 (§4.2): ψ(x) = Σ_{m≥1} θ(x^{1/m}); ψ − θ bridging bound.
- AT4.2 ⚠4.2 (§4.2): log⌊x⌋! = Σ_{p^k ≤ x} ⌊x/p^k⌋ log p; Legendre's factorial formula.
- AT4.3 ⚠4.3 (§4.3) **Abel/partial summation**: A(x) = Σ_{n≤x} a(n) ⇒ Σ_{n≤x} a(n)f(n) = A(x)f(x) − ∫₁^x A(t)f′(t)dt for C¹ f, with the π/θ conversions.
- AT4.4–AT4.5 ⚠4.4–4.5 (§4.4): PNT equivalences (π(x) ~ x/log x ⇔ ψ(x) ~ x ⇔ θ(x) ~ x ⇔ p_n ~ n log n ⇔ π(x) ~ Li(x)).
- AT4.6–AT4.7 ⚠4.6–4.7 (§4.5) **Chebyshev's bounds**: c₁x/log x ≤ π(x) ≤ c₂x/log x via binomial middle terms; Bertrand-type existence (for every n a prime in (n, 2n]); ψ(x) = O(x).
- AT4.8 ⚠4.8 (§4.6) **Shapiro's Tauberian theorem [COMPLETED — was an unfinished sketch in v1].** Sourced formal statement (AFP `Prime_Distribution_Elementary/Shapiro_Tauberian.thy`, "Shapiro's Tauberian theorem (see Section 4.6 of Apostol's Introduction to Analytic Number Theory)", verified this pass): if a(n) ≥ 0 for n > 0 and T(x) = Σ_{n≤x} a(n)⌊x/n⌋ satisfies T(x) = x ln x + O(x), then:
  (i) Σ_{n≤x} a(n)/n = ln x + O(1);
  (ii) ∃B ≥ 0 ∀x ≥ 0: Σ_{n≤x} a(n) ≤ Bx;
  (iii) ∃C > 0 ∀x ≥ 1/C: Σ_{n≤x} a(n) ≥ Cx; equivalently Σ_{n≤x} a(n) ∈ Θ(x).
  (The book's own printed constants/hypothesis phrasing remain ⚠ pending pinning; the statement above is complete and proved in AFP following the book's §4.6.)
- AT4.9 ⚠4.9 (§4.7): Σ_{n≤x} Λ(n)/n = log x + O(1) (via Shapiro).
- AT4.10 **4.10 [V]** (§4.7) **Mertens' first theorem (1874)**: Σ_{p≤x} log p / p = log x + O(1). *Anchor: Formalpedia record `d09af852-f479-4509-a198-8f0ba56f9115`, shard `envs/0df444a/index-004.jsonl` line 3080, theorem_name `MertensTheorems.sum_log_div_prime_le`, title "Mertens' first theorem, with explicit constant", status Proved, author @cm_beta, created 2026-09-21, source citing "Apostol, Introduction to Analytic Number Theory, Theorem 4.10" with the Lean proof extracted from `Salt/Maynard/Mertens.lean`; statement file `envs/0df444a/Theorems/Thm_MertensTheorems_sum_log_div_prime_le.lean`. This resolves review C7's demand for the actual record.*
- AT4.11–AT4.12 ⚠4.11–4.12 (§4.8) **Mertens' second theorem**: Σ_{p≤x} 1/p = log log x + B + O(1/log x); corollary ∏_{p≤x}(1−1/p) ~ e^{−B}/log x. (Covered in AFP `Prime_Number_Theorem` per its abstract, which states both Mertens theorems with formulas — ABSTRACT tier, §4.)
- AT4.13 ⚠4.13 (§4.9): Σ_{n≤x} μ(n)/n = O(1); PNT-equivalence discussion.
- AT4.14–AT4.16 ⚠4.14–4.16 (§4.10): the Selberg-method lemma development. **UNFINISHED — research reminder:** v1's sketch did not state the three lemmas with hypotheses; complete at pin time from the printing (blueprint now exists: AFP `Selberg_Asymptotic_Formula.thy`'s `(* 4.17 *)`-labelled inversion development).
- AT4.17 ⚠4.17 (§4.11) **Selberg's asymptotic formula**: Σ_{n≤x} Λ(n) log n + Σ_{mn≤x} Λ(m)Λ(n) = 2x log x + O(x). **NOT open** (review C2): AFP `(* 4.18 *) theorem selberg_asymptotic_formula` proves the equivalent form ψ(x)·ln x + Σ_{n≤x}Λ(n)ψ(x/n) =o 2x·ln x + O(x) following Apostol, and Metamath `selberg` proves the same asymptotic symmetry form (Shapiro 10.4.10). A Lean proof would be a **port with blueprint**, not new-to-every-assistant mathematics.

**Dependencies:** Ch. 1–3. **Node count 22** (5 D + 17 T).

### Chapter 5 — Congruences (pp. 106–128 ⚠carried)

**Definitions (7 — v1's table said 6 while labelling D5.1–D5.7; the seven labels are kept, resolving the review's C3 flag; all unnumbered-as-printed ⚠):** AD5.1 congruence a ≡ b (mod m) (§5.1); AD5.2 residue classes / complete residue system (§5.2); AD5.3 polynomial congruence (§5.1/5.5); AD5.4 reduced residue system (§5.4); AD5.5 linear congruence (§5.3); AD5.6 cross-classification (§5.10); AD5.7 polynomial degree mod m (§5.5 — weakest node; may merge with AD5.3 at pin time).

**Theorems (20):** AT5.1–AT5.3 ⚠5.1–5.3 equivalence-relation + arithmetic compatibility + cancellation laws; AT5.4 ⚠5.4 ℤ/mℤ ring structure; AT5.5–AT5.6 ⚠5.5–5.6 linear congruences (ax ≡ b (mod m) solvable iff (a,m) | b, then exactly (a,m) classes); AT5.7–AT5.8 ⚠5.7–5.8 Euler–Fermat a^{φ(m)} ≡ 1 (mod m) for (a,m)=1 (Fermat as corollary); AT5.9 ⚠5.9 **Lagrange**: degree-n polynomial congruence mod p with p ∤ leading coefficient has ≤ n incongruent solutions; AT5.10–AT5.11 ⚠5.10–5.11 applications (x² ≡ 1; Wilson (p−1)! ≡ −1 (mod p)); AT5.12–AT5.13 ⚠5.12–5.13 CRT (pairwise-coprime and general-compatibility forms); AT5.14–AT5.15 ⚠5.14–5.15 composite-modulus decomposition; AT5.16–AT5.18 ⚠5.16–5.18 prime-power lifting (Hensel-type); AT5.19 ⚠5.19 cross-classification principle; AT5.20 ⚠5.20 RRS tensor decomposition and φ-multiplicativity.

**Dependencies:** Ch. 1–2. **Node count 27** (7 D + 20 T).

### Chapter 6 — Finite Abelian Groups and Their Characters (pp. 129–145 ⚠carried)

**Definitions (6):** AD6.1 abelian group/subgroup; AD6.2 character χ: G → ℂ*; AD6.3 character group Ĝ; AD6.4 principal character; AD6.5 Dirichlet character mod k; AD6.6 real (quadratic-type) character.

**Theorems (17):** AT6.1–AT6.3 ⚠6.1–6.3 elementary group facts; AT6.4 ⚠6.4 subgroups of every order dividing |G|; AT6.5 ⚠6.5 characters beyond the principal; AT6.6 ⚠6.6 the character group, |Ḡ| = |G|; AT6.7–AT6.9 ⚠6.7–6.9 **orthogonality** (Σ_{x∈G} χ(x) = |G|[χ=χ₀] else 0; Σ_{χ} χ(x) = |G|[x=e] else 0); AT6.10–AT6.11 ⚠6.10–6.11 Dirichlet characters form a group ≅ character group of RRS, φ(k) of them; AT6.12–AT6.14 ⚠6.12–6.14 sums with Dirichlet characters; AT6.15–AT6.17 ⚠6.15–6.17 **L(1,χ) ≠ 0 for real non-principal χ by the elementary Ch. 6 proof** — the statement is upstream in stronger form (`LFunction_apply_one_ne_zero_of_quadratic`, M, §4); the book's elementary route is not (presentational gap only).

**Dependencies:** Ch. 5. **Node count 23** (6 D + 17 T).

### Chapter 7 — Dirichlet's Theorem on Primes in Arithmetic Progressions (pp. 146–156 ⚠carried)

**Definitions (1):** AD7.1 L(s,χ) = Σ χ(n)n^{−s} (introduced for s > 1; full theory deferred to Ch. 11–12).

**Theorems (9):** AT7.1 ⚠7.1 primes ≡ ±1 (mod 4) elementary; AT7.2–AT7.3 ⚠7.2–7.3 the plan: Dirichlet's theorem reduced to nonvanishing/divergence at s = 1; Lemma AT7.4 ⚠7.4 (§7.4) convergence/boundedness of Σ_p Σ_m χ(p)^m/(m p^s); Lemma AT7.5 ⚠7.5 (§7.5) log L(s,χ) convergence for χ ≠ χ₀; Lemma AT7.6 ⚠7.6 (§7.6) L(s,χ₀) ~ (φ(k)/k)·ζ(s)-type pole; Lemma AT7.7 ⚠7.7 (§7.8) nonvanishing L(1,χ) for complex χ; Lemma AT7.8 ⚠7.8 (§7.7) real-character case (from Ch. 6 §6.10); AT7.9 ⚠7.9 (§7.9) distribution of primes in AP: π(x;k,h) ~ (1/φ(k))·x/log x. *(v1's "100% of the main theorem" coverage claim for this chapter is withdrawn — only the infinitude statement is declaration-verified upstream; see §4.)*

**Dependencies:** Ch. 5–6, Ch. 4 partials. **Node count 10** (1 D + 9 T).

### Chapter 8 — Periodic Arithmetical Functions and Gauss Sums (pp. 157–177 ⚠carried)

**Definitions (8):** AD8.1 periodic arithmetical function; AD8.2 finite Fourier series; AD8.3 Ramanujan sum s_k(n); AD8.4 generalized sums s_k-family; AD8.5 Gauss sum G(n,χ); AD8.6 induced modulus; AD8.7 primitive character; AD8.8 conductor.

**Theorems (22):** AT8.1 ⚠8.1 minimal period/CRT decomposition; AT8.2–AT8.3 ⚠8.2–8.3 finite Fourier expansion + inversion; AT8.4–AT8.7 ⚠8.4–8.7 Ramanujan-sum evaluations s_k(n) = Σ_{d|(k,n)} dμ(k/d) = μ(k/(k,n))φ(k)/φ(k/(k,n)), integrality, Σ_{d|k} s_d(n) = [k|n], Ramanujan expansion; AT8.8–AT8.9 ⚠8.8–8.9 multiplicativity in k and n, Σ_{d|k}|s_d(n)|² = k(k,n); AT8.10–AT8.11 ⚠8.10–8.11 |G(n,χ)| = √k for (n,k)=1, separability; AT8.12–AT8.13 ⚠8.12–8.13 nonvanishing for primitive χ; AT8.14–AT8.15 ⚠8.14–8.15 induced-modulus criterion via Gauss-sum vanishing; AT8.16–AT8.17 ⚠8.16–8.17 induction and L-series factorization; AT8.18 ⚠8.18 unique primitive inducing character; AT8.19–AT8.20 ⚠8.19–8.20 primitive ⇒ separable, |G| = √k for all n; AT8.21 ⚠8.21 Fourier expansion of characters; AT8.22 ⚠8.22 Pólya's inequality for primitive χ (elementary bound; the sharp book form is printed as **Thm 13.15 [V]** — see Ch. 13).

**Dependencies:** Ch. 5–6, roots of unity, Ch. 2. **Node count 30** (8 D + 22 T). **This entire chapter is formalized in Isabelle** (AFP `Gauss_Sums`, "a full formalisation of Chapter 8", Dec 2019) — the strongest chapter-level prior art in the book.

### Chapter 9 — Quadratic Residues and the Quadratic Reciprocity Law (pp. 178–203 ⚠carried)

**Definitions (5):** AD9.1 quadratic residue/nonresidue; AD9.2 Legendre symbol (n|p); AD9.3 Euler's criterion (as statement); AD9.4 Jacobi symbol (n|P); AD9.5 quadratic Gauss sums G(n;m).

**Theorems (26):** AT9.1 ⚠9.1 half residues/half nonresidues; AT9.2–AT9.4 ⚠9.2–9.4 Legendre laws, Euler's criterion n^{(p−1)/2} ≡ (n|p), (−1|p); AT9.5–AT9.7 ⚠9.5–9.7 evaluation of (−1|p), (2|p); AT9.8–AT9.10 ⚠9.8–9.10 Gauss' lemma and counting; AT9.11 ⚠9.11 **quadratic reciprocity** (first proof); AT9.12–AT9.13 ⚠9.12–9.13 applications; AT9.14–AT9.16 ⚠9.14–9.16 Jacobi symbol laws + reciprocity + complementary laws; AT9.17–AT9.19 ⚠9.17–9.19 primes represented by x² + my² (incl. p = x² + y² iff p ≡ 1 (mod 4)); AT9.20–AT9.22 ⚠9.20–9.22 quadratic Gauss-sum evaluations, |G(1;p)| = √p; AT9.23–AT9.25 ⚠9.23–9.25 reciprocity for quadratic Gauss sums, G(1;m) evaluation; AT9.26 ⚠9.26 third proof of QR.

**Dependencies:** Ch. 5–6, Ch. 8. **Node count 31** (5 D + 26 T).

### Chapter 10 — Primitive Roots (pp. 204–223 ⚠carried)

**Definitions (3):** AD10.1 exponent/order of a mod m; AD10.2 primitive root (exponent φ(m)); AD10.3 index (discrete logarithm) ind_r a.

**Theorems (21):** AT10.1–AT10.2 ⚠10.1–10.2 order laws (ord a | φ(m); ord a^k = ord a/(k, ord a)); AT10.3 ⚠10.3 cyclic-structure characterization; AT10.4 ⚠10.4 **nonexistence mod 2^α** (α ≥ 3): a^{2^{α−2}} ≡ 1 (mod 2^α) for all odd a; AT10.5 ⚠10.5 existence mod p (φ(p−1) primitive roots); AT10.6 ⚠10.6 criterion g^{(p−1)/q} ≢ 1 for q | p−1; AT10.7–AT10.8 ⚠10.7–10.8 existence mod p^α (lifting); AT10.9 ⚠10.9 existence mod 2p^α; AT10.10 ⚠10.10 **classification: primitive roots exist exactly for m = 1, 2, 4, p^α, 2p^α**; AT10.11 ⚠10.11 φ(φ(m)) primitive roots when they exist; AT10.12–AT10.16 ⚠10.12–10.16 **index calculus** (ind laws; x^n ≡ a solvability criterion a^{(p−1)/d} ≡ 1, d = (n, p−1), with exactly d solutions; binomial-congruence tables); AT10.17–AT10.19 ⚠10.17–10.19 primitive roots ↔ Dirichlet characters (χ(g^k) = e^{2πirk/φ(p^α)}); AT10.20–AT10.21 ⚠10.20–10.21 primitive characters mod p^α, criterion p ∤ r. **Index calculus and the character-structure sections were not located in any assistant within the searches run — open-in-everything-checked is UNVERIFIED (bounded), open-in-Lean verified within this pass's searches.**

**Dependencies:** Ch. 5–6. **Node count 24** (3 D + 21 T).

### Chapter 11 — Dirichlet Series and Euler Products (pp. 224–248 ⚠carried)

**Definitions (4):** AD11.1 Dirichlet series F(s) = Σ f(n)n^{−s}; AD11.2 abscissae σ_a, σ_c; AD11.3 Euler product; AD11.4 formal ↔ analytic identification (under ∗).

**Theorems (18):**
- AT11.1 ⚠11.1 (§11.2): absolute convergence in half-planes σ ≥ σ₀+ε.
- AT11.2 ⚠11.2 (§11.2): half-plane of convergence σ > σ_c; σ_a − σ_c ≤ 1.
- AT11.3 ⚠11.3 (§11.3): analyticity in the open half-plane; termwise differentiation.
- AT11.4 ⚠11.4 (§11.4) **multiplication theorem**: series of f∗g = product of series.
- AT11.5–AT11.6 ⚠11.5–11.6 (§11.5) **Euler products**: f multiplicative ⇒ F(s) = ∏_p Σ_k f(p^k)p^{−ks}; f completely multiplicative ⇒ F(s) = ∏_p (1 − f(p)p^{−s})^{−1}; converses.
- AT11.7 ⚠11.7 (§11.6): exact half-plane of convergence; boundary behavior.
- AT11.8–AT11.9 ⚠11.8–11.9 (§11.7) analytic properties + **uniqueness** (equal sums on a half-plane ⇒ equal coefficients).
- AT11.10 ⚠11.10 (§11.8) **Landau**: f ≥ 0, convergence exactly for σ > σ_c ⇒ σ_c is a singularity.
- AT11.11–AT11.12 ⚠11.11–11.12 (§11.9) exponential representation (F = f(1)·exp(Σ P(p^m)p^{−ms}/m)-type; ζ = exp(Σ Λ(n)n^{−s}/log n)).
- AT11.13–AT11.15 ⚠11.13–11.15 (§11.10) mean-value / partial-sum formulas.
- AT11.16 ⚠11.16 (§11.11) **Coefficient extraction by vertical means [REPAIRED — review C1(d); v1's integral was an unusable placeholder].** Complete statement:
  **Let F(s) = Σ_{n≥1} f(n) n^{−s} be a Dirichlet series and let σ be a real point at which the series converges absolutely (i.e. σ > σ_a). Then for every n ≥ 1:**
  **f(n) = lim_{T→∞} (1/2T) ∫_{−T}^{T} F(σ + it) · n^{σ+it} dt.**
  The **averaging normalization 1/(2T)** is essential — the review's counterexample: for F ≡ 1 (so f(1) = 1, f(n) = 0 else) and n = 1, the un-normalized (1/2πi)-vertical integral grows like T/π and diverges, while the averaged mean equals 1 for every T. Proof mechanism (also the engine of the uniqueness theorem): expand F(σ+it)n^{σ+it} = Σ_m f(m)(n/m)^σ e^{it·log(n/m)}; absolute convergence at σ justifies the interchange; the t-mean of e^{iut} is 1 for u = 0 and tends to 0 otherwise, isolating m = n. *Whether the printing states this as a standalone numbered theorem or as the mechanism of the uniqueness development is UNVERIFIED pending pinning (⚠); the statement above is complete as mathematics.*
- AT11.17–AT11.18 ⚠11.17–11.18 (§11.12) **Perron's formula (the chapter's crown).** Corrected statement (see §5.4 for sources and the v1 line-548 repair): if F(s) = Σ f(n)n^{−s} converges absolutely for σ > σ_a, c > max(σ_a, 0), x > 0 non-integer:
  **Σ_{n≤x} f(n) = (1/2πi) ∫_{c−i∞}^{c+i∞} F(s) x^s / s ds** — **the division by s (equivalently w) is part of the kernel** — with Σ*-half-weight convention at integer x and T-truncated forms with error bounds.

**Dependencies:** Ch. 2, Ch. 4 (Λ), elementary complex analysis. **Node count 22** (4 D + 18 T).

### Chapter 12 — The Functions ζ(s) and L(s, χ) (pp. 249–277 ⚠carried)

**Definitions (5):** AD12.1 Γ(s) (properties only); AD12.2 Hurwitz ζ(s,a) = Σ_{n≥0}(n+a)^{−s}; AD12.3 Riemann ζ(s) = ζ(s,1); AD12.4 L(s,χ) and its Hurwitz combination; AD12.5 completed Λ(s,χ).

**Theorems (20 — v1 counted 18 while labelling 12.1–12.20; the twenty labels are kept, resolving the review's C3 flag):** AT12.1–AT12.3 ⚠12.1–12.3 Γ basics (integral, recursion, reflection); AT12.4 ⚠12.4 Hurwitz ζ analyticity + integral representation; AT12.5 ⚠12.5 Hankel contour representation; AT12.6 ⚠12.6 **Hurwitz continuation** (meromorphic, simple pole residue 1 at s=1); AT12.7 ⚠12.7 ζ continuation; L(s,χ) entire for χ ≠ χ₀ (L = q^{−s}Σ_r χ(r)ζ(s, r/q)); AT12.8 ⚠12.8 **Hurwitz's formula**; AT12.9 ⚠12.9 ζ functional equation; AT12.10 ⚠12.10 Hurwitz functional equation; AT12.11 ⚠12.11 L functional equation (root number G(1,χ̄)/(i^α√k)); AT12.12 ⚠12.12 special values ζ(−n,a) = −B_{n+1}(a)/(n+1), ζ(−2n) = 0; AT12.13–AT12.15 ⚠12.13–12.15 Bernoulli numbers/polynomials, ζ(2n) evaluation; AT12.16 ⚠12.16 L(0,χ) = −(1/k)Σχ(r)r; AT12.17 ⚠12.17 finite-sum approximation with remainders; AT12.18–AT12.20 ⚠12.18–12.20 strip inequalities for |ζ(s,a)|, |ζ(s)|, |L(s,χ)| (Ch. 13 inputs). *(AT12.18–AT12.20 constants unspecified in v1 — UNFINISHED rows, research reminders; complete at pin time.)*

**Dependencies:** Ch. 11, Ch. 6–8, contour integration. **Node count 25** (5 D + 20 T).

### Chapter 13 — Analytic Proof of the Prime Number Theorem (pp. 278–303 ⚠carried)

**Definitions (1):** AD13.1 the smoothed reformulation quantities ψ₁(x) = ∫₀^x ψ(t)dt and the weighted error sums of the plan (§13.1, §13.3).

**Theorems (20).** Because printed **13.15 is Pólya–Vinogradov [V]** (AFP `Polya_Vinogradov.thy` l. 813: "Apostol formulates it in the following way (Theorem 13.15, notation adapted)"), v1's reconstructed sequence 13.1–13.19 — which placed the zero-free region at 13.15–13.16 — is renumbered: nodes after the PNT node carry provisional numbers **⚠ ≥ 13.16 (shifted; no collision with verified 13.15)**:
- AT13.1 ⚠13.1 (§13.1) the plan: ζ(1+it) ≠ 0 ⇒ PNT, via ψ₁(x) ~ x²/2 ⇒ ψ(x) ~ x.
- AT13.2–AT13.7 ⚠13.2–13.7 (§13.2) the analytic lemma set (growth/contour lemmas). **UNFINISHED rows — research reminders:** v1 left exponents/constants unspecified; complete at pin time.
- AT13.8 ⚠13.8 (§13.3) contour integral representation of ψ₁(x)/x² with T-truncation.
- AT13.9–AT13.10 ⚠13.9–13.10 (§13.4) ζ, ζ′ bounds near σ = 1 (O(log t), O(log² t)-class). **UNFINISHED rows** as above.
- AT13.11 ⚠13.11 (§13.5) **nonvanishing ζ(1+it) ≠ 0** (the 3-4-1 argument).
- AT13.12–AT13.13 ⚠13.12–13.13 (§13.6) bounds for 1/ζ and ζ′/ζ on σ = 1. **UNFINISHED rows.**
- AT13.14 ⚠13.14 (§13.7) **the Prime Number Theorem**: ψ(x) ~ x, θ(x) ~ x, π(x) ~ x/log x.
- AT13.15 **13.15 [V]** (§13.12) **Pólya–Vinogradov**: "If χ is any nonprincipal character mod n, then for all x ≥ 2, Σ_{m≤x} χ(m) = O(√n log n)." Verified anchor — AFP proves the primitive form `polya_vinogradov_inequality_primitive`: ‖Σ_{m=1..x} χ m‖ < √n·ln n, and an explicit conductor form `polya_vinogradov_inequality_explicit` (nonprincipal χ: ‖Σ χ‖ < √(conductor)·ln(conductor)·d(n/conductor)).
- AT13.16–AT13.17 ⚠ ≥13.16 shifted (§13.8) zero-free region σ ≥ 1 − c/log|t| and the error-term consequence. **UNFINISHED rows** (constants); prior art: AFP `PNT_with_Remainder` proves a zero-free region and π(x) = Li(x) + O(x exp(−√(log x)/3653)) — a different (stronger, VK-shaped) statement than the book's classical region.
- AT13.18 ⚠ ≥13.17 shifted (§13.9) the Riemann hypothesis — **statement-only section; proof not in the book; its printed numbering is UNVERIFIED and it is flagged for re-classification at pin time** (v1 counted it as a theorem node; if unnumbered as printed it leaves the ledger).
- AT13.19 ⚠ ≥13.18 shifted (§13.10) application to d(n) (error-term sharpening).
- AT13.20 ⚠ ≥13.19 shifted (§13.11) application to φ(n) averages.

**Dependencies:** Ch. 4, 11, 12; contour integration throughout. **Node count 21** (1 D + 20 T).

### Chapter 14 — Partitions (pp. 304–328 ⚠carried)

**Definitions (5):** AD14.1 partition p(n); AD14.2 Ferrers graphs, conjugate partitions; AD14.3 Euler function φ(x) = ∏_{n≥1}(1−xⁿ); AD14.4 restricted partition functions p_A(n); AD14.5 generalized pentagonal numbers g_k = k(3k−1)/2.

**Theorems (11):**
- AT14.1 ⚠14.1 (§14.3) **generating functions**: Σ p(n)xⁿ = ∏(1−x^m)^{−1}, |x| < 1; parts-from-A form.
- AT14.2 ⚠14.2 (§14.3) Euler's odd-parts = distinct-parts identity.
- AT14.3–AT14.4 ⚠14.3–14.4 (§14.4) **pentagonal-number theorem**: φ(x) = Σ_{k∈ℤ}(−1)^k x^{k(3k−1)/2}, |x| < 1. *(Formalized both analytically and as a formal power series in AFP — `pentagonal_number_theorem_complex` and `has_fps_expansion_euler_phi_complex` — see §6's Ch. 14 decision.)*
- (§14.5 Franklin's combinatorial proof — unnumbered, not a node.)
- AT14.5 **14.5 [V]** (section ⚠; sits after Franklin's §14.5 proof in v1's ordering) **Upper bound for p(n) [COMPLETED — was "p(n) ≤ …" in v1]**: exact formal statement (AFP `Partition'_le`, following "Apostol's presentation of the proof by van Lint~\cite[Theorem~14.5]{apostol}"):
  **for n > 1: p(n) ≤ π·exp(π√(2n/3)) / √(6(n−1)).** The book's own printed constants remain ⚠ pending pinning; the shape, constant π√(2/3) and the van Lint attribution are verified via the AFP source (l. 400–424).
- AT14.6 ⚠14.6 (§14.8) Euler's recursion: p(n) = Σ_{k≥1}(−1)^{k+1}[p(n−g_k) + p(n−g_{−k})]. Formalized in AFP: `theorem Partition'_recurrence` — for n > 0, p(n) = Σ_{i∈[1..n]∩pent_nums} (±1)·p(n−i) with sign by parity of the pentagonal index.
- AT14.7 ⚠14.7 (§14.8) **Jacobi's triple product identity** — **an analytic identity as printed**: ∏_{n≥1}(1−x^{2n})(1+x^{2n−1}y²)(1+x^{2n−1}y^{−2}) = Σ_{k∈ℤ} x^{k²}y^{2k} for **|x| < 1, y ≠ 0** (infinite sums and products; the y^{−2} factor makes a purely formal-series reading non-trivial — see the Ch. 14 decision in §6). Formalized in AFP as `jacobi_theta_nome_triple_product_complex` (w ≠ 0, ‖q‖ < 1) and `ramanujan_theta_triple_product_complex` (‖ab‖ < 1).
- AT14.8 ⚠14.8 (§14.9) consequences (Jacobi's divisor-sum identities).
- AT14.9 ⚠14.9 (§14.10) logarithmic differentiation identities (Σ d(n)xⁿ = Σ xⁿ/(1−xⁿ)).
- AT14.10–AT14.11 ⚠14.10–14.11 (§14.11) Ramanujan's partition congruences p(5n+4) ≡ 0 (mod 5), p(7n+5) ≡ 0 (mod 7) (11-version an exercise). **Not located in any assistant within the searches run; open-everywhere UNVERIFIED (bounded), open-in-Lean verified within this pass's searches.**

**Dependencies:** Ch. 1–2 (formal series from §2.15), absolute convergence in |x| < 1 — **the chapter does carry an analysis prerequisite** (v1's §6 "pure power-series work with no analysis prerequisites" is retracted; see §6). **Node count 16** (5 D + 11 T).

---

## §3 Prior-art register (every row re-verified live by this pass, 2026-11-10 ≈18:05–18:35 UTC)

The fixed reference **M = `862047ba60dbfd5ec316433fb728e310612e6449`** (mathlib4, committer date 2026-11-10T11:56:22Z, "#45805 chore(Algebra/Order/Group/Indicator)"). Master has since moved (now `68dd2955f557`, 2026-11-10T17:26:40Z) — M is the dossier's snapshot, per the review's framing. All raw artifacts + sha256 in `prefetch-v2/`.

### 3.1 Upstream mathlib4 at M (the review's eight sampled corrections, re-verified)

| # | Claim | This pass's independent result | Source (fetched) |
|---|---|---|---|
| 1 | `Mathlib/NumberTheory/` size | **70 top-level entries (46 files + 24 directories); 252 `.lean` files recursively; tree untruncated** — confirmed | `contents-NumberTheory.json`, `tree-M.json` |
| 2 | Apostol citations | **0 case-insensitive "Apostol" matches** in `ArithmeticFunction/Defs.lean` (24,979 B), `MulChar/Basic.lean` (24,265 B), `LSeries/HurwitzZeta.lean` (8,496 B), `docs/references.bib` (236,259 B) — confirmed | files/ (raw at M) |
| 3 | atlas | **242 top-level entries (211 files + 31 dirs) at `18d1aa399b6ebaa8cd9c4a48795b43f6734c3785` (2026-11-05T21:17:41Z); recursively 630 entries** (the review's 242 is the top-level contents count — both true with their definitions; review C10's refinement confirmed) | `atlas/contents-MathlibExtNT.json`, `atlas/tree-atlas.json` |
| 4 | UyNewNas | `32e538c6c3ce386f25751b874a24da905a5b5540` (2026-09-17T08:40:20Z) = **70** `.lean`; main `88ee563ba0021702ea370b13bae7c7e7fec59657` (2026-09-22T17:08:16Z) = **197**; both trees untruncated; `Analysis/{PerronSeries,TruncatedPerron}.lean`, `Dirichlet/CharacterPerron{,ClosedError,Residue}.lean` present at main — confirmed | `uynnewnas/` |
| 5 | Abel summation | Commit **`822e8564863729fa71322d896c9f6aa7903adef4`** (2024-12-01T09:59:43Z) "feat(NumberTheory): Abel summation (#19289)" adds `Mathlib/NumberTheory/AbelSummation.lean`; present at M with `sum_mul_eq_sub_sub_integral_mul`, `summable_mul_of_bigO_atTop` — confirmed | `commits/mathlib-822e…json`, `files/…AbelSummation.lean` |
| 6 | Pentagonal | Commit **`98ef485d217e48d24735e2637a46b1b01c41019b`** (2026-09-01T16:43:18Z) "pentagonal number theorem for normed ring (#42185)" adds `Pentagonal/EulerFunction.lean` (+`PowerSeries`, `Ring`); at M: `eulerFunction_eq_tprod`, `hasProd_eulerFunction`, `eulerFunction_eq_tsum_pentagonal` — confirmed | `commits/…98ef…json`, `files/` |
| 7 | Wiener–Ikehara | Commit **`d4bda671c42c9097d07275af15f9c288cad61a28`** (2026-11-03T23:55:27Z) "the Wiener-Ikehara Tauberian theorem (#43233)" adds `LSeries/WienerIkehara.lean`; at M: `tendsto_sum_div`, `tendsto_sum_range_div` (with a Chebyshev-type hypothesis; existence ≠ book-route fidelity) — confirmed | `commits/…d4bd…json`, `files/` |
| 8 | Primitive roots | `RingTheory/ZMod/UnitsCyclic.lean` at M contains `isCyclic_units_iff` plus the full case list (`…_one/two/four/eight/prime/of_prime_pow/of_mul_coprime/two_mul_iff_of_odd/two_pow_iff`); commit **`95153009917ea7c8a07d4cbfb0acce197433eff6`** (2026-10-31T15:38:56Z) "(ZMod (2^n))ˣ is generated by -1 and 5 (#45509)" completed the 2-power case — confirmed | `files/…UnitsCyclic.lean`, `commits/…9515…json` |

Additional this-pass checks at M (used by §4): `SumPrimeReciprocals.lean` (`not_summable_one_div_on_primes`); `Data/Nat/Prime/Infinite.lean` (`Nat.exists_infinite_primes`); `Data/Nat/Factorization/Basic.lean` (`factorization_prod_apply`); `Data/Nat/Prime/Defs.lean` (`def Prime`, `minFac`); `ArithmeticFunction/Misc.lean` (`def sigma`, `sigma_apply_prime_pow`); `ArithmeticFunction/{Defs (instMonoid, one_apply), Moebius (isMultiplicative_moebius, coe_moebius_mul_coe_zeta), VonMangoldt (moebius_mul_log_eq_vonMangoldt, sum_moebius_mul_log_eq, vonMangoldt_mul_zeta), Liouville}`; `Data/Nat/Totient.lean` (`sum_totient`, `totient_eq_mul_prod_factors`, `totient_eq_card_coprime`); `Chebyshev.lean` (`def psi`, `def theta`, `abs_psi_sub_theta_le_sqrt_mul_log`); `Bertrand.lean` (`exists_prime_lt_and_le_two_mul_succ`); `Wilson.lean` (`prime_iff_fac_equiv_neg_one`); `PowModTotient.lean` (`pow_totient_mod_eq_one`); `Data/Nat/ChineseRemainder.lean` (`chineseRemainder`, `chineseRemainder_modEq_unique`); `DirichletCharacter/Orthogonality.lean` (`sum_characters_eq`, `sum_characters_eq_zero`, `sum_char_inv_mul_char_eq`); `LSeries/PrimesInAP.lean` (`forall_exists_prime_gt_and_zmodEq`, `infinite_setOf_prime_and_modEq`); `LSeries/Nonvanishing.lean` (`LFunction_ne_zero_of_one_le_re`, `LFunction_apply_one_ne_zero_of_quadratic`); `GaussSum.lean` (`def gaussSum`, `gaussSum_one_right`, `gaussSum_mulShift`); `LegendreSymbol/Basic.lean` (`eulerCriterion`), `LegendreSymbol/ZModChar.lean` (`neg_one_pow_div_two_of_one_mod_four`), `LegendreSymbol/QuadraticReciprocity.lean` (`quadratic_reciprocity`), `LegendreSymbol/JacobiSymbol.lean` (`at_two`, `at_neg_one`); `LSeries/{HurwitzZeta (hurwitzZeta_one_sub, meromorphic-continuation/residue-1 docstring), RiemannZeta (completedRiemannZeta_one_sub, riemannZeta_zero, riemannZeta_neg_two_mul_nat_add_one), DirichletContinuation (completedLFunction_one_sub)}`; `EulerProduct/{Basic (eulerProduct), DirichletLSeries (riemannZeta_eulerProduct, eulerProduct_log_eq_LSeries)}`; `Combinatorics/Enumerative/Pentagonal/EulerFunction.lean`, `Partition/{GenFun (hasProd_genFun, genFun_eq_tprod), Glaisher (card_odds_eq_card_distincts)}`.

**Tree-level absences at M (whole-repo tree, untruncated):** no path matching `Perron`; none matching `Polya`; no `PrimeNumberTheorem` path (no `prime_number_theorem` in `Wanted.lean` either); Jacobi-theta files exist only under `ModularForms/JacobiTheta/` (no product identity); no partition-recurrence file (`Enumerative/Partition/{Basic,YoungDiagram,GenFun,Glaisher}.lean` contain no recurrence; `Pentagonal/PowerSeries.lean` proves coefficient lemmas of the pentagonal series, not p(n)'s recurrence).

### 3.2 atlas-lean (`facebookresearch/atlas-lean`) at `18d1aa3…`

`MathlibExt/NumberTheory/` = **242 top-level entries** (C10; review's number confirmed) / 630 recursive. `PrimeNumberTheorem.lean` (8,973 B) — **0 `sorry`; `theorem prime_number_theorem` present**; imports `MathlibExt/Analysis/LaplaceTransform/NewmanTauberian` ("Private helpers for Newman's analytic theorem") — the Newman/Zagier route. Also present: `PrimeNumberTheoremAP.lean`, `RamanujanSum.lean`, `ApostolBernoulliNumber.lean` (Apostol's 1951 Bernoulli generalization — unrelated to IANT). **LICENSE = Apache 2.0 text preceded by the preamble "Codebase is not intended for use to train, fine-tune, distill, evaluate, or otherwise develop ML models"** (captured verbatim; no legal ruling made here — import ruling required before fleet use, as in v1).

### 3.3 Formalpedia (`prove2me/formalpedia`) — review C7 RESOLVED with records

Head `acf1cadf94817574ae8d3e7431e847c0685314b6` (2026-11-10T06:05:00Z, unchanged since the morning passes). This pass **re-downloaded all 20 shards of `envs/0df444a/` fresh (435 MB)**; all are byte-identical (cmp) to the local morning cache. Case-insensitive "Apostol" matches: **16 records**, each listed with shard and line (v1's "16 occurrences in 12 entries" refined):

| shard:line | record id | theorem_name | cites |
|---|---|---|---|
| index-000:9416 | a24781f5-8303-4cc1-b9ce-0ddfcef2ebd0 | ArithmeticFunctions.mul_apply_prime_pow | **IANT** |
| index-002:6425 | c2c3cda1-02d9-44e4-98d0-97df73491079 | ChebyshevFunctions.sum_log_eq_sum_vonMangoldt_mul_div | **IANT** |
| index-002:11695 | d3383a7c-015f-4784-9ea4-213db620f7d4 | DirichletCharacters.toArithmeticFunction_prime_pow | **IANT** |
| index-002:11699 | 29f41301-6094-451d-a99e-45d4dfb86b38 | DirichletLFunctions.LSeriesSummable_toArithmeticFunction | **IANT** |
| index-002:11700 | cfdad958-c6ab-46ce-8be2-501280345837 | DirichletLFunctions.LSeries_toArithmeticFunction_eq | **IANT** |
| index-002:13095 | 0c8ef581-3132-4a6f-ae7d-c7379f1be6bb | DivisorSums.sum_card_divisors_le | **IANT** |
| index-004:3076 | d79eee94-11fe-4705-8930-1cd224c8fde8 | MertensTheorems.integral_inv_tlog | **IANT** |
| index-004:3077 | 919a7a12-5623-40a0-ac01-bec768221c03 | MertensTheorems.integral_inv_tlogsq | **IANT** |
| index-004:3080 | **d09af852-f479-4509-a198-8f0ba56f9115** | **MertensTheorems.sum_log_div_prime_le** | **IANT Thm 4.10** |
| index-004:3364 | e3e8c8e6-e669-4dc3-ad2d-db0b29cd96c1 | MilnorDynamics.milnorLambdaHalfShift_ne_one | Modular Functions |
| index-004:3394 | 81ffb158-208f-4fe4-85f0-794dd288461a | MilnorLambda (Definition) | Modular Functions |
| index-004:3395 | 46b2af40-3f5b-4d4c-baad-3cb9839e2382 | MilnorLambdaHalfShift (Definition) | Modular Functions |
| index-006:834–837 | 40cf05f8…, b1f777c6…, 36ed7b5f…, d719edb7… | VectorSpaceOpt.riesz_representation… (×4) | *Mathematical Analysis* (2nd ed., Ch. 7) |

So: **9 records cite IANT** (all status Proved, all Lean proofs extracted from the Salt project, created 2026-09-21), 3 cite Apostol's *Modular Functions*, 4 cite Apostol's *Mathematical Analysis*. The **Mertens Thm 4.10 anchor is now fully sourced** (record id + shard + line + statement path + author + date, in §2's AT4.10). Related: `jyh/salt` head `e7d9a1906772` (2026-11-08); `Salt/Maynard/Mertens.lean` fetched at that head — 25,216 B, **0 "Apostol" strings** (the citation lives only in Formalpedia's metadata), and it contains `sum_log_div_prime_le` and `integral_inv_tlog` matching the records.

### 3.4 Palomar Registry — review C9's bounded observation, extended

This pass observed **revision 853**, release `7b13db9a0a2a4238e21d36138a2be0c1a75f9a940763226f43a19ec34540faac`, totals **1,052 results / 821 projects**. Fresh queries: `?q=Apostol` → **0 entries** (NOT FOUND at 853, this pass's own observation); `?id=PALOMAR-2026-10-25-000017` → **0 entries** (NOT FOUND at 853). History: v1 observed rev 850 (1,050/819); the review observed rev 851 (release `b5120a3c…`, 1,051/820) and reproduced both NOT-FOUNDs there. **NOT FOUND at 850 is historically UNVERIFIED; no claim is made about when the ID disappeared, and no date-window reasoning from a paginated listing is used** (the Dirichlet listing has a `next` cursor; page 1 ordering was not used as evidence).

### 3.5 AFP (isa-afp.org) — 18 entries, publication dates re-verified from the live entry pages

All 18 entry HTML pages fetched fresh (`prefetch-v2/afp/entries/`); dates below are the "published" dates on those pages; five entries' theory sources additionally fetched as release tarballs and the key declarations read directly (`prefetch-v2/afp/src/`).

| Entry | Published | Scope evidence used in this dossier |
|---|---|---|
| Dirichlet_Series (Eberl) | **2017-10-12** | Abstract: "a formalisation of much of Chapters 2, 3, and 11 of Apostol's 'Introduction to Analytic Number Theory'", incl. "density of squarefree integers and the average number of divisors" |
| Dirichlet_L (Eberl) | **2017-12-21** | Dirichlet characters + L-functions + Dirichlet's theorem; "non-vanishing follows a very short and elegant proof by Newman" (not the book's route) |
| Prime_Number_Theorem (Eberl & Paulson) | **2018-09-19** | PNT in several equivalent forms; Chebyshev ψ, ϑ, p_n; **"Lastly, we derive Mertens' First and Second Theorem, i. e. ∑_{p≤x} ln p/p = ln x + O(1) and ∑_{p≤x} 1/p = ln ln x + M + O(1/ln x)"** + explicit remainder bounds |
| Gauss_Sums (Raya & Eberl) | **2019-12-10** | **"a full formalisation of Chapter 8 of Apostol's Introduction to Analytic Number Theory"** incl. Pólya–Vinogradov |
| Zeta_Function (Eberl) | **2017-10-12** | Hurwitz/ζ via **Euler–MacLaurin continuation** (not the book's Hankel route); abstract lists "the non-vanishing of ζ(s) for Re(z) ≥ 1", "special values at negative integers and positive even integers", **"Hurwitz's formula and the reflection formula"** |
| Euler_MacLaurin (Eberl) | **2017-03-10** | Banach-valued E–M; **not Apostol content** (the book has Euler's summation formula = the k = 0 case) |
| Prime_Distribution_Elementary (Eberl) | **2019-02-21** | **"a formalisation of Chapter 4 (and parts of Chapter 3)"**; sessions incl. `Shapiro_Tauberian`, `Selberg_Asymptotic_Formula`, `PNT_Consequences` |
| Perrons_Formula (Eberl) | **2026-06-17** | Perron's formula incl. effective bounds; see §5.4 |
| PNT_with_Remainder (Song & Yao) | **2024-05-05** | "first formalized version of PNT with an explicit error term": π(x) = Li(x) + O(x exp(−√(log x)/3653)) + the zero-free region |
| Pentagonal_Number_Theorem (Eberl) | **2025-04-23** | Pentagonal theorem via JTP; **`Partition'_recurrence`** (p(n) recurrence); **`Partition'_le` = Thm 14.5 [V]** |
| Theta_Functions (Eberl) | **2024-12-02** | **`jacobi_theta_nome_triple_product_complex`** (JTP: w ≠ 0, ‖q‖ < 1), `ramanujan_theta_triple_product_complex` |
| Rademacher_Series (Eberl & Paulson) | **2026-07-03** | Rademacher's convergent series for p(n) — beyond the book |
| Rogers_Ramanujan (Eberl) | **2024-12-02** | Rogers–Ramanujan identities |
| Combinatorial_Q_Analogues (Eberl) | **2024-12-02** | q-bracket/factorial/binomial + infinite product lemmas |
| Chebyshev_Prime_Bounds (Eberl) | **2024-09-13** | explicit ψ ≥ 0.9x (x ≥ 41), ϑ ≥ 0.82x, ϑ ≤ ψ ≤ 1.2x |
| Bertrands_Postulate (Biendarra & Eberl) | **2017-01-17** | ported from Harrison's HOL Light proof |
| Prime_Harmonic_Series (Eberl) | **2015-12-28** | divergence of Σ 1/p |
| Sum_Of_Squares_Count (Eberl) | **2024-11-26** | r_k(n); main result **Jacobi's two-square theorem** (the four-square attribution remains **UNVERIFIED**, as in the review) |

**The Selberg refutation at declaration level (review C2).** From the release tarball (`Selberg_Asymptotic_Formula.thy`): line 22 labels the inversion development `(* 4.17 *)` (locale `selberg_inversion`, header "Following Apostol, we first show an inversion formula"); line 78–79:
```
(* 4.18 *)
theorem selberg_asymptotic_formula:
  includes prime_counting_syntax
  shows    "(λx. ψ x * ln x + dirichlet_prod' mangoldt ψ x) =o (λx. 2 * x * ln x) +o O(λx. x)"
```
i.e. ψ(x)·ln x + Σ_{n≤x} Λ(n)ψ(x/n) = 2x·ln x + O(x) — the Selberg asymptotic formula, following Apostol. Additionally Metamath `selberg` (fetched, `prefetch-v2/metamath/selberg.html`): "(λx. (Σ_{n∈(1…⌊x⌋)} (Λ(n)·((log n) + ψ(x/n))))/x − 2·log x) ∈ O(1)", described as "Selberg's symmetry formula … equivalent to Σ_{n≤x} Λ(n)log n + Σ_{m·n≤x} Λ(m)Λ(n) = 2x log x + O(x). Equation 10.4.10 of [Shapiro], p. 419. (Contributed by Mario Carneiro, 23-May-2016.)" — the same asymptotic form, hence prior art for it; and per the review, Avigad–Donnelly–Gray–Raff (arXiv:cs/0509025v3 §§3.1–3.2) describe a verified Selberg proof in Isabelle. **The pointwise Ch. 2 identity (AT2.20) is a different statement; neither AFP nor Metamath `selberg` is it, and its global absence remains UNVERIFIED.**

### 3.6 girving/interval — Euler–Maclaurin (review C11's sorry-audit closed)

Commit `2c89204b806f4acd9b8530a38e656369d0a4d7f3` (2026-10-14T04:58:40Z, "Add the Euler-Maclaurin formula for real end points, with remainder bounds (#34)"). `Interval/EulerMaclaurin/` contains **10 `.lean` files** (v1 said 11 — corrected); **this pass fetched every file and grepped: 0 `sorry` in all 10** (Bernoulli, DerivUnderIntegral, EulerMaclaurin, Formula, Gamma, IteratedDerivArith, LHopital, PartialDerivCommute, PeriodizedBernoulli, RemainderBound). LICENSE = plain Apache 2.0. `sum_Ioc_eq_integral_add_of_hasDerivWithinAt`'s statement is quoted in §2 (AT3.1) — it corroborates the repaired Euler-summation signs at p = 1.

### 3.7 Other provers and the bounded book-level negative (review C8)

- **Metamath** `set.mm`: `selberg` (above). v1's `dirith`/`pnt`/`pnt2`/`pnt3` line observations are carried from v1 (checked 2026-11-10 morning; not re-fetched this pass — the 51.9 MB file was not re-downloaded; mark "v1-verified").
- **HOL Light, Coq/Rocq, HOL4/Mizar**: carried from v1's checks (PNT via Newman in `100/pnt.ml`; no PNT/Dirichlet/Perron/E–M/partition packages in the Coq opam archive; Freek-100 index) — not re-run this pass except: fresh `gh search code "Apostol" --language=Coq` → **3 hits** (keyboard-layout/verification files, irrelevant).
- **Fresh GitHub searches (this pass, authenticated):** `gh search repos "Apostol" --language=Lean` → **0**; `gh search code "Apostol" --language=lean` → **25 hits** (atlas `ApostolBernoulliNumber.lean` + test copy, `girving/interval Interval/EulerMaclaurin/Formula.lean`, `lean-forward/class-group-and-mordell-equation src/number_theory/farey.lean` (an Apostol citation for Farey sequences, not IANT content), plus irrelevant TruthCore/palindrome/sofa hits — full list in `prefetch-v2/gh-search-code-apostol-lean.txt`); `gh search code "Apostol" --language=Isabelle` → 98 hits, dominated by a mirror of the AFP (`caotic123/Isabelle src/Abduct/AFP/…` incl. `Gauss_Sums/Polya_Vinogradov.thy`, `Prime_Distribution_Elementary/…`); `gh search repos "Introduction to Analytic Number Theory"` → 2 metadata-described repos (`robfatland/ant` — course/exercise project by description; `wflaherty02/IntroductionToANT` — "images for my third year mathematics project"; neither claims a formalization; content UNVERIFIED).
- **`ryandv/apostol.mm`** at `75ad655e39e44c0ab3fc58bf41e1b089eb15f5db` (2023-07-14T13:15:38Z): fetched the file — header: "Solutions to exercises given in **Calculus, Vol. 1 by Apostol, 2nd ed.**" — **not IANT** (confirms the review).
- **Bounded chapter-level negative (restated per C8):** in the searches listed above (this pass) plus v1's and the review's recorded searches (GitHub repo/code, atlas, ReasBook, lean-pool, salt, TauCeti, Formalpedia, Palomar, Freek-100, Coq opam, AFP index), **no complete fourteen-chapter Apostol project was identified**, while **chapter-level formalizations do exist** (AFP `Gauss_Sums` = full Ch. 8; AFP `Prime_Distribution_Elementary` = Ch. 4 + parts of Ch. 3; `Dirichlet_Series` = much of Ch. 2, 3, 11; the Ch. 14 chain). No stronger negative is asserted.

---

## §4 Coverage map, rebuilt from individually verified nodes only (review C4 + C11)

**Method (fixed, auditable).** A node is counted as covered **only** when this pass verified a specific declaration (or a Formalpedia Proved record) whose statement matches the node — **DECL tier**, with the file and declaration named. A second tier, **ABSTRACT**, records AFP entries whose live abstracts state precise coverage of book content (e.g. Gauss_Sums' "full formalisation of Chapter 8") — these are real prior art but were **not** node-verified and are **not counted** in any numerator. Topic overlap, empty-file observations, and source-level `sorry` counts are never counted as coverage (review C11); the sorry counts this pass did run are reported for what they are (atlas PNT file: 0; all 10 interval E–M files: 0). "Unverified remainder" = nodes neither DECL- nor ABSTRACT-supported in this pass — a mixture of genuinely open statements and statements nobody pinned this pass; no claim either way.

**Headline (auditable lower bounds, denominators = the §2 provisional ledger):**
- **Lean upstream [M], DECL-verified: 58/318 (18.2%).**
- **External Lean [E] (salt via Formalpedia record; girving/interval; atlas), DECL-verified: 3/318 (0.9%).**
- **Lean anywhere [M]+[E] = 61/318 (19.2%).**
- **Cross-assistant [X] DECL-verified (AFP/Metamath): 7/318 (2.2%) → covered in some assistant: 68/318 (21.4%).**
- v1's 62%/74%/90%/~60% figures are **withdrawn**; nothing above these lower bounds is asserted.

| Ch. | Nodes | [M] DECL (nodes → declarations at M) | [E] DECL | [X] DECL | ABSTRACT tier (not counted) | Unverified remainder |
|---|---:|---|---|---|---|---|
| 1 | 17 | **4**: AD1.3 (`def Prime`); AT1.5 (`factorization_prod_apply`); AT1.7 (`Nat.exists_infinite_primes`); AT1.10 (`not_summable_one_div_on_primes`) | — | — | AFP Prime_Harmonic_Series (Σ1/p divergence, entry scope) | 13 (incl. AT1.9 sieve-procedure node — trivial, unverified) |
| 2 | 34 | **13**: AD2.1 (`ArithmeticFunction`), AD2.2 (`isMultiplicative_moebius`, `moebius_apply_of_squarefree`), AD2.3 (`totient_eq_card_coprime`), AD2.4 (`instMonoid`, `mul_apply`), AD2.5 (`one_apply`), AD2.7 (`vonMangoldt_apply` family), AD2.8 (`IsMultiplicative`), AD2.10 (`liouville_apply`), AD2.11 (`def sigma`, `sigma_apply_prime_pow`); AT2.1 (`coe_moebius_mul_coe_zeta`), AT2.3 (`sum_totient`), AT2.4 (`totient_eq_mul_prod_factors`), AT2.8 (`moebius_mul_log_eq_vonMangoldt`, `sum_moebius_mul_log_eq`, `vonMangoldt_mul_zeta`) | — | — | AFP Dirichlet_Series ("much of Chapters 2, 3, 11") | 21 (incl. Bell-series AD2.13/AT2.17–18, derivative AD2.14/AT2.19, Selberg identity AT2.20 — AT2.20 open-in-Lean within searches; global absence UNVERIFIED) |
| 3 | 16 | 0 | **1**: AT3.1 (interval `sum_Ioc_eq_integral_add_of_hasDerivWithinAt`, p = 1 ≡ Euler summation; Abel-form `sum_mul_eq_sub_sub_integral_mul` at M is the AT4.3 node) | — | AFP Dirichlet_Series (average divisors, squarefree density); AFP Euler_MacLaurin (beyond-book E–M) | 15 (the asymptotic specializations AT3.2–AT3.13 — the hyperbola Σd(n) with O(√x), Σφ, Σμ², visible points are open in Lean per this pass's tree checks) |
| 4 | 22 | **4**: AD4.1 (`def psi`, `def theta`); AT4.1 (ψ–θ bridge, `abs_psi_sub_theta_le_sqrt_mul_log` — exact bound shape to re-pin); AT4.3 (`sum_mul_eq_sub_sub_integral_mul`); one Chebyshev/Bertrand node (`exists_prime_lt_and_le_two_mul_succ` ⚠ of the AT4.6–4.7 pair) | **1**: AT4.10 Mertens I (salt, Formalpedia record `d09af852…`, Proved) | **2**: AT4.8 Shapiro (`Shapiro_Tauberian.thy` locale + four-part lemma); AT4.17 Selberg asymptotic (`selberg_asymptotic_formula` `(* 4.18 *)`) | AFP Prime_Distribution_Elementary (Ch. 4 + parts 3: PNT equivalences, ω/d/φ/lcm consequences); AFP Prime_Number_Theorem (**Mertens I & II stated with formulas**); AFP Chebyshev_Prime_Bounds (explicit constants); Metamath `selberg` | 15 (incl. AT4.2 Legendre/factorial identity, AT4.4–4.5 equivalences at DECL level, AT4.9, AT4.11–13, the Selberg lemma row AT4.14–16) |
| 5 | 27 | **3**: AT5.7 Euler–Fermat (`pow_totient_mod_eq_one`); AT5.10 Wilson (`prime_iff_fac_equiv_neg_one`); AT5.12 CRT (`chineseRemainder`, `chineseRemainder_modEq_unique`) | — | — | — (congruence theory is background library in Isabelle; no AFP entry; no full-chapter claim made) | 24 (Lagrange's congruence-form AT5.9: field-theory content exists (`Polynomial.roots` cardinality over `ZMod p`) but was not located as the book-form congruence theorem — presentational; Hensel AT5.16–18: `NumberTheory/Padics/Hensel.lean` exists at M, path-level only) |
| 6 | 23 | **3**: AT6.7, AT6.8 orthogonality (`sum_characters_eq`, `sum_characters_eq_zero`, `sum_char_inv_mul_char_eq`); one L(1,χ)≠0-real node (`LFunction_apply_one_ne_zero_of_quadratic` — statement only, not the book's route) | — | — | AFP Dirichlet_L (characters, L-theory; Newman route) | 20 |
| 7 | 10 | **1**: the infinitude statement in AT7.2–3 (`forall_exists_prime_gt_and_zmodEq`, `infinite_setOf_prime_and_modEq`) | — | — | AFP Dirichlet_L (Dirichlet's theorem, Newman); Metamath `dirith` (v1-verified); HOL Light `100/dirichlet.ml` (v1-verified) | 9 (incl. AT7.9 asymptotic PNT-AP — atlas `PrimeNumberTheoremAP.lean` exists, path-level only) |
| 8 | 30 | **2**: AD8.5 (`def gaussSum`); one basic Gauss-sum node (`gaussSum_one_right`, `gaussSum_mulShift`) | — | — | **AFP Gauss_Sums — full Ch. 8** (strongest chapter prior art in the book) | 28 (Ramanujan sums: atlas `RamanujanSum.lean` path-level; induced moduli/primitive-character criteria, finite Fourier expansion, Pólya AT8.22 — the sharp form is [X] as Ch. 13's 13.15) |
| 9 | 31 | **5**: AT9.2 Euler criterion (`eulerCriterion`); one (−1|p)/(2|p)-family node (`neg_one_pow_div_two_of_one_mod_four`; `at_two`); AT9.11 QR (`quadratic_reciprocity`); AD9.4 Jacobi (JacobiSymbol.lean decls); one Jacobi complementary-laws node (`at_two`, `at_neg_one` in JacobiSymbol) | — | — | AFP Sum_Of_Squares_Count (two-square theorem); QR in Isabelle/Rocq/Metamath/Mizar (v1, Freek-100) | 26 (quadratic Gauss-sum evaluations AT9.20–25: `LegendreSymbol/QuadraticChar/GaussSum.lean` exists at M, path-level only) |
| 10 | 24 | **7**: AD10.2 (cyclic-units framing); AT10.4 (`isCyclic_units_two_pow_iff`); AT10.5 (`isCyclic_units_prime`); AT10.7 (`isCyclic_units_of_prime_pow`); AT10.8 (within the prime-power development); AT10.9 (`isCyclic_units_two_mul_iff_of_odd`); AT10.10 (`isCyclic_units_iff` — the full classification) | — | — | — | 17 (**index calculus AT10.12–16 and character-structure AT10.17–21 not located in any assistant searched — open-in-everything UNVERIFIED (bounded negative)**) |
| 11 | 22 | **4**: AD11.1 (`LSeriesSummable` family in LSeries/Basic); AT11.5 (`eulerProduct`); AT11.6 (`eulerProduct_completely_multiplicative`); AT11.11-partial (`riemannZeta_eulerProduct_exp_log`, `eulerProduct_log_eq_LSeries` — ζ-instance) | — | **1**: AT11.17 Perron (AFP `perron_asymp` + `perron_effective_strong`, exact statements in §5.4) | AFP Dirichlet_Series (Ch. 11 portion) | 17 (incl. AT11.16 vertical-mean coefficient extraction — not located anywhere searched; AT11.10 Landau; AT11.2 σ_c theory) |
| 12 | 25 | **7**: AD12.2 (HurwitzZeta.lean: series, meromorphic continuation, residue 1 — docstring); AD12.3 (`riemannZeta`); AT12.4 (Hurwitz continuation/residue, same file); AT12.9 (`completedRiemannZeta_one_sub`); AT12.10 (`hurwitzZeta_one_sub`); AT12.11 (`completedLFunction_one_sub`); AT12.12 (`riemannZeta_neg_two_mul_nat_add_one`, `riemannZeta_zero`) | — | — | AFP Zeta_Function (E–M continuation route; abstract: nonvanishing Re ≥ 1, special values, **Hurwitz's formula + reflection**) | 18 (Hankel route AT12.5 — different route by design; AT12.16 L(0,χ); AT12.17–20 strip inequalities) |
| 13 | 21 | 0 | **1**: AT13.14 PNT (atlas `theorem prime_number_theorem`, 0 sorry, Newman route) | **1**: AT13.15 Pólya–Vinogradov (`polya_vinogradov_inequality_primitive`: ‖Σ_{m≤x}χ(m)‖ < √n·ln n; + conductor form) | AFP Prime_Number_Theorem (Newman); **AFP PNT_with_Remainder (π(x) = Li(x) + O(x exp(−√(log x)/3653)) + zero-free region)**; Metamath `pnt/pnt2/pnt3` (v1-verified); HOL Light (v1) | 19 (the book's literal contour chain AT13.1–13.13: no σ=1-line ζ-nonvanishing at M — only `riemannZeta_ne_zero_of_one_lt_re` (Re > 1) and the L-version `LFunction_ne_zero_of_one_le_re`; Mathlib's Wiener–Ikehara `tendsto_sum_div` is a route enabler, not a book node) |
| 14 | 16 | **5**: AD14.3 (`eulerFunction_def`); AT14.1 (`hasProd_genFun`, `genFun_eq_tprod`); AT14.2 (`card_odds_eq_card_distincts`); AT14.3–AT14.4 (`eulerFunction_eq_tprod`, `hasProd_eulerFunction`, `eulerFunction_eq_tsum_pentagonal`) | — | **3**: AT14.5 (`Partition'_le` = Thm 14.5 [V]); AT14.6 (`Partition'_recurrence`); AT14.7 JTP (`jacobi_theta_nome_triple_product_complex`) | AFP Theta_Functions + Pentagonal_Number_Theorem chain; AFP Rademacher_Series, Rogers_Ramanujan, Combinatorial_Q_Analogues (beyond-book) | 8 (Ramanujan congruences AT14.10–11 not located anywhere searched — open-in-everything UNVERIFIED, bounded; Jacobi divisor identities, log-differentiation identities) |
| **Σ** | **318** | **58 (18.2%)** | **3** | **7** | — | — |

**Where the auditable open core sits (for pin planning):** Ch. 3's asymptotic specializations (13 unverified nodes), Ch. 5's book-form congruence nodes (24, mostly presentational glue), Ch. 8's Ramanujan/induced-moduli block (28), Ch. 9's Gauss-sum evaluation block (26), Ch. 10's index calculus (17), Ch. 11's σ_c/Landau/Perron-in-Lean block (17), Ch. 12's strip inequalities and L(0,χ) (18), Ch. 13's literal contour chain (19), Ch. 14's post-JTP identities and congruences (8). The **new-to-every-assistant candidates** within bounded searches: index calculus, the Ramanujan partition congruences, the pointwise Selberg identity (absence UNVERIFIED), the book's literal Ch. 13 route — each requiring a dedicated search pass before any "first" claim.

---

## §5 The five hardest theorems + Selberg: strongest published forms, quotations repaired (review C6)

**1. The Prime Number Theorem (AT13.14).** Strongest verified formalized form (cross-assistant), abstract quoted verbatim from the live entry page (this pass): AFP `PNT_with_Remainder` (2024-05-05): "We have formalized the proof of the Prime Number Theorem with remainder term. This is the first formalized version of PNT with an explicit error term. … the main result, prime number theorem with remainder: π(x) = Li(x) + O(x exp(−√(log x)/3653)) … Second, the zero-free region of the Riemann zeta function" (3653 outside the square root, confirmed in the page's own TeX). Lean: atlas `theorem prime_number_theorem` (0 sorry, Newman/Zagier route — verified this pass); PNTAnd (`AlexKontorovich/PrimeNumberTheoremAnd`, Apache-2.0, v1-verified head `127b50e3`, 2026-10-20) targets the classical error term — in progress. **Delta:** the book's contour route (ψ₁-representation, 3-4-1, the classical zero-free region σ ≥ 1 − c/log|t|) is formalized nowhere within the searches; AFP's zero-free region is the stronger VK-shaped one. Route decision required at pin time (§6).

**2. Dirichlet's theorem (AT7.2–3). [C6: labeled a SUMMARY, not verbatim]** Mathlib at M, `LSeries/PrimesInAP.lean`, provides `infinite_setOf_prime_and_modEq` and `forall_exists_prime_gt_and_zmodEq` (for every n there is a prime > n with p ≡ a (mod q), q ≠ 0, IsCoprime a q) — the *infinitude* statement, not the asymptotic AT7.9. v1's §5.2 rendering spliced the file's docstring prose with an abbreviated signature — it is a **summary**; the declaration names above are the citable anchors. AFP `Dirichlet_L` (2017-12-21): "This also leads to a relatively short proof of Dirichlet's Theorem, which states that, if h and n are coprime, there are infinitely many primes p with p ≡ h (mod n)" (abstract, Newman-route nonvanishing). **Delta:** no upstream asymptotic PNT-AP; the book's elementary real-character route (Ch. 6) is no formalization's route.

**3. Euler's summation formula / Euler–Maclaurin (AT3.1).** Corrected statement in §2 (AT3.1) with the sign corroboration from `interval`'s `sum_Ioc_eq_integral_add_of_hasDerivWithinAt` (quoted there). Mathlib `AbelSummation.lean` (`sum_mul_eq_sub_sub_integral_mul`, since 2024-12-01) is the Abel/partial-summation form (the AT4.3 node). AFP `Euler_MacLaurin` (2017-03-10, two variants per its abstract) is beyond-book E–M. **Delta:** trivial for the pin; the residual work is the book's *applications* (Ch. 3 asymptotics), of which only the salt/FourFold slices exist as records (§3.3).

**4. Perron's formula (AT11.17). [C6 repaired at declaration level.]** The exact AFP declaration (release-tarball source `Perrons_Formula/Perrons_Formula.thy`, l. 982, fetched this pass):
```
theorem perron_asymp:
  fixes fds :: "complex fds" and z :: complex and c x T :: real
  assumes c: "c > 0" "ereal (Re z + c) > conv_abscissa f" and x: "x > 0"
  shows   "((λT. contour_integral (L c T) (λs. eval_fds f (z + s) * of_real x powr s / s))
             ⟶ 2 * pi * 𝑖 * sum_upto' (λn. fds_nth f n / of_nat n powr z) x) at_top"
```
i.e. Σ′_{n≤x} a_n n^{−z} = (1/2πi) lim_{T→∞} ∫_{c−iT}^{c+iT} f(z+w) · **x^w / w** dw — **the division by w, dropped in v1's line-548 rendering, is restored**. Note the convergence hypothesis is the *ordinary* abscissa of convergence (`conv_abscissa`), i.e. AFP proves a stronger hypothesis-class than the book's absolute-convergence version; `perron_effective_strong` adds an explicit distance bound for finite T (via `abs_conv_abscissa`). **The AFP *abstract*'s typography is indeed faulty** (as the review suspected) — its formula reads "f(z + w) x^s w dw/w", with a wrong exponent variable (`x^s`) and a stray factor `w` before `dw/w`; the `.thy` declaration above is the citable form, and **neither the abstract's nor any summary's typography may be promoted into a frozen pin** — pin the declaration. Lean: UyNewNas `Analysis/{PerronSeries,TruncatedPerron}.lean`, `Dirichlet/CharacterPerron{,ClosedError,Residue}.lean` at head `88ee563b` (paths verified; truncated/dyadic variants; not upstream).

**5. Jacobi's triple product (AT14.7).** AFP `Theta_Functions/Jacobi_Triple_Product.thy` (fetched): `jacobi_theta_nome_triple_product_complex`: for w ≠ 0, ‖q‖ < 1, θ(w, q) = (q²;q²)∞·(−qw;q²)∞·(−q/w;q²)∞; and `ramanujan_theta_triple_product_complex` for ‖ab‖ < 1. The file's own comment records the convergence-transfer shape: the identity is first proved on a restricted real domain (q ∈ (0, 1/4), w ∈ (1/2, 1)) and extended to the full domain **by analytic continuation** — direct evidence for §6's Ch. 14 decision. Downstream in AFP: `pentagonal_number_theorem_complex` + the fps variant `has_fps_expansion_euler_phi_complex`, `Partition'_recurrence`, `Partition'_le` (= 14.5 [V]). Lean: JTP not located anywhere searched (Mathlib's `ModularForms/JacobiTheta/` proves no product identity — tree check at M).

**6. Selberg's asymptotic formula (AT4.17) — the retraction record.** AFP `(* 4.18 *) theorem selberg_asymptotic_formula` (statement in §3.5) and Metamath `selberg` (Shapiro 10.4.10 form, Carneiro 2016-05-23) both prove the asymptotic formula; Avigad–Donnelly–Gray–Raff (arXiv:cs/0509025v3 §§3.1–3.2, per the review) verified the Selberg-era elementary development in Isabelle. **No claim of openness or blueprint-absence survives for the asymptotic form.** The pointwise Ch. 2 identity (AT2.20) remains separately unlocated (UNVERIFIED absence).

---

## §6 Revised recommendation, lane prerequisites, schedule, risks (review C12)

### What the repaired evidence supports

- The book is **not open as a book** in any assistant searched (bounded negative, §3.7) — a Lean Apostol would still be the first complete formalization of the book.
- But its **crown is substantially taken cross-assistant**: Ch. 8 fully (AFP), Ch. 4 + parts of 3 (AFP, incl. Selberg's asymptotic formula and Shapiro), much of Ch. 2/3/11 (AFP), Ch. 14's chain to Rademacher (AFP), Perron incl. an effective form (AFP), PNT with explicit remainder + zero-free region (AFP), Dirichlet (AFP/Metamath/HOL Light), Pólya–Vinogradov (AFP), Mertens I & II (AFP + salt), JTP (AFP). New-to-every-assistant content is, within bounded searches, confined to: index calculus, the Ramanujan partition congruences, the pointwise Selberg identity (absence UNVERIFIED), the book's literal Ch. 12–13 routes, and presentational book-form nodes (Ch. 5's Lagrange congruence form, Ch. 6's elementary real-character route). Each such "first" claim needs its own dedicated search pass before being asserted in any charter.
- The auditable Lean coverage is **61/318 (19.2%)** DECL-verified (§4) — the book is an **import-and-integrate project with a hard analytic remainder**, not a greenfield.

### Recommendation (one paragraph, revised)

**Do not pick Apostol fourth on v1's rationale — that rationale is withdrawn.** On the repaired evidence, Apostol as #4 is defensible **only** under a charter that (i) accepts it as a *statement-complete, import-first integration project* whose new-to-Lean core (Perron, JTP, p(n)-recurrence, Pólya–Vinogradov, Selberg, the Ch. 3 asymptotics, index calculus, the Ch. 12–13 statements) is mostly **port-with-blueprint** work against named AFP/Metamath/salt/atlas sources, and (ii) explicitly waives "new to every assistant" for the crown. If the programme's #4 criterion is maximal first-to-any-prover mathematics, this book is the wrong pick — the Isabelle shadow covers the signature results. The final slot decision belongs to the coordinator on this repaired dossier plus the renewed crossed review; this dossier makes no slot claim.

### Lane prerequisites (decision points the charter must fix at pin time)

1. **Ch. 12–13 route carve-out (retained from v1 on revised foundations).** Proving the *statements* via the ecosystem route (Wiener–Ikehara at M; atlas's Newman PNT as import) vs formalizing the book's literal contour chain (ψ₁-representation, 3-4-1, classical zero-free region — open everywhere searched, ≈ the 19-node Ch. 13 block). This decision swings the lane by tens of nodes; the repaired dossier now quantifies the block (§4) instead of asserting 40–60.
2. **Ch. 14 decision (new, required by the review): analytic identity, not formal-series.** The pin for Jacobi's triple product should be the **analytic identity as printed** — infinite sums and products with **|x| < 1, y ≠ 0** — because the y^{−2} factor is not a formal power series in y and the printed hypotheses are convergence hypotheses. **v1's "pure power-series work with no analysis prerequisites" is retracted**; the chapter requires a convergence transfer (summable infinite products over Mathlib's `hasProd`/`tprod` machinery — already exercised by Mathlib's own pentagonal entry `hasProd_eulerFunction` and by AFP's fps variant for pentagonal, `has_fps_expansion_euler_phi_complex`, which shows the formal-series *derivation* can follow the analytic identity if wanted). Prerequisites line: complex-analysis-free does not mean analysis-free; the schedule must budget the |x|<1 product-convergence layer.
3. **Import rulings + frozen commits (retained, updated).** Freeze at lane start and re-verify: Mathlib at M or later (master moved to `68dd2955f557` during this pass); atlas `18d1aa399b6ebaa8cd9c4a48795b43f6734c3785` (**license = Apache 2.0 + ML-training-use preamble — NOASSERTION on GitHub; explicit ruling required before import**); UyNewNas `88ee563ba0021702ea370b13bae7c7e7fec59657` (moved 70→197 files within five days once already); salt `e7d9a1906772`; girving/interval `2c89204b806f4acd9b8530a38e656369d0a4d7f3` (this pass: 10 files, all sorry-free); AFP entries per §3.5 (release tarballs of 2026-10-26+). Lean pin: leanprover/lean4:v4.34.1 (programme standing rule).
4. **Selberg scope (re-scoped).** The elementary route §§4.10–4.11 + AT2.20 is no longer "genuinely new with no blueprint": AFP 4.17/4.18, Metamath `selberg`, and Avigad et al. are blueprints. It may stay a stretch spike, scoped as port-with-blueprint; the pointwise identity AT2.20 specifically needs a dedicated search before any first-claim.
5. **Statement-fidelity pinning pass (mandatory, unchanged).** Every ⚠ number in §2 re-pinned against the physical 1976-printing/1998-reissue pagination; the three [V] anchors (4.10, 13.15, 14.5) stay; all reconstructed numbers remain provisional until then. The unfinished rows (AT4.14–16, AT12.18–20, AT13.2–13, AT13.16–17 constants) must be completed from the printing before they can be pinned — they are research reminders, not statements.

### Schedule (corrected from v1)

Keep v1's dependency-first order with two corrections: **Ch. 14 is not "no analysis prerequisites"** (budget the |x|<1 convergence layer; do JTP after or with the Ch. 11 half-plane machinery, or pin it analytic-upfront per decision 2), and **Ch. 4's §§4.10–4.11 is a port-with-blueprint spike** (AFP/Metamath), not new-to-everyone mathematics. Ch. 7's "100% covered" is corrected to "main theorem covered upstream; asymptotic form not" (§4).

### Risks (revised)

1. **Route-fidelity risk (Ch. 11–13)** — unchanged in substance, now with auditable block sizes (§4): the literal-route blocks are 17/18/19 unverified nodes respectively.
2. **Prior-art acceleration risk, sharpened:** the last six weeks landed pentagonal, Wiener–Ikehara, Perron (AFP), Rademacher (AFP), PNT-with-remainder (AFP 2024), the 2^α primitive-root completion — the de-risked content of this book is on a clear absorption path; a lane that waits loses firsts, a lane that starts must re-verify every frozen SHA at launch.
3. **License/attribution risk (atlas preamble; UyNewNas drift)** — unchanged; rulings before imports, SHAs frozen.
4. **Novelty-claim risk (new):** this programme's reviews have twice caught overstated novelty (Selberg here). Any residual "first" claim in a future charter must carry its own recorded search (queries + dates), bounded like §3.7.

---

## §7 Source register (all live checks 2026-11-10 ≈18:05–18:35 UTC, artifacts + sha256 in `prefetch-v2/MANIFEST.txt`)

| Source | Reference | Access |
|---|---|---|
| Springer book page + front matter | DOI 10.1007/978-1-4757-5579-4 | **unreachable this pass** (bot-challenge HTML, 3,038 B ×2); v1's morning capture carried |
| mathlib4 | M = `862047ba60dbfd5ec316433fb728e310612e6449` (2026-11-10T11:56:22Z); master at pass end `68dd2955f557` (17:26:40Z); commits `822e8564`, `98ef485d`, `d4bda671`, `95153009` (§3.1) | gh api + raw |
| atlas-lean | `18d1aa399b6ebaa8cd9c4a48795b43f6734c3785` (2026-11-05T21:17:41Z); LICENSE captured | gh api + raw |
| UyNewNas/analytic-number-theory-lean | `32e538c6…` (70 .lean), `88ee563b…` (197 .lean) | gh api |
| jyh/salt | `e7d9a1906772` (2026-11-08); `Salt/Maynard/Mertens.lean` fetched (0 "Apostol") | raw |
| prove2me/formalpedia | head `acf1cadf94817574ae8d3e7431e847c0685314b6`; all 20 shards of `envs/0df444a/` re-downloaded fresh (435 MB), byte-identical to the morning cache | raw + gh api |
| girving/interval | `2c89204b806f4acd9b8530a38e656369d0a4d7f3` (2026-10-14); 10 EulerMaclaurin files fetched, 0 sorry each | gh api + raw |
| AFP (isa-afp.org) | 18 entry pages (§3.5, publication dates from the pages) + release tarballs for Prime_Distribution_Elementary, Gauss_Sums, Pentagonal_Number_Theorem, Perrons_Formula, Theta_Functions (current releases) | curl -L |
| Metamath | `us.metamath.org/mpeuni/selberg.html` fetched (statement + description transcribed); `dirith`/`pnt*` carried from v1 (51.9 MB file not re-downloaded) | curl -L |
| Palomar Registry | rev 853, release `7b13db9a…`, 1,052/821; `?q=Apostol` → 0; `?id=PALOMAR-2026-10-25-000017` → 0 | data.palomar-registry.org/api/v1 |
| GitHub searches (fresh, authenticated) | repos `Apostol language:Lean` → 0; code `Apostol language:lean` → 25 (saved); code `Apostol language:Isabelle` → 98 (saved); code `Apostol language:Coq` → 3 (saved); repos `Introduction to Analytic Number Theory` → 2 (saved); `ryandv/apostol.mm` @ `75ad655e…` fetched (Calculus Vol. 1) | gh search |
| HOL Light / Coq archive / Freek-100 | carried from v1's 2026-11-10 morning checks (not re-run, except the Coq code search above) | — |
| Prefetch manifest | `prefetch-v2/MANIFEST.txt` — sha256 + bytes per file, 183 files, no directory listings | local |

---

## §8 Repair compliance map (review C1–C12 → where repaired in v2)

| Review ID | Repair in this dossier |
|---|---|
| **C1 (blocking)** — false/incomplete statements | σ_α product: §2 AT2.14 (denominator p^α−1, α=0 case split, counterexample, Mathlib decl note). Euler summation: §2 AT3.1 (−f(x)ψ(x)+f(y)ψ(y), counterexample, interval corroboration at p=1). Bell series: §2 AT2.17–18 (multiplicativity hypotheses, counterexample, φ_p = (1−x)/(1−px), σ_α,p series). Ch. 11 coefficient integral: §2 AT11.16 (complete vertical-mean theorem with 1/(2T) normalization and absolute-convergence hypothesis; counterexample; proof mechanism; book-numbering UNVERIFIED note). Shapiro completed: §2 AT4.8 (sourced from AFP `Shapiro_Tauberian.thy`). van Lint completed: §2 AT14.5 (exact `Partition'_le` statement). Remaining sketches explicitly marked **UNFINISHED — research reminders**: AT4.14–16, AT12.18–20, AT13.2–13, AT13.16–17, AT13.18 (RH, statement-only, numbering unverified). |
| **C2 (blocking)** — Selberg novelty | Retracted: §0.2, §2 AT4.17 + AT2.20, §3.5 (AFP 4.17/4.18 declaration transcript), §5.6 (Metamath `selberg` transcript; Avigad et al. per review). Pointwise identity kept UNVERIFIED-as-absent, never conflated with the asymptotic form; §6 re-scopes the spike as port-with-blueprint. |
| **C3** — node ledger | One method, one total: §1 table — 318 = 70 D + 248 T; Ch. 5 → 7 D, Ch. 12 → 20 T, Ch. 13 → 20 T resolved; every node has a neutral ID; printed count stays UNVERIFIED, all ⚠. |
| **C4** — coverage arithmetic | §4: numerator/denominator per chapter from individually verified nodes only; headline 58 [M] + 3 [E] + 7 [X] = 68/318 DECL-verified anywhere (61/318 Lean); ABSTRACT tier listed but never counted; v1's 62/74/90/~60% withdrawn; "~60% upstream-only" dropped (no numerator existed). |
| **C5** — numbering discipline | §1: neutral IDs vs book numbers; ⚠ on every reconstructed number everywhere (checked in §2's cross-references); [V] anchors only 4.10, 13.15, 14.5; Ch. 13 tail renumbered "⚠ ≥ 13.16 shifted" with explicit no-collision note for verified 13.15. |
| **C6** — quotations | Perron: §5.4 restores the /w (kernel x^w/w), quotes the AFP *declaration* (`perron_asymp`) rather than the abstract, and documents the abstract's faulty `x^s w` typography with a do-not-promote rule. Mathlib Dirichlet quotation: §5.2 relabeled a **summary** with the citable declaration names. PNT quotation verified against the live abstract (§5.1). |
| **C7** — evidence gaps | Both closed with records this pass: Mertens 4.10 = Formalpedia record `d09af852-f479-4509-a198-8f0ba56f9115`, index-004.jsonl:3080 (§2 AT4.10, §3.3); Formalpedia Apostol count = 16 records with shard:line table, head `acf1cadf…` unchanged, shards re-downloaded fresh (§3.3). |
| **C8** — chapter negatives | Restated boundedly: §0.1, §3.7 — "no complete fourteen-chapter project identified in the inspected searches"; AFP's Ch. 8-full and Ch. 4(+parts 3) formalizations named as prior art; every negative bounded to the searches listed. |
| **C9** — Palomar | §3.4: NOT FOUND retained at each actually-observed revision (850 per v1; 851 per review; **853 this pass**, release `7b13db9a…`); 850-historical UNVERIFIED; no date-window reasoning; pagination caveat recorded. |
| **C10** — atlas count | §3.1 row 3 + §3.2: 242 top-level (211 files + 31 dirs) at `18d1aa3…`; the 630 recursive count added with its distinct definition. |
| **C11** — coverage-evidence discipline | §4 method (DECL/ABSTRACT tiers; no topic-overlap or empty-file counting); interval sorry-audit completed first-hand (10 files, 0 sorry — §3.6); atlas PNT file sorry-count (0) attached to the one claim it supports; dependency-closure explicitly not claimed (§0 "Not established"). |
| **C12** — recommendation | §6: revised recommendation (conditional, no slot claim), Ch. 14 analytic-vs-formal decision with the convergence transfer (JTP |x|<1, y≠0; AFP restrict-then-continue route as blueprint; "no analysis prerequisites" retracted), prerequisites/schedule/risks revised, both carve-outs retained on repaired foundations, novelty-claim discipline added. |

---

**Rule-compliance footer.** This dossier is a research input; it authorizes no lane. Unmarked-⚠ book numbers herein are reconstructions pending pinning against the physical printing; the three [V] anchors (4.10, 13.15, 14.5) carry their sources at the node. Every live source was checked 2026-11-10 (≈18:05–18:35 UTC) with heads/SHAs as recorded in §7 and artifacts checksummed in `prefetch-v2/MANIFEST.txt`. Claims that could not be verified are marked UNVERIFIED, never asserted. No coding, no Lean, no repo writes, no GitHub writes, no installs were performed; no review was requested, arranged, or contacted — the renewed crossed review is the coordinator's to appoint. Any future proof lane still needs its own frozen pin manifest and crossed review; Lean pin: leanprover/lean4:v4.34.1.

DOSSIER COMPLETE.
