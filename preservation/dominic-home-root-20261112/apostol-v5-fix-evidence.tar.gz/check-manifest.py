#!/usr/bin/env python3
"""Verify a MANIFEST.txt against a directory, handling both programme formats:
  "<sha256> <bytes> <file>"  (sha-first, e.g. Marker fix lane)
  "<file> <bytes> <sha256> <fetched-at>" (file-first, e.g. van Lint fix lane)
  "<sha256>  <file>" (sha256sum format)
Skips blank lines and '#' comments. Usage: check-manifest.py <dir>"""
import sys, hashlib, os

d = sys.argv[1]
man = os.path.join(d, "MANIFEST.txt")
checked = bad = missing = 0
unparsed = 0
for line in open(man, errors="replace"):
    line = line.strip()
    if not line or line.startswith("#"):
        continue
    parts = line.split()
    sha = name = None
    if len(parts[0]) == 64 and all(c in "0123456789abcdef" for c in parts[0]):
        sha = parts[0]
        # "<sha256> <bytes> <file>" or "<sha256>  <file>"; a trailing
        # parenthetical note after the filename is not part of the name.
        name = parts[2] if len(parts) >= 3 and parts[1].isdigit() else parts[1]
    elif len(parts) >= 3 and len(parts[2]) == 64 and all(c in "0123456789abcdef" for c in parts[2]):
        name, sha = parts[0], parts[2]
    else:
        unparsed += 1
        print("UNPARSED:", line[:100])
        continue
    p = os.path.join(d, name)
    if not os.path.isfile(p):
        missing += 1
        print("MANIFEST_MISSING:", name)
        continue
    h = hashlib.sha256(open(p, "rb").read()).hexdigest()
    checked += 1
    if h != sha:
        bad += 1
        print("MANIFEST_MISMATCH:", name)
print(f"MANIFEST_CHECK checked={checked} bad={bad} missing={missing} unparsed={unparsed}")
