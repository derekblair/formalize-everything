FAIL

The repair makes substantial progress, including the Selberg retraction and the analytic Chapter 14 decision, but **v2 is not sound as the promised statement inventory or verified coverage ledger**. False Ramanujan/Gauss-sum formulas remain; the Mertens coverage citation proves only one side of the counted theorem; and the PNT prior-art comparison misidentifies a classical zero-free region as Vinogradov–Korobov. These are material failures under the supplied verdict rules, independently of the evidence-delivery gaps. The integration-project idea remains plausible; this dossier cannot yet support pinning. Sources and repair dispositions follow.

Review for Derek Blair, formalize-everything #67, appointed by the coordinator. All independent source retrievals below were made **2026-11-10**. Reviewed artifact: [DOSSIER-APOSTOL-v2.md](DOSSIER-APOSTOL-v2.md), **522 lines**, SHA256 **`7cc27b0201c5b6ba13d01f05165ccd1439f7da11226c84092d02a49198f7f13a`**. The first 25 lines of [run-review.log](run-review.log) record **model `gpt-6-astra`, provider `openai`, reasoning effort `ultra`**. This verifies the serving transcript, not merely a requested setting. The launcher's gmail-pool designation is recorded; its quota percentage was not remeasured. This was a Codex review of GLM-authored work, not self-review. Three delegated evidence audits belong to this appointed review, not to separately arranged crossed reviews. [Recorded provenance and checks](review-evidence/root/audit-output.json).

## Evidence boundary and recorded checks

The supplied prefetch package does **not** contain all the artifacts described in the brief. `evidence/` initially contained four files: the issue JSON, comments JSON, repository HEAD record, and dossier line-count record. `evidence/MANIFEST.txt` does not exist. The delivered `prefetch-v2-MANIFEST.txt` lists **183** artifacts, but **zero** are present at its claimed `prefetch-v2/` paths. Its own SHA256 is **`c2c981a63568772fd92b6b4901b6129a577f8277b1d5e5459758a3ee193c2114`**. This is a delivery/verification gap; it does not establish that the author never performed the reported checks. [Audit script](review-evidence/root/audit.py), [output](review-evidence/root/audit-output.json), [delivered manifest](prefetch-v2-MANIFEST.txt), [launcher](run.sh).

The independent shell sample ran:

```text
curl -L --max-time 15 -sS -o /dev/null -w 'HTTP %{http_code}\n' https://www.isa-afp.org/entries/Prime_Distribution_Elementary.html
exit status: 6
stdout: HTTP 000
stderr: curl: (6) Could not resolve host: www.isa-afp.org
```

Connected GitHub and Firecrawl retrievals nevertheless worked. They recovered primary sources without changing sandbox settings. **57 retrieved source files match the fix manifest byte-for-byte:** 46 Mathlib files at **M = `862047ba60dbfd5ec316433fb728e310612e6449`**, all ten `girving/interval` Euler–Maclaurin files at **`2c89204b806f4acd9b8530a38e656369d0a4d7f3`**, and atlas's PNT file at **`18d1aa399b6ebaa8cd9c4a48795b43f6734c3785`**. AFP evidence consists of independently retrieved registry entry/theory pages, not reconstructed claims to have checked missing tarballs. Some connector responses used same-day caches; capture metadata is retained. [Source hash comparisons](review-evidence/ledger/source-hash-checks.json), [AFP capture index](review-evidence/afp/capture-index.tsv), [AFP checksums](review-evidence/afp/SHA256SUMS).

Recorded recomputations: `python3 review-evidence/root/audit.py` and `python3 review-evidence/ledger/recompute.py`, both exit **0**; inputs, scripts and full outputs are retained in [audit-output.json](review-evidence/root/audit-output.json) and [recompute.log](review-evidence/ledger/recompute.log). The latter binds the dossier hash, expands its IDs, recomputes coverage, verifies source hashes and runs the stripped lexical screen. Counterexamples were independently recomputed by `python3 review-evidence/math/recompute.py`, exit **0**, with [literal inputs/script](review-evidence/math/recompute.py) and [output](review-evidence/math/recompute-output.txt). An additional direct-file screen ran as `python3 review-evidence/ledger/screen_extra.py`, exit **0**, with [recorded output](review-evidence/ledger/screen-extra.log). No Lean build, proof-assistant execution, installation, repository modification, GitHub write or merge was performed. Research captures and audit scripts are evidence artifacts only.

## Corrections required

All blocking/major items below must be fixed before pinning. A correct repair in one row does not cure another false statement in the inventory.

| ID | Finding | Severity / pinning consequence |
|---|---|---|
| R1 | False statements and omitted hypotheses remain in the claimed exact-hypothesis ledger; not all remaining sketches are marked UNFINISHED. | **Blocking**; C1 not fully repaired. |
| R2 | Coverage arithmetic adds correctly, but several cited declarations do not prove the whole node counted. | **Blocking**; C4/C11 not repaired semantically; withdraw the verified 61/68 headlines pending remapping. |
| R3 | AFP's zero-free region is classical inverse-logarithmic, not VK-shaped. Mathlib already has closed-half-plane ζ nonvanishing at M. | **Blocking** false prior-art claims; revise Ch.13 scope and C12 estimates. |
| R4 | The pointwise Selberg identity is already Metamath theorem `logsqvma2`. | **Major** new positive evidence; remove it from prospective first-to-any-assistant candidates. |
| R5 | Pólya–Vinogradov is quoted with the source's explicitly criticized Big-O quantifier ambiguity. | **Major** before pinning: use a uniform explicit statement. |
| R6 | The 183-artifact package is incomplete as delivered; Formalpedia's global 16-record count and historical Palomar revision 853 are not independently reproduced. | **Major evidence gaps**; supply artifacts or retain UNVERIFIED labels. |
| R7 | Ch.14's actual blueprint requires holomorphy/identity-theorem machinery; the purported 17/18/19 route-block sizes are not inventories of exact uncovered route lemmas. | **Major** schedule/scope correction. |
| R8 | §6 says both “not open as a book” and “would still be the first”; the latter exceeds bounded searches. Several supposedly last-six-week results are much older. | **Moderate**, fix before using novelty/timing rationale. |
| R9 | Euler-summation corroboration incorrectly identifies periodized B₁ with the fractional part. | **Moderate** source derivation error; the repaired summation formula itself is correct. |

**R1: retained mathematical failures.** Dossier line 199 gives both `Σ(d|k) s_d(n) = [k|n]` and `Σ(d|k)|s_d(n)|² = k(k,n)`. With **k=n=2**, the defining Ramanujan sums are `s₁(2)=s₂(2)=1`. The first claimed equality is **2=1** and the second **2=4**. The correct first identity has **k[k|n]** on the right. This is not a numbering issue. AFP's `Ramanujan_Sums.thy`, `ramanujan_sum_dirichlet_form`, gives `s_k(n)=Σ(d|gcd(n,k))dμ(k/d)`; summing it over divisors of k and applying Möbius cancellation yields the corrected identity. [Primary theory](https://www.isa-afp.org/thys/Gauss_Sums/Ramanujan_Sums.html), [capture](review-evidence/afp/Ramanujan_theory.md), [dossier claim](DOSSIER-APOSTOL-v2.md:199).

The same row says primitive characters give `|G(n,χ)|=√k` **for all n**. For the primitive nonprincipal character modulo 3, take frequency n=3: `χ(1)=1`, `χ(2)=−1`, and both exponential factors equal 1, so **G(3,χ)=0**, not √3. AFP's `primitive_encoding` explicitly makes the sum zero at positive noncoprime frequencies; square-root magnitude applies at coprime frequencies. Earlier AT8.10–11 also omit primitivity from their magnitude assertion. [Gauss_Sums, `primitive_encoding`](https://www.isa-afp.org/thys/Gauss_Sums/Gauss_Sums.html), [capture](review-evidence/afp/Gauss_theory.md:515).

AT4.11–12 uses the same B from `Σ(p≤x)1/p=log log x+B+O(1/log x)` in the product constant `e^(−B)`. This cannot follow: writing `R=Σ_p(log(1−1/p)+1/p)` gives a convergent **strictly negative** correction, hence the product constant is `e^(R−B)`, not `e^(−B)`. Convergence follows from the O(1/p²) logarithm remainder and R<0 already from its p=2 term. This independently refutes the displayed constant using the row's own premise, without requiring a separate evaluation of R. The two-sided reciprocal-prime premise is independently present in AFP's `mertens_second_theorem`. [Dossier](DOSSIER-APOSTOL-v2.md:164), [Mertens theory](https://www.isa-afp.org/thys/Prime_Number_Theorem/Mertens_Theorems.html).

The incomplete-row rule is also not implemented globally. Examples without an UNFINISHED designation include AT11.13–15 (“mean-value / partial-sum formulas”), AT5.16–18 (“prime-power lifting (Hensel-type)”), AT13.8's unspecified truncation, and AT13.19's unspecified error sharpening. §8 claims AT13.2–13 are marked unfinished, but AT13.8 is not. These are research labels, not exact-hypothesis statements. **C1's general demand is not satisfied by repairing only its four original counterexamples.** [Dossier](DOSSIER-APOSTOL-v2.md:233), [v1 C1 demand](REVIEW-APOSTOL-v1.md:12).

**R2: coverage mismatches, independently sampled.**

| Counted node | What the cited evidence actually establishes | Required disposition |
|---|---|---|
| AT4.10, full Mertens I `Σ log p/p = log x+O(1)` | Formalpedia record `d09af852-f479-4509-a198-8f0ba56f9115` and Salt's `sum_log_div_prime_le` give only `Σ(p≤N)log p/p ≤ log N+log 4+4`. | Do not count the full two-sided node as proved in Lean by that citation. AFP has a full statement, but that changes the assistant/category and requires an explicit remap. |
| AT11.11, general exponential representation | §4 itself labels the ζ-only evidence **partial**, then counts it as a full node. | Split the node or mark partial and exclude it from a full-node numerator. |
| AT12.4 | Inventory: analyticity **and integral representation**. Coverage table: continuation/residue from `HurwitzZeta.lean`, which is principally AT12.6's content. | Fix the ID/content match and establish the integral formula separately. |
| AT12.12 | Inventory includes general Hurwitz/Bernoulli special values; cited `riemannZeta_neg_two_mul_nat_add_one` and `riemannZeta_zero` concern Riemann ζ at negative even integers and zero. | These declarations alone do not cover the whole row. |
| AT10.4 | Inventory includes the universal exponent bound for odd residues modulo 2^α; cited `isCyclic_units_two_pow_iff` only characterizes cyclicity. | Supply the missing exponent theorem/derivation rather than treating this declaration as an exact match. |

Sources: [Formalpedia statement at `acf1cadf94817574ae8d3e7431e847c0685314b6`](https://github.com/prove2me/formalpedia/blob/acf1cadf94817574ae8d3e7431e847c0685314b6/envs/0df444a/Theorems/Thm_MertensTheorems_sum_log_div_prime_le.lean); [Salt at `e7d9a19067725884e4689f9c3bb231b3e14c591b`, `Salt/Maynard/Mertens.lean`](https://github.com/jyh/salt/blob/e7d9a19067725884e4689f9c3bb231b3e14c591b/Salt/Maynard/Mertens.lean); Mathlib at M: [HurwitzZeta.lean](https://github.com/leanprover-community/mathlib4/blob/862047ba60dbfd5ec316433fb728e310612e6449/Mathlib/NumberTheory/LSeries/HurwitzZeta.lean), [RiemannZeta.lean](https://github.com/leanprover-community/mathlib4/blob/862047ba60dbfd5ec316433fb728e310612e6449/Mathlib/NumberTheory/LSeries/RiemannZeta.lean), [UnitsCyclic.lean](https://github.com/leanprover-community/mathlib4/blob/862047ba60dbfd5ec316433fb728e310612e6449/Mathlib/RingTheory/ZMod/UnitsCyclic.lean); [dossier coverage rows](DOSSIER-APOSTOL-v2.md:412). These are evidence/strength mismatches, not assertions that the stronger results are absent everywhere.

**R3: two directly false Ch.13 claims.** AFP `PNT_with_Remainder/Zeta_Zerofree.thy`, final `zeta_nonzero_region`, proves that a zero β+iγ≠1 satisfies

`1−β ≥ (1/952320)/log(|γ|+2)`.

This is the classical inverse-log shape. `PNT_Notation.thy` defines the constant. The explicit PNT error `O(x exp(−√(log x)/3653))` is correctly quoted, but the appended “stronger, VK-shaped” comparison at dossier lines 264 and 426 is false. The source also uses Perron and rectangle contours; exact equality with Apostol's complete ψ₁ proof route remains **UNVERIFIED**, not disproved by a nonexistent VK distinction. [Zero-free theorem](https://www.isa-afp.org/thys/PNT_with_Remainder/Zeta_Zerofree.html), [constants](https://www.isa-afp.org/thys/PNT_with_Remainder/PNT_Notation.html), [PNT proof](https://www.isa-afp.org/thys/PNT_with_Remainder/PNT_with_Remainder.html).

Moreover, dossier line 415 says there is no σ=1-line ζ nonvanishing at M. **M's `LSeries/Nonvanishing.lean`, lines 417–421, contains `riemannZeta_ne_zero_of_one_le_re`**, with hypothesis `1 ≤ s.re`. Its value at s=1 is an explicitly documented totalization convention; the genuine boundary nonvanishing for s≠1 is included. This captured file exactly matches the author's manifest hash `66b7ee2e318a271508deb0aa5dcbea2193ead4795480e5f6bea738cab2572d34`. Thus the contradiction is at the dossier's own snapshot, not later library drift. [Pinned source](https://github.com/leanprover-community/mathlib4/blob/862047ba60dbfd5ec316433fb728e310612e6449/Mathlib/NumberTheory/LSeries/Nonvanishing.lean#L417), [local source](review-evidence/root/Mathlib_NumberTheory_LSeries_Nonvanishing.lean:417).

**R4: pointwise Selberg has a blueprint too.** Following proof step 88 of Metamath `selberg` reaches **`logsqvma2`**, which states for positive N:

`Σ(d|N) μ(d) log²(N/d) = Σ(d|N) Λ(d)Λ(N/d) + Λ(N)log N`.

That is AT2.20, with sides/order rearranged. The registry credits Mario Carneiro, **2016-05-13**, citing Shapiro equation 10.4.8, p.418. V2's “absence UNVERIFIED” qualifier was appropriate; the newly located positive evidence now removes this candidate from the novelty list. It is a dependency of a page the dossier already cites. [Metamath `logsqvma2`](https://us.metamath.org/mpeuni/logsqvma2.html), [capture](review-evidence/afp/Metamath_pointwise_selberg.md).

## C1–C12 repair-compliance audit

The map contains **all twelve** required IDs, each once; no C item is omitted. The following distinguishes a written retraction/repair from evidence that actually closes the demand. [Recorded map extraction](review-evidence/ledger/recompute.log).

| C item | Independent disposition |
|---|---|
| **C1** | **NOT CLOSED, blocking.** The four original repairs are mathematically substantially correct, with counterexamples retained; Shapiro and van Lint are completed. R1/R9 and the remaining unmarked sketches prevent closure. |
| **C2** | **CLOSED for the demanded asymptotic retraction.** AFP `selberg_asymptotic_formula`, labeled 4.18, and Metamath `selberg` independently verified. R4 adds pointwise prior art; it does not invalidate the successful retraction. |
| **C3** | **CLOSED as an internal provisional ledger.** 70 definitions +248 theorem/statement IDs =318, consistent across tables and expanded §2 IDs. This does not verify the printed-book inventory; grouped sketches and RH's statement-only classification still require pinning. |
| **C4** | **NOT CLOSED, blocking.** Numerical sums/rounding are correct, but the alleged full-node DECL lower bound has strength/ID mismatches (R2). No replacement total is asserted by this review. |
| **C5** | **Substantially closed.** Neutral AD/AT IDs distinguish provisional inventory from three [V] book anchors; 13.15 is no longer reused as a zero-free-region number. Explicitly historical reconstructed sequences are still printed without individual ⚠ symbols in narrative, so the literal “every cross-reference” claim is too strong, but those passages are not presented as verified. AFP source labels 4.17/4.18 are independently corroborated. |
| **C6** | **CLOSED for the required quotation fixes.** Perron's `/s` kernel and convergence hypothesis match the source declaration; Mathlib Dirichlet is correctly labeled a summary. The PNT excerpt/error matches its source, but R3's appended strength/route claim does not. |
| **C7** | **PARTIAL, evidence/strength issues.** Mertens 4.10's citation anchor is recovered, including the exact Formalpedia statement file and an independent AFP 4.10 label. It is not full Lean Mertens I coverage. The 16-record whole-index count remains UNVERIFIED without the 20 raw shards; see R6. |
| **C8** | **PARTIAL.** The chapter-level retraction is supported by AFP's explicit Ch.8 and Ch.4 descriptions. Fresh searches find no complete book project; they cannot justify §6's definite first-complete claim. The “not open” sentence also contradicts its own continuation (R8). |
| **C9** | **Method repaired; historical value UNVERIFIED.** Date-window reasoning is removed. Fresh queries reproduce NOT FOUND at **revision 855**, not 853; no retroactive certification of 850/851/853 is made. |
| **C10** | **CLOSED.** Independently retrieved atlas directory/tree: 242 top-level entries =211 files+31 directories; 630 recursive entries, untruncated, at the stated full SHA. |
| **C11** | **NOT CLOSED, blocking for coverage.** Ten interval files and atlas PNT were fetched and screened; their direct-file zero-sorry observations are supported. That does not repair R2's partial-node counting or establish dependency closure. |
| **C12** | **PARTIAL, not acceptable as the present pinning rationale.** The changed objective, two carve-outs and analytic Ch.14 choice are sensible. R1–R8 require corrected evidence, scope and scheduling before the conditional recommendation can be operationalized. |

Primary checks beyond mandatory C1/C2/C12 include **C6** pinned Perron/Dirichlet statements, **C7** Formalpedia/Salt statement strength, **C8** fresh GitHub searches and AFP chapter claims, **C9** live Palomar queries, **C10** pinned atlas tree counts, and **C11** 57 hash-matched source files plus the stripped screen. Internal C3/C4 arithmetic is additionally recorded. [Ledger audit](audit-ledger.md), [mathematical audit](audit-math.md), [AFP audit](audit-afp.md).

## Repaired-formula sample and the three [V] anchors

**Divisor sum.** AT2.14's denominator `p^α−1` and separate α=0 case are correct for real α and n≥1; state those domains explicitly. At n=2, α=1 the repaired answer is **3** and v1's answer is **1**. Independently, multiplying finite geometric sums over prime powers proves the real-exponent expression. Mathlib's cited `ArithmeticFunction.sigma_apply_prime_pow` agrees on its actual domain **k:ℕ**; it does not alone certify arbitrary real α. Preserve that source-strength distinction. The general exceptional condition `p^α=1` is sound, but its equivalence to α=0 would fail for unrestricted complex α, for example α=2πi/log p. [M, `ArithmeticFunction/Misc.lean`](https://github.com/leanprover-community/mathlib4/blob/862047ba60dbfd5ec316433fb728e310612e6449/Mathlib/NumberTheory/ArithmeticFunction/Misc.lean), [dossier repair](DOSSIER-APOSTOL-v2.md:111).

**Euler summation.** The corrected endpoint signs are right. With f=1, y=1, x=3/2 the sum is **0**, v1 RHS **1**, repaired RHS **0**. The pinned interval theorem `sum_Ioc_eq_integral_add_of_hasDerivWithinAt` specializes to the repaired formula. However its sawtooth is **P₁(t)={t}−1/2**, not {t}; the half-endpoint terms cancel using the integral of f′. V2's assertion that the endpoint term alone is already exactly the fractional-part term is incorrect. [Formula.lean at interval SHA above](https://github.com/girving/interval/blob/2c89204b806f4acd9b8530a38e656369d0a4d7f3/Interval/EulerMaclaurin/Formula.lean), [`Bernoulli.lean`, `saw_one`](https://github.com/girving/interval/blob/2c89204b806f4acd9b8530a38e656369d0a4d7f3/Interval/EulerMaclaurin/Bernoulli.lean).

Bell-series multiplicative recovery and `(1−x)/(1−px)` are correct, and the f≡1 / g(6)=2 counterexample correctly detects the missing multiplicativity. The vertical mean with `1/(2T)` is mathematically valid under absolute convergence: termwise integration gives the factor `sin(T log(n/m))/(T log(n/m))`, bounded by 1 and tending to zero off m=n; dominated convergence isolates the coefficient. For F≡1,n=1 its value is exactly 1. **Correction:** “absolute convergence at σ (i.e. σ>σ_a)” should say “for example σ>σ_a”; absolute convergence may also hold on the boundary. Book-number/page provenance for this particular standalone theorem remains UNVERIFIED, as v2 acknowledges. These are independent mathematical checks of the displayed formulas, not claims to have seen the physical book. [Dossier statements/counterexamples](DOSSIER-APOSTOL-v2.md:114), [vertical mean](DOSSIER-APOSTOL-v2.md:234), [math audit and recorded calculations](audit-math.md).

| Anchor | Independent result |
|---|---|
| **4.10, Mertens I** | The Formalpedia theorem-file metadata at `acf1cadf94817574ae8d3e7431e847c0685314b6` explicitly cites Apostol 4.10; AFP `Shapiro_Tauberian.thy` independently labels the θ interpretation 4.10. **Citation anchor verified; counted Lean strength not verified and in fact only one-sided.** The Formalpedia `.lean` is a statement fixture with `sorry`, not the extracted proof; the actual Salt upper-bound proof was separately read. [Formalpedia file](https://github.com/prove2me/formalpedia/blob/acf1cadf94817574ae8d3e7431e847c0685314b6/envs/0df444a/Theorems/Thm_MertensTheorems_sum_log_div_prime_le.lean), [AFP Shapiro](https://www.isa-afp.org/thys/Prime_Distribution_Elementary/Shapiro_Tauberian.html). |
| **13.15, Pólya–Vinogradov** | AFP explicitly names 13.15 and proves primitive constant 1, conductor refinement, and the general uniform bound **`∥Σ(m=1..x)χ(m)∥ < 2√n log n`** for nonprincipal χ. Its prose expressly warns that fixed-modulus Big-O can be vacuous. Use the explicit uniform theorem for a pin, rather than copying the ambiguous book paraphrase. [AFP `Polya_Vinogradov`](https://www.isa-afp.org/thys/Gauss_Sums/Polya_Vinogradov.html), [capture](review-evidence/math/Polya_Vinogradov.md:814). |
| **14.5, van Lint** | AFP names the book theorem and attribution, and `Partition'_le` gives exactly **n>1 ⇒ p(n)≤π exp(π√(2n/3))/√(6(n−1))**. The completed dossier row matches. Physical-printing transcription remains distinct from this verified secondary formal-source anchor. [AFP partition theory](https://www.isa-afp.org/thys/Pentagonal_Number_Theorem/Pentagonal_Number_Theorem.html), [capture](review-evidence/math/Pentagonal_Number_Theorem.md:424). |

Shapiro's repaired hypotheses and bounds also match its AFP locale and conclusions: nonnegative coefficients, `Σa(n)⌊x/n⌋=x log x+O(x)`, harmonic-weighted asymptotic, and upper/lower linear bounds. [AFP `Shapiro_Tauberian`](https://www.isa-afp.org/thys/Prime_Distribution_Elementary/Shapiro_Tauberian.html). This successful completion does not cure the unrelated retained errors.

## Isabelle coverage and quotation checks

All **18** §3.5 AFP entries exist with the listed publication dates. The complete set follows; entries were inspected at declaration level where stated, with detailed evidence in [audit-afp.md](audit-afp.md). Dates are registry publication dates, checked 2026-11-10, not dates of an alleged new release of the mathematics.

| Entry ID | Published | Independently supported content |
|---|---|---|
| [Perrons_Formula](https://www.isa-afp.org/entries/Perrons_Formula.html) | 2026-06-17 | `perron_asymp` and `perron_effective_strong`; finite-T explicit distance bound. |
| [PNT_with_Remainder](https://www.isa-afp.org/entries/PNT_with_Remainder.html) | 2024-05-05 | Explicit PNT remainder and classical inverse-log zero-free region; declarations inspected. |
| [Gauss_Sums](https://www.isa-afp.org/entries/Gauss_Sums.html) | 2019-12-10 | Entry explicitly identifies a full Ch.8 formalization; Ramanujan/Gauss/Pólya declarations sampled. This validates book-chapter prior art, not the dossier's false paraphrases. |
| [Theta_Functions](https://www.isa-afp.org/entries/Theta_Functions.html) | 2024-12-02 | Analytic JTP, with actual convergence/continuation proof inspected. |
| [Pentagonal_Number_Theorem](https://www.isa-afp.org/entries/Pentagonal_Number_Theorem.html) | 2025-04-23 | JTP → pentagonal identity; analytic-to-fps transfer; `Partition'_recurrence`; `Partition'_le`. |
| [Rademacher_Series](https://www.isa-afp.org/entries/Rademacher_Series.html) | 2026-07-03 | Registry content includes convergent partition series, remainder estimates and asymptotic; depends on the partition entry. Beyond-book content, not extra book nodes. |
| [Dirichlet_L](https://www.isa-afp.org/entries/Dirichlet_L.html) | 2017-12-21 | Characters, L-functions and prime-progression infinitude; Newman nonvanishing route. |
| [Prime_Number_Theorem](https://www.isa-afp.org/entries/Prime_Number_Theorem.html) | 2018-09-19 | Newman PNT; full Mertens I and II, with explicit bounds independently read in `Mertens_Theorems`. |
| [Prime_Distribution_Elementary](https://www.isa-afp.org/entries/Prime_Distribution_Elementary.html) | 2019-02-21 | Ch.4 and parts of Ch.3; Shapiro and Apostol-following Selberg declarations. |
| [Dirichlet_Series](https://www.isa-afp.org/entries/Dirichlet_Series.html) | 2017-10-12 | Much of Ch.2/3/11, as explicitly scoped by the entry. |
| [Euler_MacLaurin](https://www.isa-afp.org/entries/Euler_MacLaurin.html) | 2017-03-10 | General Banach-valued formulas with remainder, beyond the book's first-order summation target. |
| [Zeta_Function](https://www.isa-afp.org/entries/Zeta_Function.html) | 2017-10-12 | Euler–Maclaurin continuation, special values, Hurwitz and reflection formulas; registry scope verified. |
| [Rogers_Ramanujan](https://www.isa-afp.org/entries/Rogers_Ramanujan.html) | 2024-12-02 | Rogers–Ramanujan identities; registry scope verified. |
| [Combinatorial_Q_Analogues](https://www.isa-afp.org/entries/Combinatorial_Q_Analogues.html) | 2024-12-02 | q-analogues and infinite-product identities; registry scope verified. |
| [Chebyshev_Prime_Bounds](https://www.isa-afp.org/entries/Chebyshev_Prime_Bounds.html) | 2024-09-13 | Explicit Chebyshev bounds; registry scope verified. |
| [Bertrands_Postulate](https://www.isa-afp.org/entries/Bertrands_Postulate.html) | 2017-01-17 | Bertrand, ported from Harrison's HOL Light proof; registry attribution verified. |
| [Prime_Harmonic_Series](https://www.isa-afp.org/entries/Prime_Harmonic_Series.html) | 2015-12-28 | Divergence of the reciprocal-prime series; registry scope verified. |
| [Sum_Of_Squares_Count](https://www.isa-afp.org/entries/Sum_Of_Squares_Count.html) | 2024-11-26 | Sum-of-squares counting, specifically Jacobi's two-square theorem; no four-square coverage inferred. |

**Selberg C2:** independent source inspection confirms the Apostol-following AFP inversion labeled 4.17 and asymptotic theorem labeled 4.18. Metamath `selberg` supplies the symmetry form with Shapiro equation 10.4.10, p.419, contribution date 2016-05-23. The dossier correctly retracts novelty for the asymptotic result. [AFP theory](https://www.isa-afp.org/thys/Prime_Distribution_Elementary/Selberg_Asymptotic_Formula.html), [Metamath `selberg`](https://us.metamath.org/mpeuni/selberg.html).

**Two mandatory verbatim-source checks:** (1) the PNT excerpt in §5.1 agrees with the AFP abstract, including **3653 outside √(log x)**; mathematical markup was checked against HTML and the theorem, since text extraction can lose radicals. The appended VK sentence fails separately. (2) §5.4's Perron declaration matches the theory modulo glyph/whitespace rendering: c>0, x>0, Re(z)+c above the ordinary convergence abscissa, kernel **F(z+s)x^s/s**, and the limit equal to **2πi times the primed sum**. The primed convention gives half weight at integer x. `perron_effective_strong` uses the absolute abscissa and T>0. The source abstract itself has malformed kernel typography; v2 correctly warns against pinning it. [PNT source/theorem](https://www.isa-afp.org/thys/PNT_with_Remainder/PNT_with_Remainder.html), [Perron source](https://www.isa-afp.org/thys/Perrons_Formula/Perrons_Formula.html), [Perron capture](review-evidence/afp/Perron_theory.md:996).

The Dirichlet summary was additionally checked at M: `forall_exists_prime_gt_and_zmodEq` has q≠0, coprimality, and **∀ threshold n, ∃ prime p>n** in the progression; it is infinitude, not the AT7.9 asymptotic. [Pinned `PrimesInAP.lean`](https://github.com/leanprover-community/mathlib4/blob/862047ba60dbfd5ec316433fb728e310612e6449/Mathlib/NumberTheory/LSeries/PrimesInAP.lean#L451).

## Recommendation verdict, Chapter 14, and search limits

**Recommendation verdict: defensible project concept; not supported for pinning by this version's inventory or feasibility numbers.** The evidence strongly supports abandoning a novelty-first rationale: substantial signature mathematics already exists in Isabelle and Metamath. That is a sound prioritization judgment under a maximal-new-to-any-assistant criterion, not a proved comparison with every other candidate book. No comparative dossiers were supplied here. A statement-complete Lean integration project can still be valuable, conditional on a corrected inventory and the two stated decisions about proof routes and frozen external imports/licenses. [Recommendation-critical sources above; dossier §6](DOSSIER-APOSTOL-v2.md:450).

The analytic JTP choice is coherent. Substituting **q=x, w=y²** in `jacobi_theta_nome_triple_product_complex` yields the dossier's identity on **|x|<1, y≠0**. AFP first proves it for real **0<q<1/4, 1/2<w<1**, establishes absolute summability to exchange double sums, then uses analytic continuation first in **w on ℂ\{0}**, then in **q on the unit disk**. Thus the “no analysis prerequisites” retraction is correct. The actual blueprint needs infinite sum/product convergence, holomorphic dependence and the identity theorem; add these explicitly to the schedule if that route is selected. A Laurent-series coefficient ring could accommodate negative powers of y, so y⁻² alone is not an impossibility theorem about formal approaches. It does not change the appropriateness of the selected analytic target. [AFP JTP theorem/proof](https://www.isa-afp.org/thys/Theta_Functions/Jacobi_Triple_Product.html), [capture](review-evidence/afp/JTP_theory.md:331).

Material prerequisites still missing or unreliable:

1. Separate **alternative proofs of the same statements** from **omitting intermediate book statements**. A statement-complete charter cannot drop independently required contour/estimate lemmas merely because PNT is imported. Rebuild those nodes before assigning a route cost.
2. Replace the alleged 17/18/19 route blocks with exact, nonoverlapping statements and dependency edges. They are chapter remainders under a flawed count, not verified route costs; Ch.13 includes unrelated/tail/unfinished content. Correct the already-present ζ boundary theorem and classical AFP route evidence.
3. Remove pointwise Selberg from residual first-to-any-assistant candidates; retain bounded uncertainty for other unlocated topics rather than asserting novelty.
4. Keep frozen SHAs, license decisions, version compatibility and eventual dependency/build/axiom checks as launch prerequisites. This review performs no legal ruling or proof-lane authorization. Direct-file lexical cleanliness cannot replace those checks.
5. Correct the timing argument. Perron (June 17), Rademacher (July 3), and PNT-with-remainder (May 5, 2024) were not first published in the last six weeks. Current release refreshes do not make old mathematics newly formalized. [Registry dates above; recorded date arithmetic](review-evidence/root/audit-output.json).

**Fresh bounded search:** independent GitHub repository searches for `Apostol language:Lean`, `Apostol language:Isabelle`, and `Apostol language:Coq` each returned zero; the exact book-title repository query returned two. Code searches returned 25 Lean hits, six Isabelle hits for the exact-title query, and three Coq hits, with `incomplete_results:false`; query/result records are retained. The differing Isabelle count is from a different query than v2's broad author-name query and is not a contradiction. No complete fourteen-chapter project was identified in this pass. That supports only **not found in these searches**, never a universal zero or guaranteed first-complete claim. [Queries and outputs](review-evidence/ledger/search-repos-0.json), [code results](review-evidence/ledger/search-code-0.json), [full interpretation](audit-ledger.md).

Palomar independently returned empty results for `q=Apostol` and `id=PALOMAR-2026-10-25-000017` at **revision 855**, release **`94992346d1089ae5922ee609e14d6e715f0db75a24aa0e0690bbdfbfb921e191`**, totals **1,054 results /823 projects**. This confirms a current bounded negative; v2's historical revision 853 remains **UNVERIFIED** here because its raw response is missing. [Recorded query responses](review-evidence/ledger/palomar-0.json), [ID response](review-evidence/ledger/palomar-1.json), registry endpoint `https://data.palomar-registry.org/api/v1/results`.

Additional evidence limits are **CORRECTIONS, not silently accepted claims**: Formalpedia's whole-index total of 16, including its nine/three/four categorization, has not been recomputed from the absent shards; physical-book page/section/number fidelity beyond the three sourced anchors remains unverified; v1-carried HOL/Coq/Metamath observations not freshly examined here retain only their attributed v1 provenance. Untested per-node coverage and broad absence/route assertions receive no independent certification from this review. The 57-file hash match does not restore the rest of the 183-artifact package.

## Internal arithmetic and consistency

Expanding §2's neutral-ID ranges gives **exactly 318 unique IDs =70 D+248 T**. The §1 ledger and §0 headline agree. §5's five main items point to existing neutral IDs; Selberg is an explicitly additional sixth discussion. The §8 C-map has twelve distinct entries. These are checks of the provisional dossier, not of printed-book theorem counts. [Script and output](review-evidence/ledger/recompute.log).

| Ch. | Nodes | M | E | X | Nodes minus M/E/X |
|---|---:|---:|---:|---:|---:|
| 1 | 17 | 4 | 0 | 0 | 13 |
| 2 | 34 | 13 | 0 | 0 | 21 |
| 3 | 16 | 0 | 1 | 0 | 15 |
| 4 | 22 | 4 | 1 | 2 | 15 |
| 5 | 27 | 3 | 0 | 0 | 24 |
| 6 | 23 | 3 | 0 | 0 | 20 |
| 7 | 10 | 1 | 0 | 0 | 9 |
| 8 | 30 | 2 | 0 | 0 | 28 |
| 9 | 31 | 5 | 0 | 0 | 26 |
| 10 | 24 | 7 | 0 | 0 | 17 |
| 11 | 22 | 4 | 0 | 1 | 17 |
| 12 | 25 | 7 | 0 | 0 | 18 |
| 13 | 21 | 0 | 1 | 1 | 19 |
| 14 | 16 | 5 | 0 | 3 | 8 |
| **Total** | **318** | **58** | **3** | **7** | **250** |

The dossier's rounding is correct: M **18.2%**, E **0.9%**, M+E **19.2%**, X **2.2%**, all **21.4%**. **These recomputed figures validate arithmetic only, not coverage.** R2 prevents retaining the “verified lower bound” label.

Two further consistency corrections: §4 defines its unverified remainder as excluding ABSTRACT-supported nodes, but computes it as merely nodes minus DECL counts (e.g. 28 for Ch.8 despite the whole-chapter abstract). Rename it “not declaration-matched” or calculate the stated set difference. Its later Ch.3 “13 unverified nodes” also conflicts with table remainder **15** and with **12** theorem IDs AT3.2–13 after removing AT3.1. [Dossier coverage method/table/narrative](DOSSIER-APOSTOL-v2.md:391), [recomputation](review-evidence/ledger/recompute.log).

## Acceptance annex dispositions A–E

**A — Recorded-output evidence.** Addressed under the supplied literature-review adaptation. Dossier/hash/manifest binding, exact network command and exit status, recovered source files/hashes, and arithmetic scripts/inputs/outputs are attached above. **Build command, toolchain-bound build output and `#print axioms`: NOT APPLICABLE / NOT RUN**, because this is not a Lean artifact and Lean work on xavier was forbidden. The dossier's future `leanprover/lean4:v4.34.1` pin is not a toolchain under which this review built anything. Missing artifacts and unperformed dependency audits are explicitly unverified; no PASS is inferred from commands without output.

**B — Vacuity/hypothesis screen.**

| Required pattern | Result and evidence |
|---|---|
| Hidden hypotheses in types/scope | **FOUND.** Ch.8 magnitude claims omit primitivity/coprimality; AFP's `primitive_encoding` makes the missing conditions substantive. Mathlib's σ exponent is natural, whereas the repaired ledger formula permits real exponents. Preserve that translation obligation. |
| Vacuous branches/coverage | **FOUND as a statement/coverage risk.** The quoted fixed-character Big-O for PV leaves uniformity unclear; AFP explicitly warns it can be vacuous. R2 counts a one-sided theorem and partial specializations as full nodes. The actual AFP general PV bound has a universal constant 2 and does meaningful work. No claim is made that AFP's proof is vacuous. |
| Regularity/positivity/nonvanishing asserted instead of established | **FOUND in the retained Gauss-sum assertions:** the purported positive √k norm is zero at noncoprime frequency. **CLEAR in the sampled completed Shapiro/JTP pins:** nonnegativity is an explicit Shapiro hypothesis; AFP actually establishes JTP convergence and holomorphy before continuation. |
| Quantifier order/constants/advice | Dirichlet's ∀ threshold/∃ prime order matches its source. Pin PV with constant 2 chosen uniformly before modulus/character/cutoff, not an input-dependent Big-O constant. No advice/oracle definition was found in the inspected dossier fragments; uninspected imports receive no such assurance. |

Sources: [AFP Gauss](https://www.isa-afp.org/thys/Gauss_Sums/Gauss_Sums.html), [PV](https://www.isa-afp.org/thys/Gauss_Sums/Polya_Vinogradov.html), [Shapiro](https://www.isa-afp.org/thys/Prime_Distribution_Elementary/Shapiro_Tauberian.html), [JTP](https://www.isa-afp.org/thys/Theta_Functions/Jacobi_Triple_Product.html), pinned Mathlib/Salt sources in R2.

**C — Comment/string-stripped lexical screen.** The recorded scripts remove nested Lean block comments, line comments and string literals while preserving line positions, then scan whole tokens. **78 files** screened: the 57 hash-matched sources, actual Salt Mertens source, Formalpedia's statement fixture, and **19 additional directly cited files**. The latter include atlas's AP/Ramanujan/Apostol-Bernoulli files, all five named UyNewNas Perron files at `88ee563ba0021702ea370b13bae7c7e7fec59657`, Mathlib's named partition/Hensel/quadratic-Gauss files, all four JacobiTheta files, root `Wanted.lean`, and the indexed Farey file. All 19 were reachable and their Git blob hashes match; [exact repository/ref/path provenance](review-evidence/ledger/extra-sources.json) and [recorded checks](review-evidence/ledger/screen-extra.log) are attached. There are **no fenced Lean blocks** in v2; its two fenced declarations are Isabelle. Full per-file counts and line hits are in [lexical-screen.json](review-evidence/ledger/lexical-screen.json) and [lexical-extra.json](review-evidence/ledger/lexical-extra.json); this is not raw grep.

| Token | Active count |
|---|---:|
| sorry | 1 |
| admit | 0 |
| sorryAx | 0 |
| axiom | 0 |
| native_decide | 0 |
| ofReduceBool | 0 |
| implemented_by | 0 |
| unsafe | 0 |

The sole hit is **line 45** of the frozen Formalpedia statement fixture `Thm_MertensTheorems_sum_log_div_prime_le.lean`, SHA256 **`1d8ca57527e3f98364611275d5953d905a46f5f245840d5082d0b048450071f7`**. It is a statement export ending `by sorry`, not a proof module; that occurrence is explained, not evidence of a defective Salt proof. The separately retrieved Salt file has zero listed tokens. All other screened files have zero in each column. **No complete import-closure audit or kernel-axiom audit was performed or claimed**; uninspected dependencies cannot be certified by this direct-source screen, and lexical cleanliness alone does not turn a path-only prior-art observation into verified theorem coverage. [Pinned Formalpedia file](https://github.com/prove2me/formalpedia/blob/acf1cadf94817574ae8d3e7431e847c0685314b6/envs/0df444a/Theorems/Thm_MertensTheorems_sum_log_div_prime_le.lean), [Salt source](https://github.com/jyh/salt/blob/e7d9a19067725884e4689f9c3bb231b3e14c591b/Salt/Maynard/Mertens.lean).

**D — Strength delta for all five hardest targets.** “Strongest” below means the strongest inspected result in the dossier's cited source set, not a new global maximality claim. No result was proved by this review.

| Target | Published/formal source form inspected | Dossier target versus it |
|---|---|---|
| PNT | AFP explicit `π(x)=Li(x)+O(x exp(−√log x/3653))`, classical inverse-log zero-free region. | AT13.14 bare asymptotics are **weaker**; the quoted explicit error is **equal** to its source. The VK characterization is **false**, not a stronger result. Exact Apostol-route identity UNVERIFIED. |
| Dirichlet | Mathlib `forall_exists_prime_gt_and_zmodEq`, arbitrary positive modulus/coprime residue, prime above each threshold; AFP infinitude. | Intended infinitude target **equal**; **weaker than** separately listed AT7.9 PNT-in-progressions asymptotics, which this citation does not prove. |
| Euler summation / Euler–Maclaurin | interval general real-endpoint higher-order formula with explicit derivative/remainder hypotheses; AFP general Banach-valued variants. | Repaired AT3.1 is a **weaker, valid first-order specialization**, with the B₁ cancellation correction R9. |
| Perron | AFP limit under ordinary convergence-abscissa hypothesis; half weights at integers; effective finite-height bound under absolute-abscissa/T>0 hypotheses. | Absolute-convergence/noninteger basic target is **weaker in scope**, with **equal kernel**; integer convention is acknowledged. The unspecified truncated-error node is not an exact-strength pin. |
| JTP | AFP complex identity for w≠0, norm(q)<1 and Ramanujan variant for norm(ab)<1. | Analytic AT14.7 is **equal after q=x,w=y²**. A merely formal-series proof would need a convergence-transfer theorem before claiming this analytic target. |

Sources: [AFP PNT](https://www.isa-afp.org/thys/PNT_with_Remainder/PNT_with_Remainder.html), [Mathlib Dirichlet at M](https://github.com/leanprover-community/mathlib4/blob/862047ba60dbfd5ec316433fb728e310612e6449/Mathlib/NumberTheory/LSeries/PrimesInAP.lean), [interval Formula at fixed SHA](https://github.com/girving/interval/blob/2c89204b806f4acd9b8530a38e656369d0a4d7f3/Interval/EulerMaclaurin/Formula.lean), [AFP Perron](https://www.isa-afp.org/thys/Perrons_Formula/Perrons_Formula.html), [AFP JTP](https://www.isa-afp.org/thys/Theta_Functions/Jacobi_Triple_Product.html).

**E — Provenance honesty.** The delivered v1 review is SHA256 **`29c42b7f803ae8599a94463f2e2b938c6534da852d9d2cf471ed61ba3e39d882`**, verdict FAIL; it is the repair-demand authority, not independent primary evidence for this review. The coordinator's spot-check was not used as proof that our checks ran. V2's GLM authorship and the crossed Codex appointment are recorded in the brief/launch record; this review independently verifies the source samples described above and explicitly records remaining gaps. No claim is made that v1, v2, this review, a registry “Proved” tag, or a source-level screen satisfies a proof lane's build/axiom gate. The coordinator retains posting and slot decisions. [V1 review](REVIEW-APOSTOL-v1.md), [brief](BRIEF.md), [recorded source/output hashes](review-evidence/root/audit-output.json).

**Final disposition:** repair R1–R9, remap full/partial statement coverage, and supply the missing evidence before renewed pinning use. The conditional integration idea survives; the present dossier does not. This review authorizes no proof lane, and any future lane still requires its own frozen pin manifest and coordinator-appointed crossed review.

FAIL
REVIEW COMPLETE.
