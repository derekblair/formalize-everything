# DOSSIER-APOSTOL-v3 — T. M. Apostol, *Introduction to Analytic Number Theory* (Springer UTM, 1976): repaired dossier, second fix pass

**Task:** formalize-everything #67, math programme research rotation (GLM 5.3 stream) — **fix lane (second pass)**.
**Author:** GLM 5.3 lane, pi harness, on `dominic`, 2026-11-10 (third pass of the day).
**What this file is:** the repair of `DOSSIER-APOSTOL-v2.md` (522 lines, sha256 `7cc27b0201c5b6ba13d01f05165ccd1439f7da11226c84092d02a49198f7f13a`) against the crossed-review verdict **FAIL** (`REVIEW-APOSTOL-v2.md`, 235 lines, sha256 `54419458d7501605416f71e54affe6a1f5090cdbff46aff90bbd6f87fdb74cc9`, gpt-6-astra/ultra, 2026-11-10) and its corrections **R1–R9**. The v1 review (`REVIEW-APOSTOL-v1.md`, sha256 `29c42b7f803ae8599a94463f2e2b938c6534da852d9d2cf471ed61ba3e39d882`, FAIL) remains the repair-demand authority for v2's retained material. v1 and v2 are retained unmodified in this directory. Everything the v2 review confirmed is retained; every R-item is repaired here; §8 maps R1–R9 to the repairing sections.
**Status:** research input only. This dossier authorizes no proof lane. A proof lane needs its own frozen pin manifest and coordinator-appointed crossed review. This repaired dossier itself needs a renewed coordinator-appointed crossed review before any pinning use.
**Evidence discipline of this pass:** every live check below was made **2026-11-10 (≈20:50–21:15 UTC)** by this lane, with `curl -L` and authenticated `gh`/`gh search`. The raw artifacts are shipped in `prefetch-v3/` with a per-file sha256 `MANIFEST.txt` (**101 files listed — 100 evidence files + the package README — complete as delivered, every listed file present and non-empty**; four 3-byte search-response files contain the literal `[]`, i.e. recorded zero-result searches, not failed fetches). Where a check could not be completed it is marked **UNVERIFIED** or **MISSING**, never asserted. Springer's book page was **reachable this pass** (no bot challenge), so the chapter table below is re-verified live, upgrading v2's carried-from-v1 provenance for titles and page ranges (section-level numbering remains unverified ⚠).

---

## §0 Executive summary (v3 — supersedes v2 §0)

1. **Bounded negative, not upgraded (R8).** No complete fourteen-chapter Apostol project was identified in the searches run — this pass's fresh searches: repo search `Apostol` × {Lean, Isabelle, Coq} → **0/0/0**; code search `Apostol language:lean` → 25 hits (atlas Apostol–Bernoulli files, interval Euler–Maclaurin, an Apostol-citing Farey file, plus irrelevant hits); exact-title code searches → 1 Lean / 6 Isabelle (all AFP mirrors: `isabelle-prover/mirror-afp-devel`, `caotic123/Isabelle`, a `victor-geere` archive) / 0 Coq for the exact-title form and 3 irrelevant Coq hits for plain `Apostol`; exact-title repo search → 2 (course/image projects: `robfatland/ant`, `wflaherty02/IntroductionToANT`); Palomar `q=Apostol` and the tracked ID → empty at **revision 855** (release `94992346…`, totals 1,054/823 — v2's claimed revision 853 remains **UNVERIFIED**, its raw response was never delivered, and v3 does not rely on it). Chapter-level formalizations **do exist** (AFP `Gauss_Sums` = "a full formalisation of Chapter 8", abstract re-verified this pass; AFP `Prime_Distribution_Elementary` = "a formalisation of Chapter 4 (and parts of Chapter 3)"; AFP `Dirichlet_Series` = "much of Chapters 2, 3, and 11"). **No first-complete claim is made** (v2's contradictory "not open as a book / would still be the first" pair is withdrawn; see §6).
2. **The pointwise Selberg identity is prior art (R4).** Metamath **`logsqvma2`** (fetched this pass, statement transcribed in §2 AT2.20): for N ∈ ℕ, `Σ_{d|N} μ(d)·log²(N/d) = Σ_{d|N} Λ(d)Λ(N/d) + Λ(N)·log N` — exactly AT2.20 with sides/order rearranged. Registry: "Equation 10.4.8 of [Shapiro], p. 418. (Contributed by Mario Carneiro, 13-May-2016.)" **Withdrawn from first-to-any-assistant candidates** and moved to cross-assistant coverage [X].
3. **All retained false formulas are repaired (R1).** (a) The Ramanujan-sum divisor identities: the first is corrected to **Σ_{d|k} s_d(n) = k·[k|n]** (derived from AFP's `ramanujan_sum_dirichlet_form` by Möbius cancellation, machine-checked on a 79×79 grid this pass); the second (**Σ_{d|k}|s_d(n)|² = k(k,n)**) is **withdrawn as false** (counterexamples: k=n=2 gives 2≠4; k=n=3 gives 5≠9) and replaced by the correct multiplicative evaluation (stated in §2, machine-checked on a 119×119 grid); the row's claimed multiplicativity **in n** is also false and corrected (c₂(3)·c₂(5) = 1 ≠ −1 = c₂(15)); multiplicativity in k is correct (0 violations). (b) The Gauss-sum magnitude claims now carry **primitivity and coprimality hypotheses everywhere** (AT8.10–11, 12–13, 19–20), following AFP `primitive_encoding` (labelled Theorem 8.15): primitive χ ⇒ G(n,χ) = 0 at positive noncoprime frequencies, ‖G(1,χ)‖² = k. (c) The Mertens product constant is corrected to **e^(R−B)** with R = Σ_p(log(1−1/p)+1/p), convergent with every term strictly negative (derivation in §2 AT4.11–12). (d) The incomplete-row rule is now implemented **globally**: every §2 row that is not an exact-hypothesis statement carries an UNFINISHED mark — including AT11.13–15, AT5.16–18, AT13.8, AT13.19 (the review's named rows) and the additional sketch rows enumerated in §2 (AT1.9, AT2.5, AT2.15–16, AT3.7, AT3.8–9, AT3.12, AT4.6–7, AT5.14–15, AT5.19, AT6.1–3, AT6.12–14, AT7.2–8, AT8.1–3, AT8.14–17, AT8.21, AT9.8–13, AT9.17–25, AT10.3, AT10.13–16, AT11.7, AT12.1–5, AT12.17, AT13.20, AT14.8).
4. **Coverage is remapped node by node and the v2 headlines are withdrawn (R2).** v2's "61/318 verified Lean, 68/318 verified any" counted five nodes whose cited evidence did not prove the whole node (AT4.10, AT11.11, AT12.4, AT12.12, AT10.4) and missed three matches (AT2.20, AT13.11, AT4.10's Isabelle form). The remapped ledger (§4): **[M] Mathlib full-node 57, [E] external-Lean full-node 2 (59/318 = 18.6% in Lean), [X] cross-assistant full-node 9, total full-node coverage in some assistant 68/318 (21.4%)** — the total coincidentally equals v2's number with a **different, corrected composition** (the swap: −AT11.11, −AT12.12, AT12.4→AT12.6 relabel, AT10.4 retained only with the derivation now supplied; +AT13.11, +AT2.20, AT4.10 [E]→[X]). A **PARTIAL tier (3 nodes: AT4.10, AT11.11, AT12.12)** records statement-strength mismatches separately and is excluded from all numerators. The §4 remainder is renamed **"not declaration-matched"** and computed exactly (Ch. 3: 15 = 3 definitions + the 12 theorem nodes AT3.2–13 after AT3.1's [E] match — v2's "13" was wrong).
5. **The Ch. 13 prior-art record is corrected (R3).** AFP's zero-free region is the **classical inverse-log shape**, not Vinogradov–Korobov: the final `zeta_nonzero_region` (`PNT_with_Remainder/Zeta_Zerofree.thy`, from the current release tarball fetched this pass) shows for zeros β+iγ ≠ 1 that `1−β ≥ C₁/ln(|γ|+2)` with `PNT_const_C₁ = 1/952320` (intermediate form `1−β ≥ (1/29760)·θ(2|γ|+1)/φ(2|γ|+1)`). The explicit PNT error `π(x) = Li(x) + O(x·exp(−(ln x)^(1/2)/3653))` (3653 outside the root) is re-verified in the same tarball and stays; the "stronger, VK-shaped" comparison at v2 lines 264/426 is **removed**; exact route-match to Apostol's ψ₁ chain remains **UNVERIFIED**. And Mathlib **at M does have** the σ=1-line nonvanishing: `riemannZeta_ne_zero_of_one_le_re` (`LSeries/Nonvanishing.lean` L417–421, file fetched and hash-matched to the v2 review's capture), hypothesis `1 ≤ s.re`, with an explicitly documented junk-value convention at s=1 — genuine ζ(1+it) ≠ 0 for t ≠ 0. AT13.11 is therefore counted [M] (statement; the book's 3-4-1 proof route differs), and the Ch. 13 route estimates are restated on that basis.
6. **Chapter 14's analytic blueprint is explicit, and the route blocks are exact (R7).** The JTP pin (analytic identity, |x|<1, y≠0, via q=x, w=y²) requires: infinite product/sum convergence on the domain, holomorphic dependence in w then q, and the identity theorem — AFP's actual route (first 0<q<1/4, 1/2<w<1 real, then continuation in w on ℂ\{0}, then in q on the disk; re-read in the tarball this pass) is the blueprint and is now on the schedule. The alleged "17/18/19 route blocks" are replaced by exact, nonoverlapping node lists with dependency edges (§4.3), and **alternative proofs are separated from statement omissions**: a statement-complete charter must still prove the book's contour/estimate lemmas (AT13.2–13 etc.) even when PNT-as-statement is imported — importing a theorem does not remove the book's own intermediate statements from the charter.
7. **Evidence gaps closed where closable, labelled where not (R6).** The v3 package ships complete as delivered (101 files, sha256 manifest, non-empty verified). The **Formalpedia global 16-record count is now independently reproduced** from a fresh download of all 20 shards (455,592,034 bytes; per-shard sha256 in `prefetch-v3/formalpedia/shards-SHA256SUMS.txt`; the matched records with shard:line in `apostol-records.jsonl`) — every shard:line agrees with v2's table. The Formalpedia Mertens statement fixture is byte-identical (sha256 `1d8ca575…`) to the v2 review's recorded hash. Palomar is re-observed at 855; **revision 853 stays UNVERIFIED**. Springer's TOC is now live-verified (§1).
8. **Recommendation (conditional, unchanged in shape; timing corrected per R8).** Apostol remains defensible only as a statement-complete, import-first integration project with the two carve-outs (statement-fidelity vs Ch. 12–13 routes; frozen imports + license rulings) and the analytic Ch. 14 decision. The "recent absorption" argument no longer claims last-six-weeks dates for old registry entries: Perrons_Formula (2026-06-17), Rademacher_Series (2026-07-03), PNT_with_Remainder (2024-05-05) are months/years old as published mathematics; genuinely recent are Wiener–Ikehara in Mathlib (commit 2026-11-03) and the 2^α primitive-root completion (2026-10-31). The slot decision belongs to the coordinator on this dossier plus the renewed crossed review; no slot claim is made here.

**Not established by this dossier (explicitly):** the printed-book node count (every count remains provisional ⚠); per-node coverage above the remapped full-node totals; any global absence claim beyond the recorded searches; dependency-closure or sorry-free status beyond the files actually fetched and grepped; the section-level (x.y) numbering of the book; any legal ruling on the atlas license.

---

## §1 The book, its edition, and the numbering discipline

**Edition.** Tom M. Apostol, *Introduction to Analytic Number Theory*, Undergraduate Texts in Mathematics, Springer, first published 1976; pagination of the SpringerLink ebook / softcover reissue (DOI 10.1007/978-1-4757-5579-4). **This pass re-verified the book page live** (`prefetch-v3/springer/book-page.html`, 269,444 bytes, no bot challenge — unlike both earlier passes): JSON-LD gives `copyrightYear: 1976`, `isbn: 978-1-4757-5579-4`, author Tom M. Apostol, and the page carries the complete chapter table with page ranges, extracted below. **Chapter titles and page ranges are therefore live-verified this pass; the per-chapter section counts (x.y ranges) remain carried from v1's capture and are ⚠ unverified.**

| Ch. | Title (live-verified) | Pages (live-verified) | Sections (⚠ carried) |
|---|---|---|---|
| — | Historical Introduction | 1–12 | — |
| 1 | The Fundamental Theorem of Arithmetic | 13–23 | 1.1–1.8 ⚠ |
| 2 | Arithmetical Functions and Dirichlet Multiplication | 24–51 | 2.1–2.19 ⚠ |
| 3 | Averages of Arithmetical Functions | 52–73 | 3.1–3.12 ⚠ |
| 4 | Some Elementary Theorems on the Distribution of Prime Numbers | 74–105 | 4.1–4.11 ⚠ |
| 5 | Congruences | 106–128 | 5.1–5.11 ⚠ |
| 6 | Finite Abelian Groups and Their Characters | 129–145 | 6.1–6.10 ⚠ |
| 7 | Dirichlet's Theorem on Primes in Arithmetical Progressions | 146–156 | 7.1–7.9 ⚠ |
| 8 | Periodic Arithmetical Functions and Gauss Sums | 157–177 | 8.1–8.12 ⚠ |
| 9 | Quadratic Residues and the Quadratic Reciprocity Law | 178–203 | 9.1–9.11 ⚠ |
| 10 | Primitive Roots | 204–223 | 10.1–10.13 ⚠ |
| 11 | Dirichlet Series and Euler Products | 224–248 | 11.1–11.12 ⚠ |
| 12 | The Functions ζ(s) and L(s, χ) | 249–277 | 12.1–12.16 ⚠ |
| 13 | Analytic Proof of the Prime Number Theorem | 278–303 | 13.1–13.12 ⚠ |
| 14 | Partitions | 304–328 | 14.1–14.11 ⚠ |
| — | Back Matter | 329–340 | — |

**Numbering discipline (unchanged from v2, review-confirmed).** Every node carries a neutral provisional ID `A<ch>.<seq>` (D/T prefixes). Reconstructed book numbers appear as `⚠<book no.>` and the ⚠ travels with the number in every cross-reference. Exactly three book numbers are verified anchors **[V]** (source named at the node): **4.10** (Mertens I — Formalpedia record `d09af852-f479-4509-a198-8f0ba56f9115` + AFP `Shapiro_Tauberian.thy`'s θ-interpretation label; the anchor verifies the *citation*, not Lean proof strength), **13.15** (Pólya–Vinogradov — AFP `Polya_Vinogradov.thy` L813 names Theorem 13.15), **14.5** (van Lint bound — AFP `Partition'_le`, "following Apostol's presentation of the proof by van Lint [Theorem 14.5]"). Printed 13.15 being Pólya–Vinogradov, the Ch. 13 tail keeps "⚠ ≥ 13.16, shifted" numbers with no collision against verified 13.15.

**Ledger (retained from v2; arithmetic independently verified by the v2 review).** One counting convention, applied everywhere: **318 provisional nodes = 70 definitions + 248 theorem/lemma statement-nodes**, per chapter 17/34/16/22/27/23/10/30/31/24/22/25/21/16. This validates internal consistency only — **not** the printed-book inventory; the pinning pass against the physical printing remains mandatory and may split/merge nodes.

**Global incomplete-row rule (R1d).** A §2 row is a pinnable statement only if it carries exact hypotheses. Every row that is a research sketch instead carries **UNFINISHED — research reminder, not a pinnable statement**. The marks are applied globally this pass (list in §0.3); §8's compliance claim is checkable row by row against that list, including AT13.2–13 (all thirteen now marked, AT13.8 included) and AT13.19.

---

## §2 Chapter-by-chapter statement ledger (v3 — all repairs applied)

Conventions: repaired statements are marked **[REPAIRED R#]** with counterexample or derivation; withdrawn statements are marked **[WITHDRAWN R#]**. Book numbers ⚠ unless [V]. Coverage marks ([M]/[E]/[X]/PARTIAL) are assigned in §4; this section states the mathematics.

### Chapter 1 — The Fundamental Theorem of Arithmetic (pp. 13–23, live-verified)

**Definitions (3, unnumbered as printed ⚠):** AD1.1 divisibility; AD1.2 greatest common divisor; AD1.3 prime (n > 1 whose only divisors are 1 and n).

**Theorems (14):** AT1.1 ⚠1.1 division algorithm (b > 0; unique q, r, a = qb + r, 0 ≤ r < b). AT1.2 ⚠1.2 gcd as least positive {ax+by}; common divisors divide it. AT1.3 ⚠1.3 Euclid's lemma. AT1.4 ⚠1.4 prime divisor of a product. AT1.5–AT1.6 ⚠1.5–1.6 FTA (existence and uniqueness; p^a ∥ n well-defined). AT1.7 ⚠1.7 infinitely many primes. AT1.8 ⚠1.8 composite n has a prime divisor ≤ √n. AT1.9 ⚠1.9 sieve of Eratosthenes correctness — **UNFINISHED (procedure node; exact book form not pinned)**. AT1.10 ⚠1.10 Σ 1/p diverges. AT1.11–AT1.13 ⚠1.11–1.13 Euclidean algorithm (termination; last nonzero remainder = (a,b); (a,b) = ax+by). AT1.14 ⚠1.14 gcd of several numbers.

**Dependencies:** none. **Node count 17** (3 D + 14 T).

### Chapter 2 — Arithmetical Functions and Dirichlet Multiplication (pp. 24–51, live-verified)

**Definitions (14):** AD2.1 arithmetical function (f: ℕ⁺→ℂ); AD2.2 Möbius μ; AD2.3 Euler totient φ; AD2.4 Dirichlet product ∗; AD2.5 identity I(n) = [n=1]; AD2.6 Dirichlet inverse; AD2.7 von Mangoldt Λ; AD2.8 multiplicative; AD2.9 completely multiplicative; AD2.10 Liouville λ; AD2.11 σ_α and d = σ₀; AD2.12 generalized convolution/partial sums; AD2.13 Bell series; AD2.14 derivative f′(n) = f(n)log n.

**Theorems (20):**
- AT2.1 ⚠2.1 Σ_{d|n} μ(d) = [n=1]. AT2.2 ⚠2.2 φ(n) = nΣ_{d|n}μ(d)/d. AT2.3 ⚠2.3 Σ_{d|n}φ(d) = n. AT2.4 ⚠2.4 φ(n) = n∏_{p|n}(1−1/p).
- AT2.5 ⚠2.5 arithmetical functions under + and ∗ form a commutative ring with I as ∗-unit — **UNFINISHED (structural paraphrase; the book's exact axiomatic form not pinned; Mathlib has the monoid structure, see §4)**.
- AT2.6 ⚠2.6 f has a Dirichlet inverse iff f(1) ≠ 0. AT2.7 ⚠2.7 Möbius inversion: f = g∗1 ⇔ g = f∗μ. AT2.8 ⚠2.8 Λ = μ∗log, i.e. Σ_{d|n}Λ(d) = log n.
- AT2.9–AT2.11 ⚠2.9–2.11 multiplicativity of f∗g and of Σ_{d|n}f(d); a multiplicative function is determined by its prime-power values.
- AT2.12 ⚠2.12 completely multiplicative f has Dirichlet inverse μf. AT2.13 ⚠2.13 Σ_{d|n}λ(d) = [n square].
- AT2.14 ⚠2.14 **[REPAIRED in v2; retained with domains explicit per the v2 review]** σ_α is multiplicative, and for **real α and n ≥ 1**, with n = ∏ p^a:
  **σ_α(n) = ∏_{p^a∥n} σ_α(p^a), σ_α(p^a) = Σ_{k=0}^{a} p^{αk} = (p^{α(a+1)}−1)/(p^α−1) if p^α ≠ 1, and a+1 if p^α = 1.**
  Domains: α ∈ ℝ, n ∈ ℕ, n ≥ 1. The exceptional condition is exactly p^α = 1; for real α this is α = 0, but the equivalence "p^α = 1 ⇔ α = 0" **fails for complex α** (e.g. α = 2πi/log p gives p^α = 1), so the split must be stated on p^α, not on α. Check: n=2, α=1 → σ₁(2) = 3 = (2²−1)/(2−1) ✓ (v1's formula gave 1 ✗). Source-strength note: Mathlib's `sigma_apply_prime_pow` is stated on ℕ-valued exponents (σ_k, k : ℕ) and does not by itself certify arbitrary real α — the real-α form remains a translation obligation.
- AT2.15 ⚠2.15 Fubini-type interchange for generalized convolutions — **UNFINISHED**. AT2.16 ⚠2.16 formal power series over arithmetical functions; coefficient uniqueness — **UNFINISHED**.
- AT2.17–AT2.18 ⚠2.17–2.18 **[REPAIRED in v2; retained]** Bell series: (i) recovery f = g ⇔ equal Bell series at every prime **for multiplicative f, g** (counterexample without multiplicativity: f ≡ 1 vs g = f except g(6) = 2 — identical Bell series, f ≠ g); (ii) completely multiplicative ⇒ f_p(x) = 1/(1−f(p)x); (iii) (f∗g)_p = f_p·g_p with no hypothesis; (iv) μ_p = 1−x, Λ_p = (log p)x/(1−x), λ_p = 1/(1+x), σ_{α,p} = 1/((1−x)(1−p^α x)), **φ_p(x) = (1−x)/(1−px)** (x-coefficient p−1 = φ(p) ✓).
- AT2.19 ⚠2.19 (f∗g)′ = f′∗g + f∗g′ (exact; retained).
- AT2.20 ⚠2.20 (§2.19) **Selberg identity (pointwise form) [REPAIRED R4 — no longer a novelty candidate]:** Λ(n)log n + Σ_{d|n}Λ(d)Λ(n/d) = Σ_{d|n} μ(d)log²(n/d). **Already proved in Metamath** as `logsqvma2` (assertion, transcribed from the fetched page): `(N ∈ ℕ → Σ_{d∈{x∈ℕ | x∥N}} (μ(d)·(log(N/d))²) = Σ_{d|N}(Λ(d)·Λ(N/d)) + Λ(N)·log N)` — the same statement with sides/order rearranged; "The Möbius inverse of logsqvma. Equation 10.4.8 of [Shapiro], p. 418. (Contributed by Mario Carneiro, 13-May-2016.)" A Lean proof would be port-with-blueprint work; it is **not** first-to-any-assistant mathematics. (The asymptotic form was already retracted in v2 — AFP 4.18, Metamath `selberg` — and stays retracted.)

**Dependencies:** Ch. 1. **Node count 34** (14 D + 20 T).

### Chapter 3 — Averages of Arithmetical Functions (pp. 52–73, live-verified)

**Definitions (3):** AD3.1 O/Ω/Θ/o notation; AD3.2 fractional part ψ(x) = x − ⌊x⌋; AD3.3 average order.

**Theorems (13):**
- AT3.1 ⚠3.1 **Euler's summation formula [REPAIRED in v2; corroboration corrected R9].** f with continuous derivative on [y,x], 0 < y < x:
  **Σ_{y<n≤x} f(n) = ∫_y^x f(t)dt + ∫_y^x ψ(t)f′(t)dt − f(x)ψ(x) + f(y)ψ(y)**, ψ(t) = {t}.
  Counterexample retained: f ≡ 1, y = 1, x = 3/2 → LHS 0; v1's signs gave 1, the corrected signs give 0 ✓. **Corroboration (R9, corrected):** interval's `sum_Ioc_eq_integral_add_of_hasDerivWithinAt` at p = 1 uses the periodized Bernoulli function **P₁(t) = {t} − 1/2** (its `saw_one`: `saw 1 x = Int.fract x − 1/2`, fetched this pass), **not** {t}; v2's claim that the endpoint term "is already exactly the fractional-part term" was wrong. The two forms are equivalent after a cancellation: substituting P₁ = {·} − ½,
  ∫_y^x P₁f′ = ∫_y^x {t}f′ − ½(f(x)−f(y)), and −P₁(x)f(x)+P₁(y)f(y) = −f(x){x}+f(y){y} + ½(f(x)−f(y));
  the four half-terms cancel pairwise, leaving exactly the book's formula. (Interval at `2c89204b806f4acd9b8530a38e656369d0a4d7f3`, files shipped.)
- AT3.2 ⚠3.2 Σ_{n≤x}1/n = log x + γ + O(1/x). AT3.3 ⚠3.3 Σ_{n≤x}n^α = x^{α+1}/(α+1) + O(x^α) (α ≥ 0); Σ_{n≤x}log n = x log x − x + O(log x).
- AT3.4 ⚠3.4 Dirichlet hyperbola: Σ_{n≤x}d(n) = x log x + (2γ−1)x + O(√x). AT3.5 ⚠3.5 Σσ_α asymptotics (α > 0, β = max(1,α)); σ_{−α} companion (0 < α < 1). AT3.6 ⚠3.6 Σ_{n≤x}φ(n) = 3x²/π² + O(x log x).
- AT3.7 ⚠3.7 coprimality probability 6/π² — **UNFINISHED (the book's exact visible-lattice-points statement not pinned; the mathematical content is lim_{x→∞} #{1≤a,b≤x : (a,b)=1}/x² = 6/π²)**.
- AT3.8–AT3.9 ⚠3.8–3.9 Σ_{n≤x}μ²(n) = x/ζ(2) + O(√x) (exact); the M(x) bound half of the row — **UNFINISHED (bound not pinned)**.
- AT3.10–AT3.11 ⚠3.10–3.11 partial sums of Dirichlet products: Σ_{n≤x}(f∗g)(n) = Σ_{a≤x}g(a)Σ_{m≤x/a}f(m) = Σ_{ab≤x}f(a)g(b) (exact). AT3.12 ⚠3.12 hyperbola-symmetric re-derivation of Σd(n) — **UNFINISHED**.

**Dependencies:** Ch. 1–2; elementary real analysis. **Node count 16** (3 D + 13 T).

### Chapter 4 — Some Elementary Theorems on the Distribution of Prime Numbers (pp. 74–105, live-verified)

**Definitions (5):** AD4.1 ψ(x) = Σ_{n≤x}Λ(n), θ(x) = Σ_{p≤x}log p; AD4.2 π(x); AD4.3 p_n; AD4.4 Mertens' constant B; AD4.5 M(x) = Σ_{n≤x}μ(n).

**Theorems (17):**
- AT4.1 ⚠4.1 ψ(x) = Σ_{m≥1}θ(x^{1/m}) (finite sum: θ(y) = 0 for y < 2), and the bridging bound. **Both halves are declaration-matched at M this pass:** `Chebyshev.psi_eq_sum_theta` (ψ x = Σ_{n∈Icc 1 ⌊log x/log 2⌋₊, θ(x^{1/n})) and `Chebyshev.abs_psi_sub_theta_le_sqrt_mul_log` (|ψ x − θ x| ≤ 2√x·log x for x ≥ 1; v2's citation of this name is confirmed — the file is shipped).
- AT4.2 ⚠4.2 log⌊x⌋! = Σ_{p^k≤x}⌊x/p^k⌋log p (Legendre). AT4.3 ⚠4.3 Abel/partial summation A(x)f(x) − ∫A f′. AT4.4–AT4.5 ⚠4.4–4.5 PNT equivalences. AT4.6–AT4.7 ⚠4.6–4.7 Chebyshev's bounds c₁x/log x ≤ π(x) ≤ c₂x/log x and Bertrand — **UNFINISHED as to the printed constants c₁, c₂ (the Bertrand existence statement itself is matched at M, §4)**.
- AT4.8 ⚠4.8 **Shapiro's Tauberian theorem [COMPLETED in v2; retained]** — AFP `Shapiro_Tauberian.thy` locale `shapiro_tauberian` (locale hypotheses re-verified this pass: a(n) ≥ 0 for n > 0, T(x) = Σa(n)⌊x/n⌋ = x ln x + O(x)): conclusions (i) Σ_{n≤x}a(n)/n = ln x + O(1); (ii) Σa(n) ≤ Bx; (iii) Σa(n) ≥ Cx for x ≥ 1/C, i.e. Θ(x).
- AT4.9 ⚠4.9 Σ_{n≤x}Λ(n)/n = log x + O(1).
- AT4.10 **4.10 [V]** **Mertens' first theorem (1874): Σ_{p≤x} log p/p = log x + O(1).** Coverage split (R2a): the [V] anchor verifies the citation only (Formalpedia record + Salt extraction). **In Lean the extracted proof is one-sided:** `Salt/Maynard/Mertens.lean` `sum_log_div_prime_le` (fetched, L150–154): "Mertens' first theorem, **upper bound**" — Σ_{p≤N} log p/p ≤ log N + (log 4 + 4) for N ≥ 1. **The full two-sided theorem is in Isabelle:** AFP `Prime_Number_Theorem/Mertens_Theorems.thy` `corollary mertens_first_theorem` (fetched this pass from the release tarball): for x ≥ 1, **|ℳ x − ln x| < 2**, where ℳ x = Σ_{p≤x} ln p/p (`primes_M`, L457 confirms the definition on values). AT4.10 is therefore [X]-full + PARTIAL-in-Lean; it is not counted as Lean-covered.
- AT4.11–AT4.12 ⚠4.11–4.12 **Mertens' second theorem and product corollary [REPAIRED R1c].** Theorem: **Σ_{p≤x} 1/p = log log x + B + O(1/log x)** — two-sided premise in Isabelle: AFP `mertens_second_theorem` (fetched): |Σ_{p≤x}1/p − ln ln x − meissel_mertens| ≤ 4/ln x for x ≥ 2, plus the O-form. Corollary, **corrected**: with **R = Σ_p(log(1−1/p) + 1/p)** (convergent, since each summand is O(1/p²); **strictly negative, since log(1−u) < −u for 0 < u < 1 makes every term negative** — the p = 2 term alone is −log 2 + ½ ≈ −0.193),
  **∏_{p≤x}(1−1/p) ~ e^{R−B}/log x, NOT e^{−B}/log x.**
  Derivation: log ∏_{p≤x}(1−1/p) = Σ_{p≤x}log(1−1/p) = −Σ_{p≤x}1/p + Σ_{p≤x}(log(1−1/p)+1/p) = −(log log x + B + O(1/log x)) + R + o(1), and exponentiating gives the constant e^{R−B}. v2's e^{−B} would require R = 0, refuted by R < 0 already from the p = 2 term (this is the v2 review's argument, retained). In the standard normalization B is the Meissel–Mertens constant M and the classical identity M = γ + R gives e^{R−M} = e^{−γ}, the classical Mertens product constant; **the book's printed symbol for the constant remains ⚠ pending pinning.** No declaration-level form of the product corollary was located in the fetched AFP Mertens theory or in Mathlib (open in the checked sources).
- AT4.13 ⚠4.13 Σ_{n≤x}μ(n)/n = O(1). AT4.14–AT4.16 ⚠4.14–4.16 Selberg-method lemma development — **UNFINISHED** (blueprint exists: AFP `(* 4.17 *)` inversion development).
- AT4.17 ⚠4.17 **Selberg's asymptotic formula** — retraction retained (v2/review C2): AFP `(* 4.18 *) theorem selberg_asymptotic_formula` (statement re-verified this pass from the tarball): ψ(x)·ln x + Σ_{n≤x}Λ(n)ψ(x/n) = 2x·ln x + O(x), following Apostol; Metamath `selberg` (Shapiro 10.4.10 p. 419, Carneiro 2016-05-23, description re-verified this pass). Port-with-blueprint, not new-to-any-assistant.

**Dependencies:** Ch. 1–3. **Node count 22** (5 D + 17 T).

### Chapter 5 — Congruences (pp. 106–128, live-verified)

**Definitions (7, unnumbered ⚠):** AD5.1 congruence; AD5.2 residue classes/CRS; AD5.3 polynomial congruence; AD5.4 reduced residue system; AD5.5 linear congruence; AD5.6 cross-classification; AD5.7 polynomial degree mod m (may merge with AD5.3 at pin time).

**Theorems (20):** AT5.1–AT5.3 ⚠5.1–5.3 equivalence + compatibility + cancellation; AT5.4 ⚠5.4 ℤ/mℤ ring; AT5.5–AT5.6 ⚠5.5–5.6 linear congruences (solvable iff (a,m)|b, then (a,m) classes); AT5.7–AT5.8 ⚠5.7–5.8 Euler–Fermat a^{φ(m)}≡1 (mod m) for (a,m)=1, Fermat corollary; AT5.9 ⚠5.9 Lagrange (degree-n polynomial mod p, p∤leading coeff ⇒ ≤ n solutions); AT5.10–AT5.11 ⚠5.10–5.11 x²≡1 applications and Wilson (p−1)!≡−1 (mod p); AT5.12–AT5.13 ⚠5.12–5.13 CRT (pairwise-coprime and general); AT5.14–AT5.15 ⚠5.14–5.15 composite-modulus decomposition — **UNFINISHED**; AT5.16–AT5.18 ⚠5.16–5.18 prime-power lifting (Hensel-type) — **UNFINISHED (R1d; exact hypotheses not pinned; Mathlib has `NumberTheory/Padics/Hensel.lean` at path level only, §4)**; AT5.19 ⚠5.19 cross-classification principle — **UNFINISHED**; AT5.20 ⚠5.20 RRS tensor decomposition and φ-multiplicativity.

**Dependencies:** Ch. 1–2. **Node count 27** (7 D + 20 T).

### Chapter 6 — Finite Abelian Groups and Their Characters (pp. 129–145, live-verified)

**Definitions (6):** AD6.1 abelian group/subgroup; AD6.2 character; AD6.3 character group; AD6.4 principal character; AD6.5 Dirichlet character mod k; AD6.6 real character.

**Theorems (17):** AT6.1–AT6.3 ⚠6.1–6.3 elementary group facts — **UNFINISHED (bundled)**; AT6.4 ⚠6.4 subgroup of every order dividing |G|; AT6.5 ⚠6.5 characters beyond the principal; AT6.6 ⚠6.6 |Ĝ| = |G|; AT6.7–AT6.9 ⚠6.7–6.9 orthogonality (Σ_{x∈G}χ(x) = |G|[χ=χ₀]; Σ_χ χ(x) = |G|[x=e]); AT6.10–AT6.11 ⚠6.10–6.11 Dirichlet characters form a group ≅ character group of the RRS, φ(k) of them; AT6.12–AT6.14 ⚠6.12–6.14 sums with Dirichlet characters — **UNFINISHED**; AT6.15–AT6.17 ⚠6.15–6.17 L(1,χ) ≠ 0 for real nonprincipal χ by the elementary Ch. 6 route (statement upstream in stronger form, §4; the book's elementary route is a presentational gap only).

**Dependencies:** Ch. 5. **Node count 23** (6 D + 17 T).

### Chapter 7 — Dirichlet's Theorem on Primes in Arithmetic Progressions (pp. 146–156, live-verified)

**Definitions (1):** AD7.1 L(s,χ) = Σχ(n)n^{−s} (s > 1).

**Theorems (9):** AT7.1 ⚠7.1 primes ≡ ±1 (mod 4) elementary; AT7.2–AT7.3 ⚠7.2–7.3 the reduction plan — **UNFINISHED (plan nodes; the covered sub-statement is the infinitude in AP, §4)**; AT7.4 ⚠7.4 (§7.4) convergence/boundedness of Σ_pΣ_mχ(p)^m/(mp^s) — **UNFINISHED (bounds not pinned)**; AT7.5 ⚠7.5 (§7.5) log L(s,χ) convergence for χ ≠ χ₀ — **UNFINISHED**; AT7.6 ⚠7.6 (§7.6) L(s,χ₀) ~ (φ(k)/k)ζ(s)-type pole — **UNFINISHED**; AT7.7 ⚠7.7 (§7.8) L(1,χ) ≠ 0 for complex χ — **UNFINISHED as to the book's hypotheses (the statement is upstream, §4)**; AT7.8 ⚠7.8 (§7.7) real-character case; AT7.9 ⚠7.9 (§7.9) π(x;k,h) ~ (1/φ(k))·x/log x (exact; not covered by the upstream infinitude statements).

**Dependencies:** Ch. 5–6, Ch. 4 partials. **Node count 10** (1 D + 9 T).

### Chapter 8 — Periodic Arithmetical Functions and Gauss Sums (pp. 157–177, live-verified)

**Definitions (8):** AD8.1 periodic arithmetical function; AD8.2 finite Fourier series; AD8.3 Ramanujan sum s_k(n); AD8.4 generalized sums; AD8.5 Gauss sum G(n,χ); AD8.6 induced modulus; AD8.7 primitive character; AD8.8 conductor.

**Theorems (22):**
- AT8.1–AT8.3 ⚠8.1–8.3 minimal period/CRT decomposition; finite Fourier expansion + inversion — **UNFINISHED (exact coefficient statements not pinned; AFP `Finite_Fourier_Series.thy` and `Ramanujan_Sums.thy` `gen_ramanujan_sum_fourier_expansion` are the blueprint, tarball fetched)**.
- AT8.4–AT8.7 ⚠8.4–8.7 Ramanujan-sum evaluations **[REPAIRED R1a]**:
  **(i) Dirichlet form (exact, upstream as AFP `ramanujan_sum_dirichlet_form`, fetched: c k n = Σ_{d | gcd(n,k)} d·μ(k/d) for k > 0; equated with the exponential definition).**
  **(ii) Hölder-type form: s_k(n) = μ(k/(k,n))·φ(k)/φ(k/(k,n)) (on its stated domain).**
  **(iii) Integrality of s_k(n).**
  **(iv) [CORRECTED] Σ_{d|k} s_d(n) = k·[k|n] — the right-hand side is k·[k|n], NOT [k|n].** Derivation from (i): Σ_{d|k}s_d(n) = Σ_{d|k}Σ_{e|gcd(n,d)} e·μ(d/e) = Σ_{e|gcd(n,k)} e·Σ_{f | k/e}μ(f) = Σ_{e|gcd(n,k)} e·[k/e = 1] = k·[k|n] (Möbius cancellation). Counterexample to v2's form: k = n = 2 gives s₁(2)+s₂(2) = 1+1 = 2 = k·[k|n] ✓, while [k|n] = 1 ✗. Machine-checked on the 79×79 grid this pass.
  **(v) [WITHDRAWN] Σ_{d|k}|s_d(n)|² = k(k,n) is false:** k=n=2 → 2 ≠ 4; k=n=3 → 5 ≠ 9; k=3,n=1 → 2 ≠ 3; k=4,n=2 → 6 ≠ 8; k=6,n=2 → 4 ≠ 12. **Correct evaluation (lane-derived, machine-checked on the 119×119 grid):** the sum depends only on g = (k,n) and is multiplicative in k, with prime-power factors f(p^a, b) = 2 if b = 0 (a ≥ 1); f(p^a,b) = 1 + Σ_{j=1}^{min(a,b)} φ(p^j)² + [a > b]·p^{2b} if b ≥ 1 (b = v_p(g)). **The book's own printed form of this row is UNFINISHED pending pinning** — v1/v2's formula must not be pinned in any form.
- AT8.8–AT8.9 ⚠8.8–8.9 **[REPAIRED R1a-adjacent]**: (k ↦ s_k(n)) **is multiplicative for fixed n** (machine-checked, 0 violations on 24×24×39); **s_k(n) is NOT multiplicative in n for fixed k** — counterexample c₂(3)·c₂(5) = 1 ≠ −1 = c₂(15) — v2's "multiplicativity in k and n" is corrected to multiplicativity in k only. The "Σ|s_d(n)|²" identity formerly bundled here is withdrawn per AT8.4–7(v).
- AT8.10–AT8.11 ⚠8.10–8.11 **[REPAIRED R1b]**: **for primitive χ mod k and (n,k) = 1:** G(n,χ) = χ̄(n)G(1,χ) (separability) and **|G(n,χ)| = √k**. The bare claim "|G(n,χ)| = √k" without coprimality is **false**: for the primitive nonprincipal character mod 3 at frequency n = 3, χ(1) = 1, χ(2) = −1, both exponential factors are 1, so G(3,χ) = 0 ≠ √3. The coprimality hypothesis is substantive and is now stated at every magnitude row.
- AT8.12–AT8.13 ⚠8.12–8.13 **[REPAIRED R1b]**: for primitive χ, G(n,χ) = 0 for every positive n with (n,k) > 1, and conversely nonvanishing at such n would contradict primitivity (AFP `primitive_encoding` part 1: "∀k>0. ¬coprime k n ⟶ gauss_sum k = 0"); nonvanishing characterization: G(n,χ) ≠ 0 ⇔ (n,k) = 1 for primitive χ.
- AT8.14–AT8.15 ⚠8.14–8.15 induced-modulus criterion via Gauss-sum vanishing — **UNFINISHED**. AT8.16–AT8.17 ⚠8.16–8.17 induction and L-series factorization — **UNFINISHED**. AT8.18 ⚠8.18 unique primitive inducing character. AT8.19–AT8.20 ⚠8.19–8.20 **[REPAIRED R1b]**: primitive ⇒ separable at every frequency (AFP `primitive_encoding` part 2: "∀k>0. separable k"), **|G(n,χ)| = √k for (n,k) = 1, and G(n,χ) = 0 for positive (n,k) > 1** — v2's "|G| = √k for all n" is false as above; ‖G(1,χ)‖² = k is AFP part 3. AT8.21 ⚠8.21 Fourier expansion of characters — **UNFINISHED**.
- AT8.22 ⚠8.22 Pólya's elementary bound for primitive χ **[RESTATED R5]**: **‖Σ_{m=1..x} χ(m)‖ < √n·ln n for primitive nonprincipal χ mod n** (AFP `polya_vinogradov_inequality_primitive`), uniform in x and χ — the sharp book form is printed as **Thm 13.15 [V]** (see Ch. 13); do **not** pin the Big-O paraphrase.

**Dependencies:** Ch. 5–6, roots of unity, Ch. 2. **Node count 30** (8 D + 22 T). **This entire chapter is formalized in Isabelle** (AFP `Gauss_Sums`, "a full formalisation of Chapter 8 of Apostol's Introduction to Analytic Number Theory", abstract re-verified this pass) — the strongest chapter-level prior art in the book.

### Chapter 9 — Quadratic Residues and the Quadratic Reciprocity Law (pp. 178–203, live-verified)

**Definitions (5):** AD9.1 quadratic residue/nonresidue; AD9.2 Legendre symbol; AD9.3 Euler's criterion (as statement); AD9.4 Jacobi symbol; AD9.5 quadratic Gauss sums G(n;m).

**Theorems (26):** AT9.1 ⚠9.1 half residues/half nonresidues; AT9.2–AT9.4 ⚠9.2–9.4 Legendre laws, Euler's criterion a^{(p−1)/2} ≡ (a|p) (mod p), (−1|p) = (−1)^{(p−1)/2}; AT9.5–AT9.7 ⚠9.5–9.7 (−1|p), (2|p) evaluations; AT9.8–AT9.10 ⚠9.8–9.10 Gauss' lemma and counting — **UNFINISHED**; AT9.11 ⚠9.11 **quadratic reciprocity** (first proof); AT9.12–AT9.13 ⚠9.12–9.13 applications — **UNFINISHED**; AT9.14–AT9.16 ⚠9.14–9.16 Jacobi laws + reciprocity + complementary laws; AT9.17–AT9.19 ⚠9.17–9.19 primes represented by x² + my² (incl. p = x²+y² ⇔ p ≡ 1 (mod 4), exact; the general m-family **UNFINISHED**); AT9.20–AT9.22 ⚠9.20–9.22 quadratic Gauss-sum evaluations, |G(1;p)| = √p (exact), general evaluations **UNFINISHED**; AT9.23–AT9.25 ⚠9.23–9.25 reciprocity for quadratic Gauss sums, G(1;m) — **UNFINISHED as to the general evaluation**; AT9.26 ⚠9.26 third proof of QR.

**Dependencies:** Ch. 5–6, Ch. 8. **Node count 31** (5 D + 26 T).

### Chapter 10 — Primitive Roots (pp. 204–223, live-verified)

**Definitions (3):** AD10.1 order of a mod m; AD10.2 primitive root; AD10.3 index (discrete logarithm).

**Theorems (21):** AT10.1–AT10.2 ⚠10.1–10.2 order laws (ord a | φ(m); ord a^k = ord a/(k, ord a)); AT10.3 ⚠10.3 cyclic-structure characterization — **UNFINISHED**; AT10.4 ⚠10.4 **nonexistence mod 2^α (α ≥ 3) [REPAIRED R2e]:** cyclicity: primitive roots mod 2^α exist ⇔ α ≤ 2 (Mathlib `isCyclic_units_two_pow_iff`, fetched), **and the universal exponent bound: a^{2^{α−2}} ≡ 1 (mod 2^α) for every odd a and α ≥ 3**, supplied as a derivation from declarations at M: every unit of (ZMod 2^α)ˣ is uniquely (−1)^ℓ·5^j (`isComplement'_zpowers_unitFive_neg_one`), (−1)^{2^{α−2}} = 1, and ord(5) = 2^{α−2} (`orderOf_unitFive` / `orderOf_five`, all fetched at M) ⇒ (±5^j)^{2^{α−2}} = 1. Each ingredient is a named declaration at M; the composition is recorded here as this pass's derivation. AT10.5 ⚠10.5 existence mod p (φ(p−1) primitive roots; `isCyclic_units_prime`); AT10.6 ⚠10.6 criterion g^{(p−1)/q} ≢ 1 for q | p−1; AT10.7–AT10.8 ⚠10.7–10.8 existence mod p^α (lifting; `isCyclic_units_of_prime_pow` + the prime-power development); AT10.9 ⚠10.9 existence mod 2p^α (`isCyclic_units_two_mul_iff_of_odd`); AT10.10 ⚠10.10 classification (`isCyclic_units_iff`: exactly m = 1, 2, 4, p^α, 2p^α); AT10.11 ⚠10.11 φ(φ(m)) primitive roots; AT10.12 ⚠10.12 index laws and the solvability criterion x^n ≡ a (mod p) ⇔ a^{(p−1)/d} ≡ 1, d = (n, p−1), with exactly d solutions (exact); AT10.13–AT10.16 ⚠10.13–10.16 binomial-congruence tables — **UNFINISHED**; AT10.17–AT10.19 ⚠10.17–10.19 primitive roots ↔ Dirichlet characters (χ(g^k) = e^{2πirk/φ(p^α)}); AT10.20–AT10.21 ⚠10.20–10.21 primitive characters mod p^α, criterion p ∤ r. **Index calculus and the character-structure sections were not located in any assistant within the searches run — open-in-everything-checked is UNVERIFIED (bounded), open-in-Lean verified within this pass's searches.**

**Dependencies:** Ch. 5–6. **Node count 24** (3 D + 21 T).

### Chapter 11 — Dirichlet Series and Euler Products (pp. 224–248, live-verified)

**Definitions (4):** AD11.1 Dirichlet series F(s) = Σf(n)n^{−s}; AD11.2 abscissae σ_a, σ_c; AD11.3 Euler product; AD11.4 formal ↔ analytic identification under ∗.

**Theorems (18):**
- AT11.1 ⚠11.1 absolute convergence for σ ≥ σ₀+ε. AT11.2 ⚠11.2 half-plane of convergence σ > σ_c; σ_a − σ_c ≤ 1 — **UNFINISHED as to the book's exact σ_c development (the inequality is exact)**. AT11.3 ⚠11.3 analyticity in the open half-plane; termwise differentiation. AT11.4 ⚠11.4 multiplication theorem (series of f∗g = product of series).
- AT11.5–AT11.6 ⚠11.5–11.6 Euler products: f multiplicative ⇒ F(s) = ∏_p Σ_k f(p^k)p^{−ks} (upstream at M: `EulerProduct.eulerProduct` and `eulerProduct_tprod` for multiplicative-on-coprime f with summability, fetched); completely multiplicative ⇒ ∏_p(1−f(p)p^{−s})^{−1} (`eulerProduct_completely_multiplicative`, present at M, confirmed this pass); converses.
- AT11.7 ⚠11.7 exact half-plane of convergence; boundary behavior — **UNFINISHED**. AT11.8–AT11.9 ⚠11.8–11.9 analytic properties + uniqueness (equal sums on a half-plane ⇒ equal coefficients; the uniqueness statement is exact).
- AT11.10 ⚠11.10 **Landau's theorem**: f ≥ 0, convergence exactly for σ > σ_c ⇒ σ_c is a singularity.
- AT11.11–AT11.12 ⚠11.11–11.12 **exponential representation [REPAIRED R2b — split coverage]:** the general form F(s) = f(1)·exp(Σ_p Σ_m P(p^m)p^{−ms}/m)-type for arithmetical f. **Lean coverage is instance-level only and the node is PARTIAL, excluded from full-node counts:** at M, `riemannZeta_eulerProduct_exp_log` (exp(Σ_p −log(1−p^{−s})) = ζ(s), 1 < Re s), `DirichletCharacter.LSeries_eulerProduct_exp_log` and `DirichletCharacter.eulerProduct_log_eq_LSeries` (the same shape for every Dirichlet L-series, fetched) — ζ and Dirichlet-L instances, not the general arithmetical-function statement, which remains unmatched in the searched Lean sources. The book's exact printed form is ⚠.
- AT11.13–AT11.15 ⚠11.13–11.15 (§11.10) mean-value / partial-sum formulas — **UNFINISHED (R1d)**.
- AT11.16 ⚠11.16 **Coefficient extraction by vertical means [REPAIRED in v2; retained with the review's wording fix].** Let F(s) = Σf(n)n^{−s} converge absolutely at the real point σ (**for example σ > σ_a**; absolute convergence may also hold on the boundary). Then for every n ≥ 1: **f(n) = lim_{T→∞}(1/2T)∫_{−T}^{T}F(σ+it)n^{σ+it}dt.** The 1/(2T) normalization is essential (F ≡ 1, n = 1: the unnormalized integral grows like T/π; the mean is 1 for every T). Mechanism: expansion Σ_m f(m)(n/m)^σ e^{it log(n/m)}, the t-mean of e^{iut} being 1 at u = 0 and → 0 otherwise. Standalone-theorem vs mechanism-of-uniqueness: UNVERIFIED pending pinning.
- AT11.17–AT11.18 ⚠11.17–11.18 **Perron's formula** (retained from v2, review-confirmed): kernel **x^w/w** (the division by w is part of the kernel); Σ′ half-weight convention at integer x; absolute-convergence basic form with c > max(σ_a, 0), x > 0 non-integer; T-truncated forms with error bounds. Cross-assistant prior art: AFP `perron_asymp` (ordinary convergence abscissa hypothesis; declaration at `Perrons_Formula.thy` L982, tarball fetched) and `perron_effective_strong` (L1208). Lean: UyNewNas Perron files exist at path level (v2-verified; not re-fetched this pass).

**Dependencies:** Ch. 2, Ch. 4 (Λ), elementary complex analysis. **Node count 22** (4 D + 18 T).

### Chapter 12 — The Functions ζ(s) and L(s, χ) (pp. 249–277, live-verified)

**Definitions (5):** AD12.1 Γ(s) (properties only); AD12.2 Hurwitz ζ(s,a) = Σ_{n≥0}(n+a)^{−s}; AD12.3 Riemann ζ(s) = ζ(s,1); AD12.4 L(s,χ) and its Hurwitz combination; AD12.5 completed Λ(s,χ).

**Theorems (20):** AT12.1–AT12.3 ⚠12.1–12.3 Γ basics — **UNFINISHED (bundled)**; AT12.4 ⚠12.4 Hurwitz ζ analyticity + integral representation **[REPAIRED R2c]: the integral representation is NOT declaration-matched** — v2's coverage cited the continuation/residue, which is AT12.6's content; no integral representation was found in `HurwitzZeta.lean` (zero "integral" hits in the fetched file); the node's analyticity half is subsumed by AT12.6's match; the row moves to not-declaration-matched — **UNFINISHED (the book's integral formula itself is not stated here; complete at pin time)**; AT12.5 ⚠12.5 Hankel contour representation — **UNFINISHED**; AT12.6 ⚠12.6 **Hurwitz continuation** — meromorphic on ℂ with a simple pole of residue 1 at s = 1: **[M]-matched this pass** (`HurwitzZeta.lean`: "the meromorphic continuation to all s ∈ ℂ" docstring, `hurwitzZeta_residue_one`, `differentiableAt_hurwitzZeta`; fetched); AT12.7 ⚠12.7 ζ continuation; L(s,χ) entire for χ ≠ χ₀ (`completedLFunction_one_sub`-family at M); AT12.8 ⚠12.8 Hurwitz's formula; AT12.9 ⚠12.9 ζ functional equation (`completedRiemannZeta_one_sub`); AT12.10 ⚠12.10 Hurwitz functional equation (`hurwitzZeta_one_sub`); AT12.11 ⚠12.11 L functional equation (root number G(1,χ̄)/(i^α√k)); AT12.12 ⚠12.12 special values **[REPAIRED R2d — PARTIAL]:** ζ(−n,a) = −B_{n+1}(a)/(n+1) and ζ(−2n) = 0. **Lean covers the Riemann instances only:** `riemannZeta_zero` (ζ(0) = −1/2) and `riemannZeta_neg_two_mul_nat_add_one` (ζ(−2(n+1)) = 0), both fetched; **the general Hurwitz/Bernoulli values are unmatched in the searched Lean sources** (AFP `Zeta_Function`'s abstract lists special values at negative integers — ABSTRACT tier, §4); AT12.13–AT12.15 ⚠12.13–12.15 Bernoulli numbers/polynomials, ζ(2n); AT12.16 ⚠12.16 L(0,χ) = −(1/k)Σχ(r)r; AT12.17 ⚠12.17 finite-sum approximation with remainders — **UNFINISHED**; AT12.18–AT12.20 ⚠12.18–12.20 strip inequalities for |ζ(s,a)|, |ζ(s)|, |L(s,χ)| — **UNFINISHED (constants unpinned)**.

**Dependencies:** Ch. 11, Ch. 6–8, contour integration. **Node count 25** (5 D + 20 T).

### Chapter 13 — Analytic Proof of the Prime Number Theorem (pp. 278–303, live-verified)

**Definitions (1):** AD13.1 ψ₁(x) = ∫₀^xψ(t)dt and the weighted error sums of the plan.

**Theorems (20; printed 13.15 = Pólya–Vinogradov [V]; post-PNT nodes carry ⚠ ≥ 13.16 shifted):**
- AT13.1 ⚠13.1 (§13.1) the plan: ζ(1+it) ≠ 0 ⇒ PNT, via ψ₁(x) ~ x²/2 ⇒ ψ(x) ~ x.
- AT13.2–AT13.7 ⚠13.2–13.7 (§13.2) the analytic lemma set — **UNFINISHED (all six rows; exponents/constants unpinned)**.
- AT13.8 ⚠13.8 (§13.3) contour integral representation of ψ₁(x)/x² with T-truncation — **UNFINISHED (R1d: the truncation is unspecified)**.
- AT13.9–AT13.10 ⚠13.9–13.10 (§13.4) ζ, ζ′ bounds near σ = 1 (O(log t), O(log²t)-class) — **UNFINISHED**.
- AT13.11 ⚠13.11 (§13.5) **nonvanishing ζ(1+it) ≠ 0 [REPAIRED R3b — now matched]:** Mathlib at M contains `riemannZeta_ne_zero_of_one_le_re` (`LSeries/Nonvanishing.lean` L417–421, fetched): ζ(s) ≠ 0 for **1 ≤ Re s**, with the value at s = 1 an explicitly documented junk-value convention — so genuine ζ(1+it) ≠ 0 for t ≠ 0 **is upstream**. v2's "no σ=1-line ζ nonvanishing at M" is retracted. The L-version `LFunction_ne_zero_of_one_le_re` (χ ≠ 1 ∨ s ≠ 1) is in the same file. The **book's 3-4-1 proof route** is not the upstream route (statement coverage, not route fidelity).
- AT13.12–AT13.13 ⚠13.12–13.13 (§13.6) bounds for 1/ζ and ζ′/ζ on σ = 1 — **UNFINISHED**.
- AT13.14 ⚠13.14 (§13.7) **PNT**: ψ(x) ~ x, θ(x) ~ x, π(x) ~ x/log x. Lean: atlas `prime_number_theorem` (0 sorry, Newman/Zagier route, re-fetched this pass); Isabelle: AFP (Newman) and `PNT_with_Remainder` with explicit error.
- AT13.15 **13.15 [V]** (§13.12) **Pólya–Vinogradov [REPAIRED R5 — explicit uniform pin statement]:** **‖Σ_{m=1..x}χ(m)‖ < 2√n·ln n for every nonprincipal Dirichlet character χ mod n and every x** — AFP `polya_vinogradov_inequality` (fetched, L826–828), with the constant 2 chosen **uniformly before** modulus, character and cutoff; primitive refinement ‖Σ‖ < √n·ln n (`polya_vinogradov_inequality_primitive`) and conductor form ‖Σ‖ < √(conductor)·ln(conductor)·d(n/conductor) (`polya_vinogradov_inequality_explicit`). **Do not pin the book's Big-O paraphrase:** AFP's own comment (L813–825, fetched) quotes Apostol's "Σ_{m≤x}χ(m) = O(√n log n)" and warns that for a fixed character this Big-O "seems to suggest that n is fixed … which would make the use of `Big-O' completely vacuous".
- AT13.16–AT13.17 ⚠ ≥13.16 shifted (§13.8) zero-free region σ ≥ 1 − c/log|t| and error-term consequence — **UNFINISHED as to the book's constants; prior-art record corrected R3a:** AFP's region is the **classical inverse-log shape**: final `zeta_nonzero_region` (`PNT_with_Remainder/Zeta_Zerofree.thy`, from the fetched tarball): zeros β+iγ ≠ 1 satisfy **1−β ≥ C₁/ln(|γ|+2)** with `PNT_const_C₁ = 1/952320` (`PNT_Notation.thy` L6; intermediate form 1−β ≥ (1/29760)·θ(2|γ|+1)/φ(2|γ|+1)). **It is not Vinogradov–Korobov** (that shape would be 1−β ≫ 1/(log^{2/3}|γ|(loglog)^{1/3})); v2's "stronger, VK-shaped" comparison is **removed**. The explicit PNT error **π(x) = Li(x) + O(x·exp(−(ln x)^{1/2}/3653))** (3653 outside the root) is re-verified in the same theory (L1109) and retained. Whether AFP's Perron/rectangle route matches Apostol's ψ₁ chain lemma-for-lemma remains **UNVERIFIED**.
- AT13.18 ⚠ ≥13.17 shifted (§13.9) the Riemann hypothesis — statement-only section; proof not in the book; printed numbering UNVERIFIED; flagged for re-classification at pin time.
- AT13.19 ⚠ ≥13.18 shifted (§13.10) application to d(n) — **UNFINISHED (R1d: the error sharpening is unspecified)**.
- AT13.20 ⚠ ≥13.19 shifted (§13.11) application to φ(n) averages — **UNFINISHED**.

**Dependencies:** Ch. 4, 11, 12; contour integration throughout. **Node count 21** (1 D + 20 T).

### Chapter 14 — Partitions (pp. 304–328, live-verified)

**Definitions (5):** AD14.1 partition p(n); AD14.2 Ferrers graphs, conjugate partitions; AD14.3 Euler function φ(x) = ∏_{n≥1}(1−xⁿ); AD14.4 restricted partition functions p_A(n); AD14.5 generalized pentagonal numbers g_k = k(3k−1)/2.

**Theorems (11):** AT14.1 ⚠14.1 generating functions Σp(n)xⁿ = ∏(1−x^m)^{−1}, |x| < 1 (`hasProd_genFun`, `genFun_eq_tprod`); AT14.2 ⚠14.2 odd-parts = distinct-parts (`card_odds_eq_card_distincts`); AT14.3–AT14.4 ⚠14.3–14.4 pentagonal-number theorem (`eulerFunction_eq_tprod`, `hasProd_eulerFunction`, `eulerFunction_eq_tsum_pentagonal`); (§14.5 Franklin's proof — unnumbered, not a node); AT14.5 **14.5 [V]** van Lint upper bound (AFP `Partition'_le`, fetched: n > 1 ⇒ p(n) ≤ π·exp(π√(2n/3))/√(6(n−1))); AT14.6 ⚠14.6 Euler's recursion (AFP `Partition'_recurrence`, L362, fetched); AT14.7 ⚠14.7 **Jacobi's triple product identity — analytic as printed** (|x| < 1, y ≠ 0; q = x, w = y² in AFP `jacobi_theta_nome_triple_product_complex`, w ≠ 0, ‖q‖ < 1; Ramanujan variant `ramanujan_theta_triple_product_complex` ‖ab‖ < 1); AT14.8 ⚠14.8 Jacobi's divisor-sum identities — **UNFINISHED**; AT14.9 ⚠14.9 log-differentiation identities (Σd(n)xⁿ = Σxⁿ/(1−xⁿ), exact); AT14.10–AT14.11 ⚠14.10–14.11 Ramanujan congruences p(5n+4) ≡ 0 (mod 5), p(7n+5) ≡ 0 (mod 7) — not located in any assistant within the searches run (bounded negative).

**Dependencies:** Ch. 1–2, absolute convergence in |x| < 1 — **the chapter carries a real analysis prerequisite** (v1's "no analysis prerequisites" stays retracted; see §6 and the R7 blueprint).

**Node count 16** (5 D + 11 T).

---

## §3 Prior-art register (re-verified live this pass, 2026-11-10 ≈20:50–21:15 UTC)

The fixed reference **M = `862047ba60dbfd5ec316433fb728e310612e6449`** (mathlib4; master has since moved — `api/mathlib-master.json`: `6ddf2ec4e7633620b28c3f6346eccae11d0b712`, 2026-11-10T20:16:58Z). All raw artifacts + sha256 in `prefetch-v3/MANIFEST.txt`.

### 3.1 Upstream mathlib4 at M — declaration-level checks this pass

Every declaration cited in §4's tables was re-verified present at M this pass by fetching the containing file (37 files shipped). Notations and corrections relative to v2: (i) the Euler-criterion declaration at M is **`euler_criterion`** (snake_case, `LegendreSymbol/Basic.lean` L62: a nonzero a : ZMod p is a square ↔ a^(p/2) = 1) — v2's `eulerCriterion` spelling is corrected; (ii) `Chebyshev.abs_psi_sub_theta_le_sqrt_mul_log` **exists** (L442: |ψx−θx| ≤ 2√x·log x, x ≥ 1) and additionally **`psi_eq_sum_theta`** (L416) and `psi_eq_theta_add_sum_theta` (L429) give AT4.1's identity; (iii) `eulerProduct_completely_multiplicative` is present in `EulerProduct/Basic.lean`; (iv) `riemannZeta_eulerProduct_exp_log` (L162) and `DirichletCharacter.eulerProduct_log_eq_LSeries` (L221) exist in `EulerProduct/DirichletLSeries.lean`; (v) `LSeries/Nonvanishing.lean` L417–421 contains `riemannZeta_ne_zero_of_one_le_re` (1 ≤ s.re) and L404 `LFunction_ne_zero_of_one_le_re` (χ ≠ 1 ∨ s ≠ 1). Tree-level absences re-confirmed at file level: no Perron/Pólya/PNT path under `Mathlib/NumberTheory/`; `Wanted.lean` (fetched) contains no prime-number-theorem entry; `HurwitzZeta.lean` contains no integral representation.

### 3.2 atlas-lean at `18d1aa399b6ebaa8cd9c4a48795b43f6734c3785`

`MathlibExt/NumberTheory/` contents re-fetched: **242 top-level entries = 211 files + 31 directories** (C10 confirmed a third time); `PrimeNumberTheorem.lean` re-fetched: `public theorem prime_number_theorem` (L183), **0 sorry**, Newman/Zagier route (imports `MathlibExt/Analysis/LaplaceTransform/NewmanTauberian`). LICENSE re-fetched: Apache 2.0 text preceded by "Codebase is not intended for use to train, fine-tune, distill, evaluate, or otherwise develop ML models" — no legal ruling made here; import ruling required before fleet use.

### 3.3 Formalpedia — the 16-record count independently reproduced (R6 closed)

Head `acf1cadf94817574ae8d3e7431e847c0685314b6` (2026-11-10T06:05:00Z, "Snapshot 2026-11-10") is still main's head (`api/formalpedia-branch.json`). All 20 shards of `envs/0df444a/` were **re-downloaded fresh this pass (455,592,034 bytes)**; per-shard sha256 in `formalpedia/shards-SHA256SUMS.txt`; a full scan for "Apostol" (case-insensitive) over every JSON record returns **exactly 16 records** (`formalpedia/apostol-records.jsonl`, with shard, line, id, theorem name and matching field). Every shard:line agrees with v2's table: 9 IANT records (index-000:9416 ArithmeticFunctions.mul_apply_prime_pow; index-002:6425 ChebyshevFunctions.sum_log_eq_sum_vonMangoldt_mul_div; index-002:11695/11699/11700 DirichletCharacters/DirichletLFunctions ×3; index-002:13095 DivisorSums.sum_card_divisors_le; index-004:3076/3077 MertensTheorems ×2; index-004:3080 **MertensTheorems.sum_log_div_prime_le** = record `d09af852-f479-4509-a198-8f0ba56f9115` citing "Apostol, Introduction to Analytic Number Theory, Theorem 4.10"), 3 Milnor (*Modular Functions*), 4 VectorSpaceOpt (*Mathematical Analysis*). The Mertens statement fixture `Thm_MertensTheorems_sum_log_div_prime_le.lean` (fetched) is **byte-identical to the v2 review's recorded hash** (`1d8ca57527e3f98364611275d5953d905a46f5f245840d5082d0b048450071f7`) and remains a statement fixture ending `by sorry` — a statement export, not the extracted proof; the actual one-sided Lean proof is Salt's (§2 AT4.10).

### 3.4 Palomar Registry — bounded observation at revision 855

This pass: `?q=Apostol` → empty; `?id=PALOMAR-2026-10-25-000017` → empty; both at **revision 855**, release `94992346d1089ae5922ee609e14d6e715f0db75a24aa0e0690bbdfbfb921e191`, totals 1,054/823 (identical to the v2 review's observation). History: 850 (v1), 851 (v1 review), 855 (v2 review + this pass) — **NOT FOUND at each actually-observed revision; revision 853 (v2's claim) remains UNVERIFIED** (its raw response was never delivered) and v3 relies on nothing from it.

### 3.5 AFP — 18 entries re-verified; repair-critical declarations from release tarballs

All 18 entry pages re-fetched (publication dates from the pages: Dirichlet_Series 2017-10-12; Dirichlet_L 2017-12-21; Prime_Number_Theorem 2018-09-19; Gauss_Sums 2019-12-10; Zeta_Function 2017-10-12; Euler_MacLaurin 2017-03-10; Prime_Distribution_Elementary 2019-02-21; Perrons_Formula 2026-06-17; PNT_with_Remainder 2024-05-05; Pentagonal_Number_Theorem 2025-04-23; Theta_Functions 2024-12-02; Rademacher_Series 2026-07-03; Rogers_Ramanujan 2024-12-02; Combinatorial_Q_Analogues 2024-12-02; Chebyshev_Prime_Bounds 2024-09-13; Bertrands_Postulate 2017-01-17; Prime_Harmonic_Series 2015-12-28; Sum_Of_Squares_Count 2024-11-26). **Note for future passes:** isa-afp.org per-theory HTML pages are now JS-rendered nav stubs (~3 KB); the authoritative declarations were read from the current release tarballs (7 tarballs fetched, exact bytes + sha256 shipped, 12 .thy sources extracted to `afp/src/`). Key declarations re-verified first-hand:
- **`mertens_first_theorem`** (Prime_Number_Theorem/Mertens_Theorems.thy L511): x ≥ 1 ⇒ |ℳ x − ln x| < 2, ℳ x = Σ_{p≤x}ln p/p — **full two-sided Mertens I**; **`mertens_second_theorem`** (L644): |Σ_{p≤x}1/p − ln ln x − meissel_mertens| ≤ 4/ln x + O-form; meissel_mertens defined via an explicit integral. No product-form corollary in this theory.
- **`zeta_nonzero_region`** (PNT_with_Remainder/Zeta_Zerofree.thy, final form L872): zeros ≠ 1 satisfy 1−β ≥ C₁/ln(|γ|+2), C₁ = PNT_const_C₁ = 1/952320 — classical inverse-log; PNT error at PNT_with_Remainder.thy L1109 (3653 outside the root).
- **`primitive_encoding`** (Gauss_Sums/Gauss_Sums.thy L501, labelled Theorem 8.15): three-part corollary — zero at positive noncoprime frequencies; separable at all frequencies; ‖G(1)‖² = n.
- **`ramanujan_sum_dirichlet_form`** (Gauss_Sums/Ramanujan_Sums.thy L330): c k n = Σ_{d|gcd(n,k)} d·μ(k/d), k > 0.
- **`polya_vinogradov_inequality`** (Gauss_Sums/Polya_Vinogradov.thy L826): ‖Σ_{m=1..x}χ m‖ < 2√n·ln n, nonprincipal χ — with the L813 comment quoting Apostol 13.15 and warning the fixed-modulus Big-O reading is vacuous; primitive and conductor refinements at L153/L662.
- **`selberg_asymptotic_formula`** (Prime_Distribution_Elementary/Selberg_Asymptotic_Formula.thy L78–83, `(* 4.18 *)`, inversion locale at L22 `(* 4.17 *)`).
- **Shapiro** (Prime_Distribution_Elementary/Shapiro_Tauberian.thy: locale `shapiro_tauberian` L29 with a(n) ≥ 0 and T(x) − x ln x ∈ O(x)).
- **JTP** (Theta_Functions/Jacobi_Triple_Product.thy L32 `jacobi_theta_nome_triple_product_complex` (w ≠ 0, ‖q‖ < 1); the proof structure at L313/L358: analytic continuation first in w, then in q — the R7 blueprint, see §6).
- **Perron** (Perrons_Formula/Perrons_Formula.thy: `perron_asymp` L982, `perron_effective_strong` L1208).
- **Partitions** (Pentagonal_Number_Theorem/Pentagonal_Number_Theorem.thy: `Partition'_recurrence` L362; `(* Theorem 14.5 in Apostol *)` L400; `Partition'_le` L424).

### 3.6 girving/interval — Euler–Maclaurin (R9 sources)

`Formula.lean` and `Bernoulli.lean` at `2c89204b806f4acd9b8530a38e656369d0a4d7f3` fetched: `saw 1 x = Int.fract x − 1/2` (`saw_one`, Bernoulli.lean L146) — the sawtooth is **P₁ = {t} − ½**, the basis of the §2 AT3.1 corrected corroboration.

### 3.7 Metamath — pointwise Selberg located (R4)

`logsqvma2.html` and `selberg.html` fetched. `logsqvma2` assertion and description quoted in §2 AT2.20 (Shapiro 10.4.8 p. 418, Carneiro 2016-05-13); `selberg` (Shapiro 10.4.10 p. 419, Carneiro 2016-05-23) re-confirmed. v1's `dirith`/`pnt*` observations remain carried as v1-verified (set.mm not re-downloaded).

### 3.8 Other provers and the bounded book-level negative

HOL Light / Coq archive / Freek-100 observations are carried from v1 (attributed), except the fresh Coq code search (3 irrelevant hits). **Fresh GitHub searches this pass (authenticated, JSON shipped):** repo `Apostol` × {Lean, Isabelle, Coq} → **0/0/0**; code `Apostol language:lean` → 25; code exact-title → 1 Lean / 6 Isabelle (AFP mirrors only) / 0 Coq; code `Apostol language:Coq` → 3 (irrelevant); repo exact-title → 2 (course/image projects). **Conclusion supported: no complete fourteen-chapter Apostol project was identified in these searches.** Nothing stronger is claimed.

---

## §4 Coverage map v3 — remapped node by node (R2)

### 4.1 Method (fixed)

A node is counted **full-covered [M]/[E]/[X]** only when a specific, named declaration (or Formalpedia Proved record / Metamath theorem) **whose statement implies the node's full statement** was verified this pass in the shipped sources, with the assistant named per node (upstream Mathlib [M]; external Lean [E]: atlas, salt, Formalpedia, interval; cross-assistant [X]: AFP/Isabelle, Metamath). A node whose verified declarations prove **only a proper part** of the node is **PARTIAL** (named part stated) and is **excluded from every numerator**. **ABSTRACT** (AFP entry-scope statements) are prior art but never counted. The remainder column is **"not declaration-matched"** — nodes with no full-node match in any checked assistant (this is a match count, not an openness claim: ABSTRACT-supported and unmatched nodes both live here). v2's §4 defined the remainder as excluding ABSTRACT-supported nodes but computed nodes-minus-DECL; v3 renames and computes the stated set.

**v2's headlines are withdrawn.** The remapped figures: **[M] 57/318 (17.9%), [E] 2/318, Lean full-node 59/318 (18.6%), [X] 9/318 (2.8%), full-node coverage in some assistant 68/318 (21.4%)** — auditable lower bounds under the corrected semantics. The total coincides with v2's 68 by accident of composition (−AT11.11, −AT12.12 from Lean-full; AT12.4→AT12.6 relabel; +AT13.11, +AT2.20; AT4.10 moved [E]→[X] with its Lean half demoted to PARTIAL); the Lean figure drops 61→59. **PARTIAL tier (3 nodes):** AT4.10 (Lean: salt one-sided upper bound only), AT11.11 (Lean: ζ + Dirichlet-L instances only), AT12.12 (Lean: Riemann-ζ instances only).

### 4.2 Per-chapter table (full-node matches; per-node sources in §2/§3)

| Ch. | Nodes | [M] full (declarations at M) | [E] full | [X] full | PARTIAL (in Lean) | Not declaration-matched |
|---|---:|---|---|---|---|---:|
| 1 | 17 | **4**: AD1.3 (`Nat.Prime` def); AT1.5 (`factorization_prod_apply`); AT1.7 (`Nat.exists_infinite_primes`); AT1.10 (`not_summable_one_div_on_primes`) | — | — | — | 13 |
| 2 | 34 | **13**: AD2.1, AD2.2 (`isMultiplicative_moebius`), AD2.3 (`totient_eq_card_coprime`), AD2.4 (`instMonoid`), AD2.5 (`one_apply`), AD2.7 (`vonMangoldt_apply`), AD2.8 (`IsMultiplicative`), AD2.10 (`liouville_apply`), AD2.11 (`sigma_apply_prime_pow`, ℕ-domain), AT2.1 (`coe_moebius_mul_coe_zeta`), AT2.3 (`sum_totient`), AT2.4 (`totient_eq_mul_prod_factors`), AT2.8 (`moebius_mul_log_eq_vonMangoldt` family) | — | **1**: AT2.20 (Metamath `logsqvma2`) | — | 20 |
| 3 | 16 | 0 | **1**: AT3.1 (interval `sum_Ioc_eq_integral_add_of_hasDerivWithinAt`, p = 1; Abel form `sum_mul_eq_sub_sub_integral_mul` at M is AT4.3's) | — | — | 15 (= 3 D + AT3.2–13) |
| 4 | 22 | **4**: AD4.1 (`def psi`, `def theta`); AT4.1 (`psi_eq_sum_theta` + `abs_psi_sub_theta_le_sqrt_mul_log`); AT4.3 (`sum_mul_eq_sub_sub_integral_mul`); Bertrand node of AT4.6–7 (`exists_prime_lt_and_le_two_mul_succ`) | — | **3**: AT4.8 (AFP Shapiro); AT4.10 (AFP `mertens_first_theorem`, two-sided); AT4.17 (AFP 4.18) | AT4.10 (salt one-sided) | 15 |
| 5 | 27 | **3**: AT5.7 (`pow_totient_mod_eq_one`); AT5.10 (`prime_iff_fac_equiv_neg_one`); AT5.12 (`chineseRemainder`, `chineseRemainder_modEq_unique`) | — | — | — | 24 |
| 6 | 23 | **3**: AT6.7, AT6.8 (`sum_characters_eq`, `sum_characters_eq_zero`, `sum_char_inv_mul_char_eq`); one L(1,χ)≠0 node (`LFunction_apply_one_ne_zero_of_quadratic`, statement) | — | — | — | 20 |
| 7 | 10 | **1**: AP infinitude within AT7.2–3 (`forall_exists_prime_gt_and_zmodEq`, `infinite_setOf_prime_and_modEq`) | — | — | — | 9 |
| 8 | 30 | **2**: AD8.5 (`def gaussSum`); one basic Gauss-sum node (`gaussSum_one_right`, `gaussSum_mulShift`) | — | — | — | 28 |
| 9 | 31 | **5**: AT9.2 (`euler_criterion`); (−1\|p)/(2\|p) node (`neg_one_pow_div_two_of_one_mod_four`; `at_two`); AT9.11 (`quadratic_reciprocity`); AD9.4 (Jacobi decls); complementary-laws node (`at_two`, `at_neg_one`) | — | — | — | 26 |
| 10 | 24 | **7**: AD10.2 (cyclic-units framing); AT10.4 (`isCyclic_units_two_pow_iff` + exponent derivation from `orderOf_unitFive`/`isComplement'_zpowers_unitFive_neg_one`, §2); AT10.5 (`isCyclic_units_prime`); AT10.7 (`isCyclic_units_of_prime_pow`); AT10.8 (prime-power development); AT10.9 (`isCyclic_units_two_mul_iff_of_odd`); AT10.10 (`isCyclic_units_iff`) | — | — | — | 17 |
| 11 | 22 | **3**: AD11.1 (`LSeriesSummable` family); AT11.5 (`eulerProduct`, `eulerProduct_tprod`); AT11.6 (`eulerProduct_completely_multiplicative`) | — | **1**: AT11.17 (AFP `perron_asymp` + `perron_effective_strong`) | AT11.11 (ζ + Dirichlet-L instances: `riemannZeta_eulerProduct_exp_log`, `DirichletCharacter.eulerProduct_log_eq_LSeries`) | 18 |
| 12 | 25 | **6**: AD12.2 (HurwitzZeta def/series); AD12.3 (`riemannZeta`); **AT12.6** (`hurwitzZeta_residue_one`, `differentiableAt_hurwitzZeta`); AT12.9 (`completedRiemannZeta_one_sub`); AT12.10 (`hurwitzZeta_one_sub`); AT12.11 (`completedLFunction_one_sub`) | — | — | AT12.12 (Riemann instances: `riemannZeta_zero`, `riemannZeta_neg_two_mul_nat_add_one`) | 19 |
| 13 | 21 | **1**: AT13.11 (`riemannZeta_ne_zero_of_one_le_re`; route differs) | **1**: AT13.14 (atlas `prime_number_theorem`, 0 sorry) | **1**: AT13.15 (AFP `polya_vinogradov_inequality`, uniform constant 2) | — | 18 |
| 14 | 16 | **5**: AD14.3 (Euler function def); AT14.1 (`hasProd_genFun`, `genFun_eq_tprod`); AT14.2 (`card_odds_eq_card_distincts`); AT14.3 (`eulerFunction_eq_tprod`, `hasProd_eulerFunction`); AT14.4 (`eulerFunction_eq_tsum_pentagonal`) | — | **3**: AT14.5 (`Partition'_le`); AT14.6 (`Partition'_recurrence`); AT14.7 (AFP JTP) | — | 8 |
| **Σ** | **318** | **57 (17.9%)** | **2** | **9** | **3 (excluded)** | **250** |

**Check row (Ch. 3, R2):** 16 nodes − 1 full ([E] AT3.1) = **15 not-declaration-matched** = AD3.1–3 + the twelve theorem nodes AT3.2–AT3.13 — v2's "13 unverified nodes" narrative was wrong; v3's narrative and table agree everywhere by construction (each chapter's remainder = nodes − [M] − [E] − [X] full matches; ABSTRACT prior art is listed in §3.5 and never enters the arithmetic).

**ABSTRACT tier (unchanged in kind, not counted):** AFP Gauss_Sums (full Ch. 8), Prime_Distribution_Elementary (Ch. 4 + parts of 3), Dirichlet_Series (much of Ch. 2/3/11), Prime_Number_Theorem (PNT forms + Mertens I/II), Zeta_Function (E–M continuation route, special values, Hurwitz's formula, reflection), Dirichlet_L, Chebyshev_Prime_Bounds, Rademacher/Rogers–Ramanujan/Combinatorial_Q_Analogues (beyond-book), Theta_Functions/Pentagonal chain (also counted at node level above), Metamath `dirith`/`pnt*` (v1-verified), HOL Light (v1-verified).

### 4.3 Route blocks, exact (R7 — replaces v2's 17/18/19)

v2's "the literal-route blocks are 17/18/19 unverified nodes" conflated chapter remainders with route costs (and Ch. 13's remainder then included content now matched or classified). The exact blocks, nonoverlapping, with dependency edges:

**Ch. 11 block — 18 not-declaration-matched nodes:** AD11.2, AD11.3, AD11.4, AT11.1, AT11.2, AT11.3, AT11.4, AT11.7, AT11.8, AT11.9, AT11.10, AT11.11* (PARTIAL), AT11.12, AT11.13, AT11.14, AT11.15, AT11.16, AT11.18. Edges: AT11.4 ← AD11.1; AT11.5/6 (matched) ← AD11.3; AT11.10 ← AT11.2; AT11.16 ← AT11.1; AT11.17 (matched [X]) ← AT11.1–AT11.3. *AT11.11 is PARTIAL and listed here because its full node is unmatched.

**Ch. 12 block — 19:** AD12.1, AD12.4, AD12.5, AT12.1, AT12.2, AT12.3, AT12.4, AT12.5, AT12.7(part: L-entirety matched via `completedLFunction_one_sub` under AT12.11's family; ζ-continuation matched under AT12.6 — the node's own full statement unmatched), AT12.8, AT12.12* (PARTIAL), AT12.13, AT12.14, AT12.15, AT12.16, AT12.17, AT12.18, AT12.19, AT12.20. Edges: AT12.5–AT12.6 ← AD12.1–AD12.2; AT12.8 ← AT12.6; AT12.9–AT12.11 ← AT12.8; AT12.18–AT12.20 ← AT12.6.

**Ch. 13 block — 18:** AD13.1, AT13.1, AT13.2, AT13.3, AT13.4, AT13.5, AT13.6, AT13.7, AT13.8, AT13.9, AT13.10, AT13.12, AT13.13, AT13.16, AT13.17, AT13.18 (RH, statement-only flag), AT13.19, AT13.20. Edges: AT13.14 (matched) ← AT13.1 ← {AT13.11 (matched), AT13.8 ← Perron-class input + AT12.18–20, AT13.12–13}; AT13.8 ← AT13.9–AT13.10; AT13.16–17 ← AT13.12–13; AT13.19–20 ← AT13.16–17.

**The charter consequence (R7):** a statement-complete project must prove the book's own intermediate statements even where the goal statement is imported (atlas PNT or Mathlib Wiener–Ikehara `tendsto_sum_div`, whose Chebyshev-type hypothesis differs from the book's route). Importing PNT removes only AT13.14's proof obligation, **not** AT13.2–13/16–17/19–20 — those are book statements in their own right. Conversely, AT13.11's statement is now upstream, but the book's 3-4-1 argument remains charter content under statement fidelity. The route decision (statement-complete vs route-complete) therefore swings the lane by exactly the Ch. 13 block above plus the Ch. 12 contour/strip nodes — no vague "≈19-node block" claim is made.

---

## §5 The hardest theorems + Selberg: strongest published forms, quotations (v2-review-confirmed items retained, R3/R5 applied)

**1. The Prime Number Theorem (AT13.14).** Strongest verified formalized form (cross-assistant): AFP `PNT_with_Remainder` (2024-05-05) — π(x) = Li(x) + O(x·exp(−(ln x)^{1/2}/3653)), 3653 outside the root (re-verified at theory L1109), with the **classical inverse-log zero-free region** `1−β ≥ (1/952320)/ln(|γ|+2)` (final `zeta_nonzero_region` + `PNT_const_C₁`). **No VK comparison is made** (v2's was false); AFP's region is of the same classical shape as the book's, with explicit constants; whether AFP's Perron/rectangle route reproduces Apostol's ψ₁ chain lemma-for-lemma is **UNVERIFIED**. Lean: atlas `prime_number_theorem` (0 sorry, Newman/Zagier); Mathlib has no PNT (Wanted.lean re-checked) but now has Wiener–Ikehara as a route enabler and `riemannZeta_ne_zero_of_one_le_re` as the nonvanishing input. **Delta:** the book's literal contour route (ψ₁-representation, 3-4-1, classical region with the book's constants) is formalized nowhere within the searches; the statements PNT and ζ(1+it)≠0 are covered.

**2. Dirichlet's theorem (AT7.2–3).** [Summary, not verbatim — C6 label retained.] Mathlib at M: `forall_exists_prime_gt_and_zmodEq` / `infinite_setOf_prime_and_modEq` — the infinitude statement (q ≠ 0, coprimality, prime above each threshold), not the AT7.9 asymptotic. AFP `Dirichlet_L` (2017-12-21): Dirichlet's theorem via Newman's nonvanishing proof, not the book's route. **Delta:** no upstream PNT-in-progressions; the book's Ch. 6–7 route is no formalization's route.

**3. Euler's summation formula (AT3.1).** Corrected statement and corrected interval corroboration in §2 (R9: P₁ = {t} − ½, half-terms cancel via ∫f′; f ≡ 1, y = 1, x = 3/2 sums to 0 on both sides). Mathlib `AbelSummation.lean` is the Abel form (AT4.3). AFP `Euler_MacLaurin` is beyond-book. **Delta:** trivial for the pin; the residual work is the Ch. 3 asymptotic applications (15 not-declaration-matched nodes in Ch. 3).

**4. Perron's formula (AT11.17).** Retained from v2 (review-confirmed): AFP `perron_asymp` — kernel **F(z+w)·x^w/w**, convergence hypothesis the ordinary abscissa, Σ′ half-weight convention at integers; `perron_effective_strong` with absolute abscissa and T > 0; the AFP abstract's faulty `x^s w` typography remains do-not-pin. Statement re-verified from the tarball this pass (L982/L1208). **Delta:** the basic absolute-convergence/noninteger form is weaker in scope than AFP's; the T-truncated error node (AT11.18) is UNFINISHED as a book statement.

**5. Jacobi's triple product (AT14.7).** AFP `jacobi_theta_nome_triple_product_complex` (w ≠ 0, ‖q‖ < 1) = the book's identity under q = x, w = y² (|x| < 1, y ≠ 0). **Blueprint (R7, from the fetched .thy):** the AFP proof first establishes the identity on a restricted real domain (0 < q < 1/4, 1/2 < w < 1) with absolute summability to exchange the double sums, then continues analytically **first in w (on ℂ\{0})**, then **in q (on the unit disk)**. A Lean port must therefore budget: infinite product/sum convergence on the domain; holomorphic dependence of both sides in each variable; the identity theorem; only then the transfer. The Ramanujan variant (‖ab‖ < 1) covers the book's two-square corollary path.

**6. Selberg.** Asymptotic form (AT4.17): prior art everywhere checked (AFP 4.18 following Apostol; Metamath `selberg`; Avigad–Donnelly–Gray–Raff per the reviews) — retraction retained. Pointwise form (AT2.20): **now also prior art** (Metamath `logsqvma2`, R4). No Selberg openness claim survives anywhere in this dossier.

---

## §6 Revised recommendation, prerequisites, schedule, risks (R7, R8 applied)

### What the evidence supports

- **Not found in the searches run:** no complete fourteen-chapter project (§3.8) — v2's "would still be the first complete formalization" is **withdrawn** as exceeding the searches (R8); only the bounded negative is asserted. Chapter-level prior art exists (AFP Ch. 8 full; Ch. 4 + parts of 3; much of 2/3/11; the Ch. 14 chain through Rademacher).
- The crown is substantially taken cross-assistant: PNT (+ explicit remainder + classical region), Perron (incl. effective), Dirichlet, Mertens I & II (two-sided), Selberg asymptotic **and pointwise**, full Ch. 8 incl. Pólya–Vinogradov (explicit uniform), JTP → pentagonal → p(n)-recurrence → van Lint → Rademacher, ζ(1+it) ≠ 0 (Mathlib). Within bounded searches, new-to-every-assistant content is confined to: index calculus, the Ramanujan partition congruences, the book's literal Ch. 12–13 routes and constants, the Mertens product corollary, presentational book-form nodes — **each requiring a dedicated recorded search before any "first" claim** (twice-burned rule).
- Auditable Lean full-node coverage is **59/318 (18.6%)** — an import-and-integrate project with a hard analytic remainder, not a greenfield.

### Recommendation (one paragraph)

**Unchanged in shape from v2, on corrected evidence:** Apostol as #4 is defensible only as a statement-complete, import-first integration project whose new-to-Lean core is port-with-blueprint against named sources, and only if the programme explicitly waives "new to every assistant" for the crown. If the criterion is maximal first-to-any-prover mathematics, this book is the wrong pick. The slot decision belongs to the coordinator on this dossier plus the renewed crossed review; no slot claim is made.

### Lane prerequisites (decision points)

1. **Ch. 12–13 route carve-out, quantified exactly (R7):** statement-complete (import PNT/nonvanishing; still prove the book's contour/estimate lemmas as book statements — Ch. 11 block 18, Ch. 12 block 19, Ch. 13 block 18, exact lists in §4.3) vs route-complete (prove the ψ₁ chain as the book does). The swing is the Ch. 13 + Ch. 12 contour/strip nodes, no longer a vague "tens of nodes".
2. **Ch. 14 analytic decision, with the real prerequisites on the schedule (R7):** JTP as the analytic identity (|x| < 1, y ≠ 0) via the AFP restrict-then-continue blueprint; schedule items: q-Pochhammer/product convergence on |q| < 1 (Mathlib `hasProd`/`tprod` machinery, exercised by `hasProd_eulerFunction`), holomorphic dependence in w and q, the identity theorem, the two-step continuation. v1's "no analysis prerequisites" stays retracted.
3. **Import rulings + frozen commits (retained):** Mathlib at M or later (master at `6ddf2ec4e763…` at pass end); atlas `18d1aa3…` (license = Apache 2.0 + ML-use preamble — ruling required before import); UyNewNas `88ee563b…` (drift risk; paths only); salt `e7d9a1906772`; interval `2c89204b…` (10 E–M files, sorry-free per v2's audit, 2 re-fetched this pass); AFP current releases (7 tarballs + sha256 shipped). Lean pin: leanprover/lean4:v4.34.1.
4. **Selberg scope (closed):** neither Selberg form is a novelty candidate; the §§4.10–4.11 + Ch. 2 material is port-with-blueprint at most.
5. **Statement-fidelity pinning pass (mandatory, unchanged):** every ⚠ re-pinned against the physical printing; every UNFINISHED row completed before it can be pinned; the three [V] anchors stay; the AT4.11–12 product constant pins as e^{R−B} (≡ e^{−γ} in the standard normalization), never e^{−B}.

### Schedule

Dependency-first (Ch. 1–2 → 3–4 → 5–10 → 11–12 → 13–14) with the R7 corrections: Ch. 14 budgets the convergence/holomorphy/identity-theorem layer and runs after or with the Ch. 11 half-plane machinery; Ch. 4's §§4.10–4.11 and Ch. 8 are port-with-blueprint spikes against AFP/Metamath/salt, not novelty work; Ch. 13's route decision is taken at pin time per decision 1.

### Risks

1. **Route-fidelity risk (Ch. 11–13):** now stated as the exact blocks of §4.3.
2. **Prior-art acceleration risk, timing corrected (R8):** by first publication — PNT_with_Remainder 2024-05-05, Perrons_Formula 2026-06-17, Rademacher_Series 2026-07-03 — these are months-to-years-old entries; registry refreshes do not make old mathematics newly formalized. Genuinely recent: Wiener–Ikehara in Mathlib (2026-11-03) and the 2^α primitive-root completion (2026-10-31). The absorption-path argument survives in that weaker, accurate form: signature analytic content is being absorbed into the ecosystem, so waiting erodes firsts and starting requires re-verifying every frozen SHA at launch.
3. **License/attribution (atlas preamble; UyNewNas drift):** unchanged; rulings before imports.
4. **Novelty-claim discipline:** any residual "first" claim carries its own recorded search (queries + dates), bounded — three overstated claims have now been caught and retracted across v1/v2 (Selberg asymptotic, VK-shape, pointwise Selberg); there will not be a fourth in this dossier.

---

## §7 Source register (all live checks 2026-11-10 ≈20:50–21:15 UTC; artifacts + sha256 in `prefetch-v3/MANIFEST.txt`)

| Source | Reference | Access |
|---|---|---|
| Springer book page | DOI 10.1007/978-1-4757-5579-4 | **live this pass** (269,444 B; TOC extracted; §1) |
| mathlib4 | M = `862047ba60dbfd5ec316433fb728e310612e6449`; master `6ddf2ec4e7633620b28c3f6346eccae11d0b712` (20:16:58Z); 37 files + Wanted.lean at M | raw + api |
| AFP | 18 entry pages + 7 release tarballs (Gauss_Sums, Prime_Number_Theorem, PNT_with_Remainder, Prime_Distribution_Elementary, Theta_Functions, Pentagonal_Number_Theorem, Perrons_Formula) + 12 extracted .thy | curl -L (isa-afp.org) |
| Metamath | `logsqvma2.html`, `selberg.html` | curl -L |
| jyh/salt | `e7d9a19067725884e4689f9c3bb231b3e14c591b`; `Salt/Maynard/Mertens.lean` | raw |
| prove2me/formalpedia | head `acf1cadf94817574ae8d3e7431e847c0685314b6`; 20 shards re-downloaded fresh (455,592,034 B; sha256 per shard); statement fixture (hash-matches the v2 review's record); 16-record scan output | raw + api |
| girving/interval | `2c89204b806f4acd9b8530a38e656369d0a4d7f3`; Formula.lean, Bernoulli.lean | raw |
| atlas-lean | `18d1aa399b6ebaa8cd9c4a48795b43f6734c3785`; LICENSE, PNT file, contents JSON | raw + api |
| Palomar | rev 855, release `94992346…`, 1,054/823; `q=Apostol` → 0; tracked ID → 0 | api |
| GitHub searches | repos ×4, code ×5 (JSON shipped; four `[]` zero-result files annotated in the manifest) | gh (authenticated) |
| Carried (attributed, not re-run) | v1's HOL Light/Coq/Freek/Metamath-set.mm observations; v2's interval 10-file sorry audit (2 files re-fetched this pass); UyNewNas tree counts | — |

---

## §8 Repair compliance map (v2 review R1–R9 → where repaired in v3)

| Review ID | Repair in this dossier |
|---|---|
| **R1 (blocking)** — false formulas; global UNFINISHED rule | (a) §2 AT8.4–7: corrected Σ_{d|k}s_d(n) = **k·[k|n]** with the Möbius-cancellation derivation from AFP `ramanujan_sum_dirichlet_form` (machine-checked 79×79); second identity **withdrawn** with five counterexamples and replaced by the correct multiplicative evaluation (machine-checked 119×119); multiplicativity-in-n claim also corrected (c₂ counterexample). (b) §2 AT8.10–11/12–13/19–20: primitivity + coprimality hypotheses everywhere, via AFP `primitive_encoding` (mod-3/n=3 counterexample recorded). (c) §2 AT4.11–12: product constant **e^{R−B}**, R < 0 termwise, derivation given; classical e^{−γ} identification noted; book symbol ⚠. (d) Global rule: UNFINISHED marks on AT11.13–15, AT5.16–18, AT13.8, AT13.19 **and** the full list in §0.3/§2; §8's own claim is now true row-by-row (AT13.2–13 all marked, 13.8 included). |
| **R2 (blocking)** — coverage remap | §4: node-by-node remap; v2's 61/68 headlines withdrawn; new figures [M] 57 / [E] 2 / Lean 59 (18.6%) / any 68 (21.4%) with composition explained and the coincidence flagged; PARTIAL tier (AT4.10, AT11.11, AT12.12) excluded from numerators; AT4.10 split (salt one-sided [PARTIAL-E]; AFP `mertens_first_theorem` two-sided [X], declaration fetched); AT12.4→unmatched and AT12.6→[M] (ID/content fixed); AT12.12→PARTIAL (Riemann instances only); AT10.4→full with the exponent derivation supplied from `orderOf_unitFive` + `isComplement'_zpowers_unitFive_neg_one`; §4 remainder renamed "not declaration-matched" and computed exactly; Ch. 3 reconciled (15 = 3 D + AT3.2–13). |
| **R3 (blocking)** — Ch. 13 prior art | §2 AT13.16–17 + §5.1: VK comparison removed; classical inverse-log region quoted from the fetched `zeta_nonzero_region` (C₁ = 1/952320; intermediate 1/29760 form); PNT error retained (3653 outside the root); §2 AT13.11 + §4: `riemannZeta_ne_zero_of_one_le_re` at M acknowledged and counted [M] (junk-value caveat noted); Ch. 13 block and route estimates restated (§4.3). |
| **R4 (major)** — pointwise Selberg | §0.2, §2 AT2.20, §3.7, §5.6: Metamath `logsqvma2` located, fetched, assertion transcribed, attributed (Shapiro 10.4.8 p. 418, Carneiro 2016-05-13); removed from novelty candidates; counted [X]. |
| **R5 (major)** — Pólya–Vinogradov | §2 AT8.22 + AT13.15: explicit uniform pin statement ‖Σ_{m=1..x}χ(m)‖ < 2√n·ln n (constant 2 fixed before modulus/character/cutoff); AFP's vacuity warning quoted; primitive/conductor refinements recorded. |
| **R6 (major)** — evidence gaps | `prefetch-v3/` complete as delivered (101 files, sha256 manifest, non-empty verified, zero-result searches annotated); Formalpedia 16-record count reproduced from a fresh full shard download with per-shard checksums and matched-record output; Formalpedia fixture hash-matches the review's record; Palomar re-observed at 855; **rev 853 remains UNVERIFIED and unused**; Springer TOC now live-verified. |
| **R7 (major)** — Ch. 14 blueprint + route blocks | §5.5 + §6 decision 2: convergence, holomorphic dependence, identity theorem, two-step continuation on the schedule; §4.3: exact nonoverlapping node lists + dependency edges replace 17/18/19; alternative-proofs vs statement-omission separated (importing PNT does not remove the book's contour lemmas from a statement-complete charter). |
| **R8 (moderate)** — §6 contradiction + timing | §0.1, §3.8, §6: "would still be the first" withdrawn; bounded negative only; per-entry publication dates given (2024-05-05, 2026-06-17, 2026-07-03 are not last-six-weeks results); genuinely recent items identified (Wiener–Ikehara, 2^α completion). |
| **R9 (moderate)** — Euler-summation corroboration | §2 AT3.1: sawtooth identified as P₁ = {t} − ½ (`saw_one` fetched); the half-endpoint terms cancel via the ∫f′ contribution — algebra written out; v2's "endpoint term already is the fractional-part term" corrected. |

**Residual limits (explicit):** the printed-book inventory (318 nodes, all ⚠) and section numbering remain unpinned; coverage above the §4 full-node totals is UNVERIFIED; the 435 MB Formalpedia shards are checksummed but not shipped bodily (reproduction commands in the package README); v1-carried HOL/Coq/Metamath-set.mm observations keep their attributed provenance; no dependency-closure, build, or axiom audit is claimed; no complete import-closure sorry-audit beyond the fetched files.

---

**Rule-compliance footer.** This dossier is a research input; it authorizes no lane. Unmarked-⚠ book numbers herein are reconstructions pending pinning against the physical printing; the three [V] anchors (4.10, 13.15, 14.5) carry their sources at the node. Every live source was checked 2026-11-10 (≈20:50–21:15 UTC) with heads/SHAs as recorded in §7 and artifacts checksummed in `prefetch-v3/MANIFEST.txt` (101 files, complete as delivered). Claims that could not be verified are marked UNVERIFIED, never asserted. No coding, no Lean, no repo writes, no GitHub writes, no installs were performed; no review was requested, arranged, or contacted — the renewed crossed review is the coordinator's to appoint. Any future proof lane still needs its own frozen pin manifest and crossed review; Lean pin: leanprover/lean4:v4.34.1.

DOSSIER COMPLETE.
