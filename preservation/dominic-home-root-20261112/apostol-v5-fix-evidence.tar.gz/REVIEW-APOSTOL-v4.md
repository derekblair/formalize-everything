FAIL

Crossed review of **DOSSIER-APOSTOL-v4.md** (T. M. Apostol, *Introduction to Analytic Number Theory*, Springer UTM, 1976; DOI `10.1007/978-1-4757-5579-4`), `formalize-everything #67`, for Derek Blair. Review/live-check date: **2026-11-11 UTC**. Coordinator-appointed Carbon review (Gemini 4 Carbon High, fresh session on `xanthe`) of Carbon-authored fix work (delivered from `dominic`); research only.

**Executive summary:** `DOSSIER-APOSTOL-v4.md` closes **C2, C4, C5, C6**, all four nonblocking items, all `120` `UNFINISHED` markers (`0` unmarked sketches across `318` unique §2 bullets), both evidence manifests (`44/44` in `evidence-v4`, `101/101` in `evidence-v3`), and `68` of `69` counted §4.2 matches, while maintaining an honest candidate-without-selection stance. However, **`AT12.10` (`DOSSIER-APOSTOL-v4.md:405`, counted as full `[M]`) states a false/divergent infinite trigonometric series identity on `∀ n ∈ ℕ, s ≠ -n ∧ (a < 1 ∨ s ≠ 1)` by omitting `Re(s) > 1` and misrepresenting `HurwitzZeta.hurwitzZeta_one_sub` (`HurwitzZeta.lean:157`, which uses the analytically continued function `expZeta`).** Under the brief's explicit **C1** and **C3** blocking rules, this single defect is blocking (**FAIL**). **The `#4` slot is NOT established** (neither claimed by v4 nor established by the verified evidence), and this review authorizes no proof lane.

---

## §0 Provenance, Evidence Boundary, and Manifest Audit

### 0.1 Provenance & Antecedent Chain

All dossier and review artifacts shipped in `/root/projects/math/tasks/carbon-review-apostol-v4-20261110` were independently hashed (`sha256sum`) and line/byte-counted on `xanthe` on `2026-11-11`:

| Artifact | SHA-256 | Bytes | Lines | Recorded status |
|---|---|---:|---:|---|
| `DOSSIER-APOSTOL-v4.md` | `75f6aa332ac949dde87816f75b050ef2061aa8b671ff550a1dd284e18744cca1` | 158,473 | 741 | Under review; ends `DOSSIER COMPLETE.` |
| `REVIEW-APOSTOL-v3.md` | `1735cfc9b1067e6dc328f92a60c996af4033b5aa3f65efb73e017d4922b70951` | 42,939 | 208 | Authoritative repair spec (**FAIL**, C1–C6 + 4 nonblocking) |
| `DOSSIER-APOSTOL-v3.md` | `d5861c5101cd065c0f544e19448d15fbc7a0968614b5ba70a8f579db4f975d7f` | 83,695 | 422 | Failed antecedent |
| `REVIEW-APOSTOL-v2.md` | `54419458d7501605416f71e54affe6a1f5090cdbff46aff90bbd6f87fdb74cc9` | 44,013 | 235 | Prior repair authority (**FAIL**, R1–R9) |
| `DOSSIER-APOSTOL-v2.md` | `7cc27b0201c5b6ba13d01f05165ccd1439f7da11226c84092d02a49198f7f13a` | 91,156 | 522 | Failed antecedent |
| `REVIEW-APOSTOL-v1.md` | `29c42b7f803ae8599a94463f2e2b938c6534da852d9d2cf471ed61ba3e39d882` | 34,295 | 180 | Prior repair authority (**FAIL**) |
| `DOSSIER-APOSTOL.md` | `93a491f62af895684b281ab372a6e3173c327fb9c55d8f70317327cf7d158da1` | 117,427 | 624 | Failed antecedent |

### 0.2 Research-Only Evidence Boundary

- **Reviewer independence:** Executed in a fresh Carbon session on `xanthe`, distinct from both the v4 fix session on `dominic` and the v3 review session on `xavier`.
- **Hard gates observed:** Literature and source-level verification only. No Lean or Isabelle build, kernel check, `#print axioms`, formalization, package installation/removal, repository mutation, GitHub write, or merge was performed. Source inspection and lexical trust-escape screening do not certify transitive dependency closure or kernel compilation. This review does not authorize any proof lane.
- **Pinned upstream sources (live-verified `2026-11-11` via `curl -fsSL` with HTTP `200` validation):**
  - **M** = `leanprover-community/mathlib4@862047ba60dbfd5ec316433fb728e310612e6449`
  - **A** = `facebookresearch/atlas-lean@18d1aa399b6ebaa8cd9c4a48795b43f6734c3785`
  - **interval** = `girving/interval@2c89204b806f4acd9b8530a38e656369d0a4d7f3`
  - **Formalpedia** = `prove2me/formalpedia@acf1cadf94817574ae8d3e7431e847c0685314b6`
  - **Salt** = `jyh/salt@e7d9a19067725884e4689f9c3bb231b3e14c591b`
  - **NTKB candidate** = `jonhanke/analytic-number-theory-lean@2a7c236a347a23d8187f7a027aad058c1ee844f8` (and companion `jonhanke/elementary-number-theory-lean@a72ea55631ce8a9865a3e4df4b81b813312dc858`)
  - **AFP** = identified by registry entry/session and `.thy` theory, bound by verified release-tarball SHA-256 digests (`Gauss_Sums`, `Pentagonal_Number_Theorem`, `Perrons_Formula`, `PNT_with_Remainder`, `Prime_Distribution_Elementary`, `Prime_Number_Theorem`, `Theta_Functions`); no AFP commit SHA is invented.

### 0.3 Evidence Manifest Audit — **REPAIRED**

1. **`v4-manifest/MANIFEST.txt` structure and check:** `v4-manifest/MANIFEST.txt` (SHA-256 `27bfe1a967db05c6d4d862c21ece693dd698a1d0d8c33f118b3b2a4844976083`, 4,684 B) lists **44 entries** (`README.md` + 43 scripts/outputs/captures) and carries **no self-entry** for `MANIFEST.txt`.
   - In the local pre-fetched subset `v4-manifest/` on `xanthe`, 6 of the 44 files are shipped (`coverage-recomputed-v4.json`, `coverage-recomputed-v4.txt`, and 4 `formalpedia/*` files flattened to the directory root: `index-004-line-3394.json`, `scan-receipt.json`, `scan_formalpedia_shards.py`, `shards-SHA256SUMS.txt`). Running `python3 check-manifest.py v4-manifest` directly reports `checked=2 bad=0 missing=42 unparsed=0` because 4 shipped files are flattened without their `formalpedia/` prefix and 38 files are unshipped locally; all **6** locally shipped files match their exact SHA-256 digests and byte counts in `MANIFEST.txt` (`bad=0`).
   - Running `check-manifest.py` read-only over SSH against the full fix-lane package `dominic:/root/projects/math/tasks/carbon-apostol-v4-fix-20261110/evidence-v4` confirms all 44 files present and verified: **`MANIFEST_CHECK checked=44 bad=0 missing=0 unparsed=0`**.
2. **`evidence-v3/MANIFEST.txt` preservation:** Verified intact on `dominic` at SHA-256 `016511b839fcb29f44a7e63523dacdd1532377c5b1a528042eed96fdec1216d3` (**101** entries, no self-entry), with `check-manifest.py` reporting **`MANIFEST_CHECK checked=101 bad=0 missing=0 unparsed=0`**.
3. **Live re-fetch verification against frozen pins (`2026-11-11`):** Using `review-evidence-v4/fetch_and_verify_pins.py` (`curl -fsSL`, HTTP `200` enforced), **all 45** pinned Lean/license/Metamath files (`36` Mathlib `.lean` source files + root `Wanted.lean` at `M`, `atlas` `PrimeNumberTheorem.lean` + `LICENSE` at `A`, `interval` `Formula.lean` + `Bernoulli.lean`, `Salt` `Mertens.lean`, `Formalpedia` `Thm_MertensTheorems_sum_log_div_prime_le.lean`, and Metamath `logsqvma2.html` + `selberg.html`) plus **all 7** AFP release tarballs and **12** extracted `.thy` files were freshly fetched on `xanthe`: **`45/45` + `7/7` + `12/12` matched `evidence-v3/MANIFEST.txt` byte-for-byte with `0` hash diffs and `0` fetch errors** (`review-evidence-v4/live-pin-fetches.json`). In particular, all five required `.lean` anchor checks (and 37 additional `.lean` files) match live upstream at the frozen pins, including `DirichletContinuation.lean` (`297dd23f…`), `HurwitzZeta.lean` (`844dc62c…`), `RiemannZeta.lean` (`b20642cb…`), `Nonvanishing.lean` (`66b7ee2e…`), `PrimesInAP.lean` (`54cb65e9…`), `UnitsCyclic.lean` (`0c0f387c…`), `PrimeNumberTheorem.lean` (`720c0698…`), and `Formula.lean` (`bbe1216d…`).


---

## §1 Repair Verification (`C1–C6`, Nonblocking Items, `R1–R9`, and §8 Honesty)

### 1.1 C1 (BLOCKING — `R1d` unmarked sketches + surviving exact-statement defects) — **PARTIAL (BLOCKING FAILURE on `AT12.10`)**

1. **Exhaustive §2 bullet parse and unmarked-sketch audit (`review-evidence-v4/independent_audit.py`):**
   - Parsing `DOSSIER-APOSTOL-v4.md` §2 directly confirms **318 unique node bullets** (`70` `AD*` definitions + `248` `AT*` theorems), with sequential numbering `1..D_ch` and `1..T_ch` in all 14 chapters (`0` gaps, `0` duplicate IDs).
   - Partitioning the 318 bullets gives **`198` exact statements** and **`120` rows carrying explicit `**UNFINISHED**`**. Both `AT3.5` (L137) and `AT7.8` (L250) now carry explicit `**UNFINISHED**` marks, and **zero unmarked research sketches survive** anywhere in §2.
   - Prior content collisions in the denominator (`AT14.3` vs `AT14.4` pentagonal split; `AT6.17` vs `AT7.7–7.8` `L(1, χ) ≠ 0`; `AD9.3` vs `AT9.3` Euler's criterion; `AT9.11` vs `AT9.26` Gauss-sum QR) are resolved or flagged `UNFINISHED` — **except** for the `AT12.8` / `AT12.10` Hurwitz trigonometric-series collision documented in (3) below.

2. **Named hypothesis repairs verified at source and mathematical level:**
   - **Chapter 9 odd-prime convention & per-row `p ≠ 2` (L291, L301–320):** Verified. Both the chapter header and every applicable row state `Prime(p) ∧ p ≠ 2` (or `Odd b` for Jacobi symbols). Specifically, `AT9.20` (L320) restricts `|G(1; p)| = √p` to odd primes `p ≠ 2` (noting `G(1; 2) = 0 ≠ √2`, independently checked over all primes `< 100` in `independent_audit.py`), and `AT9.17` (L317) restricts `p = x^2 + y^2 ⇔ p ≡ 1 (mod 4)` to odd primes `p ≠ 2` (noting `2 = 1^2 + 1^2`).
   - **`AT12.12` (`n ≥ 1` in `ζ(-2n) = 0`, L407):** Verified (`n ∈ ℕ` for `ζ(-n, a) = -B_{n+1}(a)/(n+1)`, giving `ζ(0, 1) = -B_1(1) = -1/2`, and explicit `n ≥ 1` for `ζ(-2n) = 0`, matching `riemannZeta_neg_two_mul_nat_add_one` at `RiemannZeta.lean:173`).
   - **`AT12.11` (`IsPrimitive χ`, L406):** Verified (`IsPrimitive χ` explicit, matching `(hχ : IsPrimitive χ)` in `DirichletContinuation.lean:291` and avoiding the junk `rootNumber` warning at `:275`).
   - **Hurwitz parameter `0 < a ≤ 1` (`AD12.2` L390, `AT12.6` L401, `AT12.10` L405):** Verified as to the `a ∈ (0, 1]` parameter restriction (matching `hasSum_hurwitzZeta_of_one_lt_re` on `a ∈ Icc 0 1` in `HurwitzZeta.lean:73`, with `(1 : UnitAddCircle) = 0` giving `ζ(s, 1) = ζ(s)`), **but `AT12.10` fails on its `s`-domain** (see (3)).
   - **`AT1.2` (`a, b` not both `0`, L71):** Verified.
   - **`f(1) = 1` (`AD2.8` L95, `AD2.9` L96, `AT2.12` L115):** Verified (`AT2.12` explicitly requires multiplicative `f`, matching `ArithmeticFunction.IsMultiplicative` at `Defs.lean:434`).
   - **Chapter 3 `x ≥ 2` (`AT3.3(b)` L135, `AT3.6` L138):** Verified (`O(log x)` and `O(x log x)` stated on `x ≥ 2`, avoiding `log 1 = 0`).
   - **Chapter 6 `G` finite abelian (`AT6.4–AT6.9`, L222–227):** Verified (`AT6.4` marked `UNFINISHED`; `AT6.5–6.9` explicitly state `G` finite abelian).
   - **Chapter 8 `AT8.7` (`gcd(k, n)` for fixed `k`, L272):** Verified (`UNFINISHED` book-pin row explicitly states dependence on `g = gcd(|n|, k)` **for fixed `k`**; prime-power formula verified across all `80 × 81 = 6,480` pairs `(k, n) ∈ {1..80} × {-40..40}` including `n = 0` in `independent_audit.py`).
   - **Chapter 10 odd prime `p` (`AT10.7` L342, `AT10.9` L344, `AT10.10` L345):** Verified (`p ≠ 2`, `α ≥ 1`, and `m ≥ 1` in `AT10.10`, aligning with `UnitsCyclic.lean:206,287,334`).
   - **Chapter 11 forward-vs-converse separation (`AD11.1` L361, `AT11.5–11.6` L371–372, `AT11.7` L373):** Verified (`AD11.1` qualifies convergence domain; `AT11.5–11.6` state forward absolute-summability implications matching `EulerProduct/Basic.lean:225,357`; converse isolated in `UNFINISHED` `AT11.7`).
   - **Chapter 13 `AT13.2–AT13.13` count (L19, L419):** Verified (`12` nodes in inclusive range: `AT13.11` matched `[M]`, `11` `UNFINISHED`).

3. **Surviving blocking hypothesis/statement defect on `AT12.10` (`DOSSIER-APOSTOL-v4.md:405`):**
   - `DOSSIER-APOSTOL-v4.md:405` states (and counts as full **`[M]`** in §4.2 L580):
     > `Functional equation of Hurwitz zeta (finite cos/sin sum form): for 0 < a ≤ 1 (a : ℝ mapped to UnitAddCircle) and s ∈ ℂ satisfying ∀ n ∈ ℕ, s ≠ -n and (a < 1 ∨ s ≠ 1), ζ(1 - s, a) = (2 Γ(s) / (2π)^s) (cos(π s / 2) ∑_{n=1}^∞ cos(2π n a) n^{-s} + sin(π s / 2) ∑_{n=1}^∞ sin(2π n a) n^{-s}) (expressed at M via hurwitzZetaEven / hurwitzZetaOdd in hurwitzZeta_one_sub, NumberTheory_LSeries_HurwitzZeta.lean:141).`
   - **Why `AT12.10` is mathematically false as written (missing `Re(s) > 1` on raw infinite trigonometric series):**
     - **Counterexample 1 (`a = 1, s = 1/2`):** Every stated hypothesis holds (`0 < 1 ≤ 1`, `∀ n ∈ ℕ, 1/2 ≠ -n`, and `a < 1 ∨ s ≠ 1` holds via `1/2 ≠ 1`). The LHS is finite (`ζ(1/2, 1) = ζ(1/2) ≈ -1.4603545`), whereas on the RHS `cos(2π n · 1) n^{-1/2} = n^{-1/2}` and `sin(2π n · 1) = 0`, so `∑_{n=1}^∞ cos(2π n a) n^{-s} = ∑_{n=1}^∞ n^{-1/2} = +∞` diverges to `+∞` (and under Lean's unconditional `tsum` convention for non-summable series, evaluates to `0`, yielding RHS `= 0 ≠ ζ(1/2)`).
     - **Counterexample 2 (`Re(s) ≤ 0, s ∉ -ℕ`, for every `a ∈ (0, 1]`, e.g., `a = 1/3, s = -1/2`):** Every stated hypothesis holds, yet `(cos(2π n a))^2 + (sin(2π n a))^2 = 1` forces `max(|cos(2π n a) n^{-s}|, |sin(2π n a) n^{-s}|) ≥ n^{-Re(s)} / √2 ≥ 1 / √2 ↛ 0` as `n → ∞`. Both series fail the `n`-th term test across the entire half-plane `{Re(s) ≤ 0} \ (-ℕ)` (even if combined into a single series `∑ cos(π s/2 - 2π n a) n^{-s}`, at `a = 1/3, s = -1/2` the `n`-th term has magnitude `|cos(2π n/3 + π/4)| √n ≥ cos(5π/12) √n > 0.2588 √n → +∞`).
   - **Source-level mismatch with `HurwitzZeta.lean` and conflation with `AT12.8`:**
     - In `leanprover-community/mathlib4@862047ba60dbfd5ec316433fb728e310612e6449`, `hurwitzZeta_one_sub` is at `Mathlib/NumberTheory/LSeries/HurwitzZeta.lean:157–160` (`:141` is `hurwitzZetaEven_one_sub`) and states:
       `hurwitzZeta a (1 - s) = (2 * π) ^ (-s) * Gamma s * (exp (-π * I * s / 2) * expZeta a s + exp (π * I * s / 2) * expZeta (-a) s)`,
       where `expZeta a s = cosZeta a s + I * sinZeta a s` (`L116`) is the **meromorphically continued** periodic zeta function, which equals the infinite series `∑' n : ℕ, cexp (2 * π * I * a * n) / (n : ℂ) ^ s` **only when `1 < re s`** (`hasSum_expZeta_of_one_lt_re`, `L129`).
     - Moreover, `AT12.10`'s title `"finite cos/sin sum form"` refers to Apostol's rational-parameter theorem (`a = h/k`, `1 ≤ h ≤ k`, a **finite** `k`-term sum over `m = 1..k` involving `ζ(s, m/k)`), whereas its formula pastes the **infinite** trigonometric series of `AT12.8` (`L403`, Hurwitz's formula for `Re(s) > 1`) while stripping `Re(s) > 1`.
   - Under `BRIEF.md` §1 C1 (*"Any surviving unmarked sketch or missing hypothesis is a blocking failure"*), this single surviving defect on `AT12.10` is **blocking**. No other exact row among the remaining 197 exact rows in §2 exhibited a missing hypothesis or false specialization under exhaustive row-by-row inspection and finite-domain testing.

---

### 1.2 C2 (BLOCKING — `AT3.13` missing, `317` actual vs `318` printed) — **REPAIRED**

1. **Restored Chapter 3 rows:** `AT3.10` (general partial sum of a Dirichlet product, L142), `AT3.11` (divisor-sum floor identity, L143), `AT3.12` (Möbius and Mangoldt floor-sum identities, L144), and `AT3.13` (Dirichlet's symmetric hyperbola identity, explicitly marked `**UNFINISHED**`, L145) are all present as individual §2 bullets.
2. ** Totals and Chapter 3 remainder:** Independent parsing (`independent_audit.py`) confirms per-chapter counts `17 / 34 / 16 / 22 / 27 / 23 / 10 / 30 / 31 / 24 / 22 / 25 / 21 / 16` (`D`: `3, 14, 3, 5, 7, 6, 1, 8, 5, 3, 4, 5, 1, 5 = 70`; `T`: `14, 20, 13, 17, 20, 17, 9, 22, 26, 21, 18, 20, 20, 11 = 248`), summing to **`318`** and matching §1 (L31–48) and §4.2 (L569–583). Chapter 3 has `16` nodes (`AT3.1` matched `[E]`), leaving remainder **`15`** (`AD3.1–3, AT3.2–13`).
3. **Audit of `recompute_coverage_v4.py` (`review-evidence-v4/from-dominic/recompute_coverage_v4.py`):** Inspected first-hand and cross-checked against `v4-manifest/coverage-recomputed-v4.json` and `coverage-recomputed-v4.txt`. The script **parses §2 bullet IDs directly** (`^- \*\*(A[DT])(\d+)\.(\d+)\*\*`) rather than trusting chapter headings, enforces contiguous `1..D_ch` and `1..T_ch` sequences, verifies every `UNFINISHED` mark, and cross-checks §1, §4.2, and §4.3.

---

### 1.3 C3 (BLOCKING — full-node coverage semantics) — **PARTIAL (`68 / 69` verified full matches; `AT12.10` fails)**

1. **Structural 1-to-1 compliance in §4.2:** Every counted entry across `[M]` (`56`), `[E]` (`2`), and `[X]` (`11`) names one unique, explicit, non-`UNFINISHED` §2 ID (`69` pairwise disjoint IDs; zero anonymous `"one L(1,χ) node"` or `"one basic Gauss-sum node"` placeholders, zero grouped references, zero `UNFINISHED` plan nodes).
2. **Specific C3 repairs verified against live-fetched primary files (`2026-11-11`, `review-evidence-v4/declarations-and-lexical.json`):**
   - **`AT7.2` vs `AT7.3`:** `AT7.2` (Dirichlet AP infinitude, L244) is cleanly separated as a standalone `[M]` node matched by public `Nat.forall_exists_prime_gt_and_zmodEq` / `forall_exists_prime_gt_and_modEq` / `infinite_setOfPred_prime_and_modEq` in `NumberTheory/LSeries/PrimesInAP.lean:448–464`; `AT7.3` (L245) is a separate `UNFINISHED` reduction node excluded from coverage.
   - **`AT12.11` (`IsPrimitive χ`):** States `IsPrimitive χ` explicitly (L406) and matches public `DirichletCharacter.IsPrimitive.completedLFunction_one_sub` at `NumberTheory/LSeries/DirichletContinuation.lean:291` (note `:291–292` for the `theorem` header, `:288–290` docstring).
   - **`AT6.10, AT6.12, AT6.13, AT6.17`:** Explicitly matched to public declarations `DirichletCharacter.mulEquiv_units` (`Orthogonality.lean:37`), `card_eq_totient_of_hasEnoughRootsOfUnity` (`:42`), `sum_characters_eq_zero` / `sum_characters_eq` (`:61, 71`), `sum_char_inv_mul_char_eq` (`:82`), and public `DirichletCharacter.LFunction_apply_one_ne_zero` (`Nonvanishing.lean:412`, replacing v3's `private` citation).
   - **`AT8.10`:** Explicitly states unit-frequency separability (`gcd(n, k) = 1`) and matches public `gaussSum_mulShift_eq` (`NumberTheory/GaussSum.lean:83`).
   - **Chapter 9 eight symbol/reciprocity nodes (`AD9.2, AD9.4, AT9.3, AT9.5, AT9.6, AT9.11, AT9.15, AT9.16`):** Each carries its own ID with explicit `p ≠ 2` / `Odd` hypotheses and matches verified public declarations in `LegendreSymbol/Basic.lean:62,109,116,180,274`, `QuadraticReciprocity.lean:60,74,107`, `ZModChar.lean:72,77,150`, and `JacobiSymbol.lean:105,311,321,404,423`.
   - **Demotions and moves (`AD2.11, AD10.2, AT10.8, AT14.1, AT14.4`):** `AD2.11` (`ℕ`-exponent `sigma` only), `AD10.2` (`IsCyclic (ZMod m)ˣ` framing), and `AT10.8` (`UNFINISHED` lifting lemma) are removed from `[M]`; `AT14.3` consolidates Euler's pentagonal theorem onto one `[M]` ID (`EulerFunction.lean:97,134`) with `AT14.4` (`UNFINISHED`) uncounted; `AT14.1` is demoted to `PARTIAL (in Lean)` (`Partition/GenFun.lean:26` `TODO: prove this` and formal `R⟦X⟧` `WithPiTopology` at `:170`) and matched in `[X]` via AFP `Pentagonal_Number_Theorem.thy:321,338` (`sums_inverse_euler_phi_complex` / `_real`) + `:133`.
   - **Lexical trust-escape & visibility audit across all 42 pinned `.lean` files (`verify_all_69_and_lexical.py`):** Comment/string-stripped scan across all 42 `.lean` files found `0` occurrences of `admit`, `sorryAx`, `axiom`, `native_decide`, `ofReduceBool`, `implemented_by`, or `unsafe`, and `1` occurrence of `sorry` solely in the non-counted Formalpedia statement fixture `Thm_MertensTheorems_sum_log_div_prime_le.lean:45`. Zero cited declarations in §4.2 are `private`.
3. **Coverage recomputation and content adjudication:**
   - **From the dossier's own §4.2 ledger labels:** `[M] = 56 / 318` (`17.6%`), `[E] = 2 / 318` (`0.6%`), Lean full = `58 / 318` (`18.2%`), `[X] = 11 / 318` (`3.5%`), any-assistant = `69 / 318` (`21.7%`), remainder = `249 / 318` (`78.3%`).
   - **Content-level adjudication:** **`68` of the `69` counted nodes** are verified full statement matches at source level (subject to the research-only boundary in §0.2 and transparently disclosed type representations such as `ArithmeticFunction` `f 0 = 0`, `IsCyclic (ZMod m)ˣ`, `UnitAddCircle` on `a ∈ (0, 1]`, `riemannZeta`'s nonzero junk value at `s = 1` in `AT13.11`, and `ℕ`-indexed PNT in `AT13.14`). **The 69th counted node — `AT12.10` (`[M]`) — is NOT a valid match** because its §2 statement substitutes divergent infinite trigonometric series without `Re(s) > 1` for `hurwitzZeta_one_sub`'s analytically continued `expZeta` (`cosZeta`/`sinZeta`) functions (§1.1(3)). Thus **verified defect-free full-node coverage** is **`[M] = 55 / 318` (`17.3%`), `[E] = 2 / 318` (`0.6%`), Lean full = `57 / 318` (`17.9%`), `[X] = 11 / 318` (`3.5%`), any-assistant = `68 / 318` (`21.4%`), remainder = `250 / 318` (`78.6%`)**.
   - **Minor citation line-number drift in §2 Ch. 12 (nonblocking):** `AD12.2` cites `HurwitzZeta.lean:45,103` (actual `def hurwitzZeta` `:53`, `hasSum_hurwitzZeta_of_one_lt_re` `:73`); `AD12.3` cites `RiemannZeta.lean:49,115` (actual `def riemannZeta` `:127`, `zeta_eq_tsum_one_div_nat_cpow` `:207`); `AT12.9` cites `RiemannZeta.lean:81,126` (actual `completedRiemannZeta_one_sub` `:106`, `riemannZeta_one_sub` `:178`); `AT12.10` cites `HurwitzZeta.lean:141` (actual `hurwitzZeta_one_sub` `:157`).

---

### 1.4 C4 (MAJOR — Formalpedia shard-scan reproducibility + truncated `81ffb158…`) — **REPAIRED**

1. **Inspection of shipped scan artifacts (`v4-manifest/`):**
   - `v4-manifest/scan_formalpedia_shards.py` (4,807 B, SHA-256 `4939909a3673873545340adbdba34a912a83bd5f63b6992cb98d1f73b08e3a81`) is a self-contained executable Python script that downloads all `20` frozen shards `envs/0df444a/index-000.jsonl` … `index-019.jsonl` from `prove2me/formalpedia@acf1cadf94817574ae8d3e7431e847c0685314b6`, verifies all `20` per-shard SHA-256 digests against `shards-SHA256SUMS.txt` (`da6bd1ca…`), and scans every JSONL line both as raw case-insensitive text (`"apostol"`) and recursively across parsed JSON string values.
   - `v4-manifest/scan-receipt.json` (SHA-256 `da6e703c…`, executed `2026-11-11T07:50:24Z`, exit `0`) records `shards_scanned: 20`, `all_20_sha256_matched: true`, `total_bytes: 455592034`, `total_records_scanned: 386344`, `raw_case_insensitive_line_hits: 16`, `parsed_json_record_hits: 16`, `raw_and_parsed_agree: true`, and `counts_by_book: {"IANT": 9, "ModularFunctionsVol2": 3, "MathematicalAnalysis": 4}`. Cross-checking `apostol-records-full.jsonl` (`1fe74948…`, 16 JSONL lines) confirms all 16 records and book classifications.
2. **Independent live single-shard authentication (`2026-11-11`, `review-evidence-v4/formalpedia-shard004-check.json`):**
   - Per the brief's cap (re-authenticate at most one shard rather than re-downloading 455 MB), `index-004.jsonl` (`25,228,821` B) was freshly fetched via `curl -fsSL` from `https://raw.githubusercontent.com/prove2me/formalpedia/acf1cadf94817574ae8d3e7431e847c0685314b6/envs/0df444a/index-004.jsonl` (and deleted after verification).
   - Its SHA-256 matched `shards-SHA256SUMS.txt` identically (`f15c9da00ca02c2bdfaa55449d0e80656d0f310b9209ba4be5c31a8a36b1a5b9`), its line count matched (`19,476` records), and scanning it yielded the exact `6` `"apostol"` hits (`3076, 3077, 3080, 3364, 3394, 3395`), including `3080` (`d09af852-f479-4509-a198-8f0ba56f9115`, `MertensTheorems.sum_log_div_prime_le`, anchoring `4.10 [V]`) and `3394` (`81ffb158-208f-4fe4-85f0-794dd288461a`, `MilnorLambda`), which matched `v4-manifest/index-004-line-3394.json` (`533d0855…`) byte-for-byte with untruncated `"..., cf. Apostol, Modular Functions and Dirichlet Series in Number Theory, Vol. 2, Springer, 1990, Chapter 2."`
   - **Grade:** The 20-shard scan is **reproducible** from the shipped script, checksums, and receipt.

---

### 1.5 C5 (MODERATE — 55-node inventory vs route-fidelity swing) — **REPAIRED (minor `7`-for-`8` slip at L603 & L721)**

1. **Common unmatched-statement inventory (`18 + 19 + 18 = 55`):** §4.3(1) (L593–599) preserves the exact `55` unmatched Ch. 11–13 nodes (`Ch. 11: 18`, `Ch. 12: 19`, `Ch. 13: 18`), verified by `independent_audit.py` to be pairwise disjoint and exact chapter complements of §4.2's matched nodes in Chapters 11–13. It accurately frames all 55 nodes as required book statements under **either** charter (`AD13.1` as a definition, `AT13.18` RH as a statement-only conjecture), withdrawing v3's conflation of the 55-node inventory with the charter delta.
2. **Route-fidelity separation and 3-4-1 classification:** §4.3(2) (L601–608) separates incremental route-fidelity obligations into (a) textbook-route re-proofs of already-matched theorems and (b) Hankel/keyhole contour infrastructure, and explicitly classifies Apostol's `3 + 4 cos θ + cos 2θ ≥ 0` proof of `AT13.11` strictly as a **route-fidelity** requirement, never statement fidelity (L604).
3. **Minor arithmetic slip (nonblocking):** §4.3(2)(a) L603 writes `("7" analytic/Dirichlet theorems across Ch. 6–7 & 12–13)` (repeated in §8.1 L721 as `"7" re-proofs`), then enumerates `AT13.11` (`1`) + `AT13.14` (`1`) + `AT12.6, AT12.9, AT12.10, AT12.11` (`4`) + `AT6.17, AT7.2` (`2`) = **`8` nodes** (matching the 8 IDs named in §6.3 Gate 3 L668).

---

### 1.6 C6 (MODERATE — unbounded Ch. 6–7 route claim + newly located `jonhanke` project) — **REPAIRED (minor companion timestamp label nit)**

1. **Source-bounded Ch. 6–7 route statement (§5.2 L622):** Verified. Replaces v3's universal `"the book's Ch. 6–7 route is no formalization's route"` with the source-bounded statement that neither Mathlib's `PrimesInAP.lean` nor AFP's `Dirichlet_L` follows Apostol's elementary real-character Ch. 6–7 route, while explicitly marking uninspected formalizations (including `jonhanke/analytic-number-theory-lean`) **`UNVERIFIED`**.
2. **Live verification of `jonhanke/analytic-number-theory-lean` (`2026-11-11`, `review-evidence-v4/c6-live-summary.json`):**
   - **Repository & pinned commit:** Live GitHub REST queries (`curl -fsSL`, HTTP `200`) confirm `jonhanke/analytic-number-theory-lean` was created `2026-11-10T18:24:22Z`, license `Apache-2.0`, pinned commit `2a7c236a347a23d8187f7a027aad058c1ee844f8` committed `2026-11-10T21:03:23Z` (with subsequent upstream pushes already reaching `2026-11-11T09:24:01Z`), toolchain `leanprover/lean4:v4.36.0-rc2`, Mathlib `1b1ccf4b088b32fa3f23f2de1127433254a81e1e`. Recursive tree summary (`266` blobs, `0` raw tree dumps): `247` `.lean` files (`109` `NTKB/Analytic/Apostol/`, `114` `NTKB/Analytic/Davenport/`, `14` `NTKB/Elementary/`, `2` `NTKB/Port/`, plus root/Challenge/Solution/scripts; `Challenge_Apostol.lean` has `3` intentional `sorry`s, `Solution_Apostol.lean` has `0` `sorry`s).
   - **Self-reported `docs/results/books/apostol.md` row counts:** Independent table parse confirms **`322` rows** across Chapters 1–14 (`20 / 42 / 21 / 21 / 35 / 23 / 10 / 28 / 20 / 20 / 27 / 27 / 17 / 11`), consisting of **`168` `"proved"`**, **`148` `"in Mathlib"`**, **`2` `"proved in part"`**, **`3` `"in Tau Ceti only (not a dependency)"`**, and **`1` `"in PrimeNumberTheoremAnd only (not a dependency)"`**.
   - **Chapter 14 truncation & AI/unreviewed disclosures:** Confirmed directly from `apostol.md` (Chapter 14 has `11` rows ending at `Theorem 14.8`, omitting Ramanujan's mod-`5` and mod-`7` congruences `AT14.10–14.11`), `formalization.yaml:84–97,111–118`, and `README.md:43–44` (written almost entirely by `Claude Opus 5.5` and `Claude Sonnet 5.5` in Nov 2026; `"the 18 headline statements of the Challenge_<book>.lean files and the definitions they use have not yet been reviewed by a human"` and `"The rest of the library has not been reviewed by a human"`).
   - **Non-promotion & Gate 1:** Confirmed v4 promotes **zero** rows of `analytic-number-theory-lean` to verified coverage in §4 and places a dedicated build/`#print axioms`/statement-fidelity audit as mandatory Gate 1 in §6.3 (L666).
   - **Live GitHub searches (`2026-11-11`):** Confirmed `Apostol language:Lean` → **`1` repository** (`jonhanke/analytic-number-theory-lean`), `Apostol language:Isabelle` → `0`, `Apostol language:Coq` → `0`, `"Introduction to Analytic Number Theory"` → `2` (`robfatland/ant`, `wflaherty02/IntroductionToANT`), with v3's `0`-hit capture properly marked historical only (§3.8 L533).
   - **Minor timestamp nit (nonblocking, §3.8 L538):** v4 writes `(created 2026-11-10T18:33:08Z)` for companion `jonhanke/elementary-number-theory-lean@a72ea55631ce8a9865a3e4df4b81b813312dc858`; live GitHub API check shows `2026-11-10T18:33:08Z` is the **commit date** of `a72ea556…`, while the repository's `created_at` is `2026-11-09T15:30:42Z`.

---

### 1.7 Nonblocking Items (`1–4`) — **ALL 4 REPAIRED**

| # | v3 Review Nonblocking Item | Disposition in v4 | Evidence |
|---:|---|---|---|
| 1 | Qualify `PARTIAL` flags **in Lean** and separate `[X]`-full nodes from global remainder | **REPAIRED** | All `8` flags read `PARTIAL (in Lean)` (§0.2 L23, §4.1–4.2 L555–583); `[X]`-full trio `{AT4.10, AT4.11, AT14.1}` cleanly separated from global-remainder quintet `{AD2.11, AT2.14, AT8.11, AT11.11, AT12.12}`. |
| 2 | `AT13.2–AT13.13` count (`12` nodes, `AT13.11` `[M]`, `11` `UNFINISHED`) | **REPAIRED** | Explicitly corrected in §0.1 L19 and §2 Ch. 13 L419; verified by parser. |
| 3 | Mathlib file count (`36` source files + `Wanted.lean` = `37` total) | **REPAIRED** | Corrected in §3.1 L480–482 and §7 L697; verified in `evidence-v3/MANIFEST.txt` and live fetches. |
| 4 | `AT8.7` squared Ramanujan divisor sum depends on `gcd(k, n)` **for fixed `k`** | **REPAIRED** | Stated explicitly at §2 `AT8.7` L272 (`(2,1) → 2` vs `(6,1) → 4`); verified across `6,480` `(k, n)` pairs. |

---

### 1.8 `R1–R9` Adjudication (Full Set — Every Item Reported)

| v2 Review ID | v3 Disposition | v4 Disposition (Verified `2026-11-11`) | Evidence & Source Spot-Checks |
|---|---|---|---|
| **R1a** (Ch. 8 Ramanujan identities, `n = 0`) | Repaired | **PRESERVED (REPAIRED)** | `AT8.4–AT8.8` (L269–273) retain `k [k ∣ n]`, withdraw `k gcd(k, n)` with fixed-`k` prime-power formula, include `n = 0`, and restrict multiplicativity to `k`; verified on `6,480` pairs (`independent_audit.py`). |
| **R1b** (Ch. 8–9 Gauss-sum primitivity & coprime/odd-prime hypotheses) | Close in Ch. 8; Ch. 9 `p = 2` caveat | **REPAIRED** | `AT8.10–8.12, AT8.19` keep primitive + `gcd(n, k) = 1` hypotheses; `AT9.20` (L320) adds `p ≠ 2` (`G(1; 2) = 0 ≠ √2`). |
| **R1c** (`AT4.12` Mertens product constant `e^{R - B}`) | Repaired | **PRESERVED (REPAIRED)** | **Spot-checked:** `AT4.12` (L168) states `∏_{p≤x} (1 - 1/p) ∼ e^{R - B} / log x` (`= e^{-γ} / log x` under `B = γ + R`, never `e^{-B}`), `R < 0` (`≈ -0.31571` over `p ≤ 200,000`); `afp/src/Mertens_Theorems.thy` verified to have `15` declaration headers and zero product-form corollary (`run_remaining_checks.py`). |
| **R1d** (Unmarked sketches & exact-statement hypotheses) | Failed (`C1`) | **PARTIAL — BLOCKING (`AT12.10`)** | Zero unmarked sketches survive (`120` explicit `UNFINISHED`), and all named C1 repairs hold **except `AT12.10`**, which omits `Re(s) > 1` on raw divergent trigonometric series (§1.1(3)). |
| **R2** (1-to-1 full-node coverage remap) | Failed (`C2, C3`) | **PARTIAL — BLOCKING (`AT12.10`)** | `318` IDs restored and `68 / 69` counted nodes verified at source level, **except `AT12.10`**, whose §2 series formula does not match `hurwitzZeta_one_sub` (`HurwitzZeta.lean:157`, §1.3). |
| **R3** (Classical zero-free region, PNT `/3653`, `ζ(1+it) ≠ 0`) | Repaired | **PRESERVED (REPAIRED)** | **Spot-checked:** `Zeta_Zerofree.thy:872–874` + `PNT_Notation.thy:6` prove `1 - β ≥ (1/952320) / ln(|γ| + 2)` (classical inverse-log shape, intermediate `1/29760` at `:748–750`, **not** Vinogradov–Korobov); `PNT_with_Remainder.thy:1108–1109` proves `O(x * exp(- 1 / 3653 * (ln x) powr (1 / 2)))` (`3653` outside the root); `Nonvanishing.lean:417` proves `riemannZeta_ne_zero_of_one_le_re` (`AT13.11` `[M]`). |
| **R4** (Pointwise Selberg `AT2.20` in Metamath) | Repaired | **PRESERVED (REPAIRED)** | `AT2.20` matched `[X]` via Metamath `logsqvma2.html` (`b02da237…`, Mario Carneiro, `13-May-2016`); asymptotic `AT4.17` matched via `Selberg_Asymptotic_Formula.thy:79` and `selberg.html` (`23-May-2016`). |
| **R5** (Uniform Pólya–Vinogradov constant `2`) | Repaired | **PRESERVED (REPAIRED)** | **Spot-checked:** `Polya_Vinogradov.thy:817–828` warns fixed-modulus `O(√n log n)` is vacuous and proves `norm (∑ m=1..x. χ m) < 2 * sqrt n * ln n` for `χ ≠ principal_dchar n` with constant `2` fixed prior to `n, χ, x` (`AT13.15` `[X]`; primitive constant `1` noted at `AT8.22`). |
| **R6** (Evidence package + Formalpedia + Palomar) | Partial (`C4`) | **REPAIRED** | `101/101` `evidence-v3` + `44/44` `evidence-v4` manifest-verified; C4 20-shard scan shipped & shard `004` live-authenticated (§1.4); Palomar rev `857` (`40638c75…`, `1,056` results / `825` projects, `0` hits) independently reproduced live on `2026-11-11` (`c6-live-summary.json`). |
| **R7** (Analytic JTP blueprint & Ch. 11–13 separation) | Partial (`C5`) | **REPAIRED** | Analytic two-variable continuation blueprint from `Jacobi_Triple_Product.thy:32–47,172,313–393` retained (§5.5, §6.3 Gate 4); 55-node inventory separated from route-fidelity delta (§1.5). |
| **R8** (No first-complete claim; AFP & Mathlib dates) | Partial (`C6`) | **REPAIRED** | AFP dates (`PNT_with_Remainder` `2024-05-05`, `Perrons_Formula` `2026-06-17`, `Rademacher_Series` `2026-07-03`, `Dirichlet_L` `2017-12-21`) verified in `afp/entries/*.html:95`; Mathlib commit dates (`#45509` `2026-10-31T15:38:56Z`, `#43233` `2026-11-03T23:55:27Z`) and C6 candidate (`2026-11-10T21:03:23Z`) verified live (`c6-live-summary.json`). |
| **R9** (Euler–Maclaurin `saw_one` half-term cancellation) | Repaired | **PRESERVED (REPAIRED)** | `interval/Formula.lean:293–323` + `Bernoulli.lean:146` (`saw_one : saw 1 x = Int.fract x - 1 / 2`) verified algebraically and numerically across 4 test intervals (`run_remaining_checks.py`). |

---

### 1.9 §8 Disposition Honesty

- **Accurate mapping & stance:** §8 maps every C1–C6 item, all 4 nonblocking items, and R1–R9 with concrete section pointers, and maintains the no-ordinal / un-established `#4` stance without evasion through §8 and the rule-compliance footer (L739).
- **Two inaccuracies in §8:**
  1. §8.1 (`C1` L717, `C3` L719) and §8.2 (`R1d & R2` L728) report `C1`, `C3`, `R1d`, and `R2` as completely closed (`56 / 2 / 11 / 249`), overlooking the surviving `AT12.10` divergent-series defect and `hurwitzZeta_one_sub` declaration mismatch (§1.1(3), §1.3).
  2. §8.1 (`C5` L721) repeats §4.3(2)(a)'s `"7"` count for an enumerated `8`-theorem list.

---

## §2 Internal Consistency Audit (§2, §4, §5, §6)

### 2.1 Inventory (§2) and §4 Table Arithmetic

- **§2 row count (`independent_audit.py`):** Exactly **`318` unique bullet IDs** (`70` `AD*` + `248` `AT*`), split into `198` exact rows and `120` explicit `UNFINISHED` rows, matching §1's chapter-by-chapter table (`17 + 34 + 16 + 22 + 27 + 23 + 10 + 30 + 31 + 24 + 22 + 25 + 21 + 16 = 318`).
- **§4.2 row and column arithmetic:** Every chapter row satisfies `[M] + [E] + [X] + Remainder = Nodes`, and column sums equal `56 + 2 + 11 + 249 = 318` identically. The `8` `PARTIAL (in Lean)` flags partition cleanly into `3` `[X]`-full nodes (`AT4.10, AT4.11, AT14.1`) and `5` global-remainder nodes (`AD2.11, AT2.14, AT8.11, AT11.11, AT12.12`).

### 2.2 Coverage Figures Across §0, §4, and §6 — Verified Proofs vs Label Census

- **Cross-section arithmetic consistency:** §0.2 (L23), §4.1–4.2 (L559–583), §6.2 (L661), and §8.1 (L719) report identical ledger figures (`56/318 = 17.6%`, `2/318 = 0.6%`, `58/318 = 18.2%`, `11/318 = 3.5%`, `69/318 = 21.7%`, `249/318 = 78.3%`).
- **Nature of the figures & single overclaim:**
  - Within the research-only boundary (source-level declaration/signature verification + comment-stripped lexical screening across all 42 `.lean` files, without kernel builds or `#print axioms`), **`68 / 69` counted nodes** (`55 [M]`, `2 [E]`, `11 [X]`) are **verified source-level statement matches** with disclosed representation bridges, while broader AFP entry-level overlap is appropriately held in uncounted `ABSTRACT`.
  - **Where the dossier still overclaims:** `AT12.10` (`[M]`, L405 & L580) overclaims a full `[M]` match on a false/divergent infinite-series statement (`Re(s) > 1` omitted, mismatching `HurwitzZeta.lean:157` `hurwitzZeta_one_sub`). Correcting that single overclaim yields **`[M] = 55/318` (`17.3%`), `[E] = 2/318` (`0.6%`), Lean full = `57/318` (`17.9%`), `[X] = 11/318` (`3.5%`), any-assistant = `68/318` (`21.4%`), remainder = `250/318` (`78.6%`)** (unless `AT12.10`'s §2 statement is repaired to state `expZeta` / `cosZeta` / `sinZeta`).

### 2.3 §5 Endpoint Transcriptions — Source-Level Spot-Checks Beyond C3/C6

All six §5 endpoints were verified directly against the live-fetched primary files (`2026-11-11`):

1. **PNT (`§5.1`, `atlas/PrimeNumberTheorem.lean:131,138,183` & AFP `PNT_with_Remainder.thy:1108–1109`, `Zeta_Zerofree.thy:748,872`, `PNT_Notation.thy:6`):** `public theorem prime_number_theorem` (`PrimeNumberTheorem.lean:183–186`) proves `Asymptotics.IsEquivalent (Filter.atTop : Filter ℕ) (fun n : ℕ => (Nat.primeCounting n : ℝ)) (fun n : ℕ => (n : ℝ) / Real.log (n : ℝ))` (`pnt_theta_isEquivalent` `:131` and `pnt_primeCounting_floor_isEquivalent` `:138` are `private`); AFP `prime_number_theorem` (`PNT_with_Remainder.thy:1108–1109`) proves `(λx. π x - Li x) ∈ O(λx. x * exp (- 1 / 3653 * (ln x) powr (1 / 2)))` from `zeta_nonzero_region` (`Zeta_Zerofree.thy:872–874`, `C₁ = 1/952320`). Scope matches (`AT13.14` equal to `atlas`, weaker in rate than AFP).
2. **Euler's summation formula (`§5.3`, `interval/Formula.lean:293–323` & `Bernoulli.lean:146`):** `EulerMaclaurin.sum_Ioc_eq_integral_add_of_hasDerivWithinAt` (`Formula.lean:293–301`, `hp : p ≠ 0`, `hab : a ≤ b`, Banach space `E`) and `sum_Ioc_eq_integral_add` (`:313–321`, `ContDiffOn ℝ p f (Set.Icc a b)`) specialize at `p = 1` via `saw_one : saw 1 x = Int.fract x - 1 / 2` (`Bernoulli.lean:146`) to `AT3.1` after exact cancellation of `±(f(x) - f(y))/2`. Scope matches (`AT3.1` is a strictly weaker scalar `C^1` first-order case).
3. **Perron's formula (`§5.4`, AFP `Perrons_Formula.thy:982–986, 1208–1213`):** `perron_asymp` (`:982–986`) assumes `c > 0`, `ereal (Re z + c) > conv_abscissa f`, `x > 0` with half-weighted `sum_upto'`; `perron_effective_strong` (`:1208–1213`) assumes `c > 0`, `ereal c + ereal (Re z) > abs_conv_abscissa f`, `T > 0`, `x > 0` and bounds `dist A B ≤ 4 * (arctan (T / c) + pi + 1) * x powr c * perron_bound f (c + Re z) x T`. Scope matches.
4. **Jacobi's triple product (`§5.5`, AFP `Jacobi_Triple_Product.thy:32–47, 315–395`):** `jacobi_theta_nome_triple_product_complex` (`:32–35`) assumes `w ≠ 0`, `norm q < 1` (`w, q :: complex`) and proves `jacobi_theta_nome w q = (q² ; q²)_∞ * (-q*w ; q²)_∞ * (-q/w ; q²)_∞` via two-step `analytic_continuation` in `w ∈ -{0}` (`:315–355`) and `q ∈ ball 0 1` (`:360–395`). Scope matches `AT14.7` under `q = x, w = y^2`.
5. **Mertens Lean bounds & Selberg (`§3.6` & `§5.6`, `salt/Salt_Maynard_Mertens.lean:152,473`, `Selberg_Asymptotic_Formula.thy:23–30,79–82`, Metamath `logsqvma2.html` & `selberg.html`):** Confirmed `sum_log_div_prime_le` (`:152`, `1 ≤ N`) and `sum_inv_prime_le` (`:473`, `2 ≤ n`) are upper bounds only (`PARTIAL (in Lean)` on `AT4.10–4.11`), and confirmed `selberg_asymptotic_formula` (`:79–82`) and Metamath `logsqvma2` (`13-May-2016`) / `selberg` (`23-May-2016`) match `AT4.17` and `AT2.20`.

### 2.4 §6.1 Controlling Programme State — Full 11-Slot Comparison (`#1–#11`)

Per the brief (`2026-11-11 01:23 PST`) and standing set-reporting rules, every slot `#1–#11` in `DOSSIER-APOSTOL-v4.md` §6.1 (L653–655, dated `2026-11-10`) is audited below:

| Slot & Book | v4 §6.1 Cell (`2026-11-10`) | Controlling State (`2026-11-11 01:23 PST`) | Cell Audit |
|---|---|---|---|
| **#1** Garling | Stands | Stands | **MATCH** |
| **#2** Marcus | Stands | Stands | **MATCH** |
| **#3** Humphreys | OPEN (v3 FAIL; v4 review FAIL; v5 fix LANDED + harvested, renewed review PASS WITH ISSUES recorded; slot NOT established) | Open (v5 crossed review PASS WITH ISSUES, recorded on `#69`; slot NOT established) | **MATCH** |
| **#4** Apostol | UN-ESTABLISHED (v3 FAIL — this fix) | Undecided (v3 FAIL recorded on `#67`; v4 fix under this review) | **MATCH** |
| **#5** Walters | CONTESTED (v2 FAIL; v3 review FAIL, recorded; `v4 fix queued`) | Open (v2 FAIL; v3 FAIL by Carbon review, recorded on `#68`; **`v4 fix is running on dominic`**) | **STALE** (`queued` → `running on dominic`) |
| **#6** Lieb & Loss | Conditional candidate (v2 FAIL; v3 PASS WITH ISSUES; v4 review PASS WITH ISSUES, recorded; slot NOT established) | Conditional candidate stance, `#6` slot NOT earned (v3 PASS WITH ISSUES; v4 fix harvested and renewed crossed review recorded on `#71`) | **MATCH** |
| **#7** Marker | CONTESTED (v1 FAIL; v2 FAIL; v3 review FAIL ×2; `v4 fix RUNNING`) | Undecided; **`v4 crossed review returned PASS (recorded on #72)`** — candidate-without-selection stance, `#7` slot NOT established | **STALE** (`v4 fix RUNNING` → `v4 review PASS on #72`) |
| **#8** Milnor | CONTESTED (v1 FAIL; v2 FAIL; `v3 fix RUNNING`) | `#8` NOT established (v2 FAIL recorded on `#70`); **`v3 crossed review returned PASS WITH ISSUES (recorded on #70)`** | **STALE** (`v3 fix RUNNING` → `v3 review PASS WITH ISSUES on #70`) |
| **#9** van Lint | CONTESTED (v1 FAIL; v2 PASS WITH ISSUES; `v3 fix LANDED + harvested + recorded`; slot NOT established) | v2 PASS WITH ISSUES, and **`v3 crossed review returned PASS (recorded on #73)`** — candidate label, `#9` slot NOT established | **STALE** (`v3 fix LANDED` → `v3 review PASS on #73`) |
| **#10** Alon & Spencer | CONTESTED (FAIL; v2 fix LANDED; v2 review FAIL, recorded; `v3 fix queued`) | `#10` NOT established (FAIL recorded on `#74`; `v3 fix is queued after Cutland v3`) | **MATCH** (queue order detail) |
| **#11** Cutland | CONTESTED (v1 FAIL; v2 PASS WITH ISSUES, recorded; slot NOT established; `v3 fix queued`) | Candidate label, `#11` NOT established (v1 FAIL, v2 PASS WITH ISSUES recorded on `#75`; **`v3 fix is running on brooklynn`**) | **STALE** (`v3 fix queued` → `v3 fix running on brooklynn`) |

Because none of `#3–#11` has an established slot in either snapshot, the five overnight operational transitions (`#5, #7, #8, #9, #11`) do not affect v4's no-ordinal stance, but §6.1 should be updated to the `2026-11-11` state in the next revision.

### 2.5 §6.2–§6.3 Recommendation, Mandatory Gates, and `#4`-Slot Adjudication

- **Candidate-without-selection stance & gates:** §6.1 (L657), §6.2 (L661–662), §6.3 (L666–671), and the footer (L739) carry the no-ordinal stance honestly and preserve all six mandatory prerequisites prior to any selection or pinning: (1) dedicated build / `#print axioms` / human statement-fidelity audit of `jonhanke/analytic-number-theory-lean@2a7c236a…`, (2) physical-book inventory & completion of all 120 `UNFINISHED` rows, (3) upfront statement-complete vs route-complete charter ruling, (4) Ch. 14 analytic two-variable JTP continuation budget, (5) frozen dependency manifest & `atlas` ML-license ruling, and (6) coordinator-appointed crossed reviews.
- **Explicit `#4`-slot finding:** **The `#4` slot is NOT established.** `DOSSIER-APOSTOL-v4.md` neither recommends nor awards `#4`, §6.3 Gates 1–6 remain unexecuted prerequisites, and the dossier fails C1/C3 on `AT12.10`.

---

## §3 Verdict and Required Corrections

**Verdict: FAIL.**

`DOSSIER-APOSTOL-v4.md` successfully repairs **C2, C4, C5, C6, all 4 nonblocking items, the evidence manifests (`44/44` in `evidence-v4`, `101/101` in `evidence-v3`), all 120 `UNFINISHED` markers (`0` unmarked sketches), and 68 of 69 counted §4.2 matches**, and maintains an honest candidate-without-selection stance. However, **one material exact-statement and full-node coverage claim is mathematically false as written and violates the brief's explicit C1/C3 blocking rules**:

1. **BLOCKING (`C1` / `C3` / `R1d` / `R2`) — False/divergent infinite-series functional equation at `AT12.10` (`DOSSIER-APOSTOL-v4.md:405`, §4.2 L580, §8.1 L717 & L719):**
   - `AT12.10` asserts `ζ(1 - s, a) = (2 Γ(s) / (2π)^s) (cos(π s / 2) ∑_{n=1}^∞ cos(2π n a) n^{-s} + sin(π s / 2) ∑_{n=1}^∞ sin(2π n a) n^{-s})` for `0 < a ≤ 1`, `∀ n ∈ ℕ, s ≠ -n`, and `(a < 1 ∨ s ≠ 1)`, **omitting `Re(s) > 1`** while counting `AT12.10` as full **`[M]`** via `HurwitzZeta.hurwitzZeta_one_sub`.
   - As proved in §1.1(3), the stated RHS series diverges to `+∞` at `(a, s) = (1, 1/2)` (where all stated hypotheses hold and `ζ(1/2) ≈ -1.46035` is finite) and fails the `n`-th term test across the entire half-plane `{Re(s) ≤ 0} \ (-ℕ)` for every `a ∈ (0, 1]`, because `hurwitzZeta_one_sub` (`Mathlib/NumberTheory/LSeries/HurwitzZeta.lean:157`, mis-cited as `:141`) is stated in terms of the **analytically continued** function `expZeta` (`cosZeta + I * sinZeta`), which equals the infinite trigonometric series only when `1 < re s` (`hasSum_expZeta_of_one_lt_re`, `:129`). It also conflates the `"finite cos/sin sum form"` (`a = h/k` rational finite sum over `m = 1..k` of `ζ(s, m/k)`) with Hurwitz's `Re(s) > 1` infinite trigonometric series (`AT12.8`).
   - **Required fix:** Either (i) state `AT12.10` in terms of the meromorphically continued periodic zeta functions `cosZeta` / `sinZeta` (`expZeta` at `HurwitzZeta.lean:157`) if that matches the intended node, or (ii) if the book slot is the rational `a = h/k` finite sum `ζ(1 - s, h/k) = (2 Γ(s) / (2π k)^s) ∑_{m=1}^k cos(π s / 2 - 2π m h / k) ζ(s, m/k)` (or an unpinned variant), write the true finite-sum statement (or mark `UNFINISHED` pending physical check) and drop `AT12.10` from `[M]` (`56 → 55`, Lean `58 → 57`, any `69 → 68`, remainder `249 → 250`), updating §0, §4, §6, and §8 accordingly.

2. **NONBLOCKING — Refresh §6.1 controlling programme state (`DOSSIER-APOSTOL-v4.md:653–655`):** Update the five stale `2026-11-10` cells (`#5` Walters, `#7` Marker, `#8` Milnor, `#9` van Lint, `#11` Cutland) to the current controlling state (§2.4).
3. **NONBLOCKING — Fix `"7" → "8"` matched-theorem count in §4.3(2)(a) L603 & §8.1 L721:** Align the printed count with the enumerated list (`1 + 1 + 4 + 2 = 8` nodes, or `7` if `AT12.10` is demoted from `[M]`).
4. **NONBLOCKING — Fix minor citation line numbers & companion timestamp label:** Update Ch. 12 line numbers (`AD12.2` `HurwitzZeta.lean:53,73`; `AD12.3` `RiemannZeta.lean:127,207`; `AT12.9` `RiemannZeta.lean:106,178`; `AT12.10` `HurwitzZeta.lean:157`) and label `2026-11-10T18:33:08Z` on `jonhanke/elementary-number-theory-lean@a72ea556…` (§3.8 L538) as commit date (`created_at` is `2026-11-09T15:30:42Z`).

**Slot `#4` decision:** The `#4` slot is **NOT established** by `DOSSIER-APOSTOL-v4.md` or by the evidence verified in this review; the dossier's no-ordinal stance stands, and neither pinning nor `#4` selection may proceed before the blocking `AT12.10` repair and §6.3 Gates 1–6.

**Final verdict: FAIL.**
REVIEW COMPLETE.
